#ifndef HTTPSERVER_H
#define HTTPSERVER_H

extern SeafileSession *seaf;

#endif /* HTTPSERVER_H */
