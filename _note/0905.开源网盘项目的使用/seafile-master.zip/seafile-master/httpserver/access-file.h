#ifndef ACCESS_FILE_H
#define ACCESS_FILE_H

int
access_file_init (evhtp_t *htp);

#endif
