
#ifndef COMMIT_MSG_H
#define COMMIT_MSG_H

char *
translate_commit_desc (const char *input);

#endif
