//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by trayicon.rc
//
#define IDI_STARTINTRAY                 102
#define IDS_APP_TITLE                   103
#define IDM_EXIT                        105
#define IDI_SEAFILE_ICON                107
#define IDC_STARTINTRAY                 108
#define IDI_STATUS_UP                   110
#define IDI_STATUS_DOWN                 111
#define IDI_STATUS_TRANSFER_1           113
#define IDI_STATUS_TRANSFER_2           114
#define IDI_STATUS_TRANSFER_3           115
#define IDI_STATUS_TRANSFER_4           116
#define IDD_CREATE_REPO1                138
#define IDD_WIN7_TIP                    140
#define IDD_INIT_SEAFILE                141
#define IDB_TOP_BANNER                  144
#define IDI_ICON1                       145
#define IDI_STATUS_AUTO_SYNC_DISABLED   145
#define IDC_STATIC_CREATE_PATH2         1003
#define IDC_STATIC_SEAFILRDIR           1017
#define IDC_STATIC_SEAFILE              1018
#define IDC_COMBOX_DISK                 1021
#define IDC_COMBO1                      1029
#define IDC_CHECK_NO_TIP                1032
#define ID_FINISH                       1033
#define IDC_STATIC_TITLE                1037
#define IDC_BUTTON_CHOOSE_SEAFILE_DIR   1039
#define IDC_EDIT2                       1040
#define IDC_EDIT_SEAFILE_DIR            1040
#define IDM_OPEN                        32773
#define IDM_RESTART                     32776
#define ID_Menu                         32778
#define ID_Menu32779                    32779
#define ID_32780                        32780
#define IDM_SYNC_PAUSE                  32781
#define IDM_SYNC_RESTORE                32782
#define IDM_DISABLE_AUTO_SYNC           32783
#define IDM_ENABLE_AUTO_SYNC            32784
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        146
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1041
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
