#ifndef GC_CORE_H
#define GC_CORE_H

int gc_core_run (int dry_run, int ignore_errors);

#endif
