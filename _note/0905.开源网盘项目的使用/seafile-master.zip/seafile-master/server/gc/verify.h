#ifndef GC_VERIFY_H
#define GC_VERIFY_H

int verify_repos ();

#endif
