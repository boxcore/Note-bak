<?php
/* vim: set expandtab sw=4 ts=4 sts=4: */
/**
 * @version $Id: merge.lib.php 10137 2007-03-19 17:55:39Z cybot_tm $
 */

/**
 *
 */
class PMA_StorageEngine_merge extends PMA_StorageEngine
{
}

?>
