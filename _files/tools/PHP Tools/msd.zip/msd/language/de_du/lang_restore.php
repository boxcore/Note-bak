<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Es wurden bisher <b>%d</b> Tabellen angelegt.";
$lang['L_FILE_MISSING']="konnte Datei nicht finden";
$lang['L_RESTORE_DB']="Datenbank '<b>%s</b>' auf Server '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> Tabellen wurden angelegt.";
$lang['L_RESTORE_RUN1']="<br>Es wurden bisher <b>%s</b> von <b>%s</b> Datensätzen erfolgreich eingetragen.";
$lang['L_RESTORE_RUN2']="<br>Momentan werden Daten der Tabelle '<b>%s</b>' analysiert.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> Datensätze wurden eingetragen.";
$lang['L_RESTORE_TABLES_COMPLETED']="Es wurden bisher <b>%d</b> von <b>%d</b> Tabellen angelegt.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Herzlichen Glückwunsch.</b><br><br>Die Datenbank wurde komplett wiederhergestellt.<br>Alle Daten aus der Backup-Datei wurden erfolgreich in die Datenbank eingetragen.<br><br>Alles fertig. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Fehler:<br>Auswahl der Datenbank '<b>";
$lang['L_DB_SELECT_ERROR2']="</b>' fehlgeschlagen!";
$lang['L_FILE_OPEN_ERROR']="Fehler: Die Datei konnte nicht geöffnet werden.";
$lang['L_PROGRESS_OVER_ALL']="Fortschritt gesamt";
$lang['L_BACK_TO_OVERVIEW']="Datenbank-Übersicht";
$lang['L_RESTORE_RUN0']="<br>Es wurden bisher <b>%s</b> Datensätze erfolgreich eingetragen.";
$lang['L_UNKNOWN_SQLCOMMAND']="Unbekannter SQL-Befehl:";
$lang['L_NOTICES']="Hinweise";


?>