<?php
$lang['L_LOG_DELETE']="delete Log";
$lang['L_LOGFILEFORMAT']="Log file format";
$lang['L_LOGFILENOTWRITABLE']="Can't write Log file !";
$lang['L_NOREVERSE']="Oldest entry first";
$lang['L_REVERSE']="Last entry first";


?>