<?php



/**

 * ECSHOP 文章分类

 * ============================================================================

 * * 版权所有 2005-2012 上海商派网络科技有限公司，并保留所有权利。

 * 网站地址: http://www.ecshop.com；

 * ----------------------------------------------------------------------------

 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和

 * 使用；不允许对程序代码以任何形式任何目的的再发布。

 * ============================================================================

 * $Author: liubo $

 * $Id: article_cat.php 17217 2011-01-19 06:29:08Z liubo $

*/





define('IN_ECS', true);



require(dirname(__FILE__) . '/includes/init.php');



if ((DEBUG_MODE & 2) != 2)

{

    $smarty->caching = true;

}



/* 清除缓存 */

clear_cache_files();



/*------------------------------------------------------ */

//-- INPUT

/*------------------------------------------------------ */



/* 获得指定的分类ID */

if (!empty($_GET['id']))

{

    $cat_id = intval($_GET['id']);

}

elseif (!empty($_GET['category']))

{

    $cat_id = intval($_GET['category']);

}

/* 代码增加_start  By thunje#URLdf */

elseif(!empty($_REQUEST['defurl']))

{

	$define_url=trim($_REQUEST['defurl']);

	$cat_id=$db->getOne("select cat_id from ". $ecs->table('article_cat') ." where define_url='$define_url'  limit 0,1");

	$cat_id=$cat_id ? $cat_id : intval($define_url);



}

/* 代码增加_end  By thunje#URLdf */

else

{

    ecs_header("Location: ./\n");



    exit;

}



/* 获得当前页码 */

$page   = !empty($_REQUEST['page'])  && intval($_REQUEST['page'])  > 0 ? intval($_REQUEST['page'])  : 1;



/*------------------------------------------------------ */

//-- PROCESSOR

/*------------------------------------------------------ */



/* 获得页面的缓存ID */

$cache_id = sprintf('%X', crc32($cat_id . '-' . $page . '-' . $_CFG['lang']));



if (!$smarty->is_cached('article_cat.dwt', $cache_id))

{

    /* 如果页面没有被缓存则重新获得页面的内容 */



    assign_template('a', array($cat_id));

    $position = assign_ur_here($cat_id);

    

    $smarty->assign('ur_here',              $position['ur_here']);   // 当前位置



    $smarty->assign('categories',           get_categories_tree(0)); // 分类树

    $smarty->assign('article_categories',   article_categories_tree($cat_id)); //文章分类树

    $smarty->assign('helps',                get_shop_help());        // 网店帮助

    $smarty->assign('top_goods',            get_top10());            // 销售排行



    $smarty->assign('best_goods',           get_recommend_goods('best'));

    $smarty->assign('new_goods',            get_recommend_goods('new'));

    $smarty->assign('hot_goods',            get_recommend_goods('hot'));

    $smarty->assign('promotion_goods',      get_promote_goods());

    $smarty->assign('promotion_info', get_promotion_info());

   $smarty->assign('article_categories5',   get_categories_tree5()); //文章分类树

   $smarty->assign('newarticles',index_new_articles(10));

   

   	$smarty->assign('hotgoods',		   get_search_hotgoods());  //热销产品

	

	$smarty->assign('xiangguangoods',		   get_search_xiangguangoods()); //相关产品

	

    /* Meta */

    $meta = $db->getRow("SELECT keywords, cat_desc,ar_title FROM " . $ecs->table('article_cat') . " WHERE cat_id = '$cat_id'");



    if ($meta === false || empty($meta))

    {

        /* 如果没有找到任何记录则返回首页 */

        ecs_header("Location: ./\n");

        exit;

    }



    $smarty->assign('keywords',    htmlspecialchars($meta['keywords']));

    $smarty->assign('description', htmlspecialchars($meta['cat_desc']));

     $smarty->assign('page_title',           $meta['ar_title']);     // 页面标题

    /* 获得文章总数 */

    $size   = isset($_CFG['article_page_size']) && intval($_CFG['article_page_size']) > 0 ? intval($_CFG['article_page_size']) : 20;

    $count  = get_article_count($cat_id);

    $pages  = ($count > 0) ? ceil($count / $size) : 1;



    if ($page > $pages)

    {

        $page = $pages;

    }

    $pager['search']['id'] = $cat_id;

    $keywords = '';

    $goon_keywords = ''; //继续传递的搜索关键词



    /* 获得文章列表 */

    if (isset($_REQUEST['keywords']))

    {

        $keywords = addslashes(htmlspecialchars(urldecode(trim($_REQUEST['keywords']))));

        $pager['search']['keywords'] = $keywords;

        $search_url = substr(strrchr($_POST['cur_url'], '/'), 1);



        $smarty->assign('search_value',    stripslashes(stripslashes($keywords)));

        $smarty->assign('search_url',       $search_url);

        $count  = get_article_count($cat_id, $keywords);

        $pages  = ($count > 0) ? ceil($count / $size) : 1;

        if ($page > $pages)

        {

            $page = $pages;

        }



        $goon_keywords = urlencode($_REQUEST['keywords']);

    }

    $smarty->assign('artciles_list',    get_cat_articles($cat_id, $page, $size ,$keywords));

    $smarty->assign('cat_id',    $cat_id);

    /* 分页 */

    assign_pager('article_cat', $cat_id, $count, $size, '', '', $page, $goon_keywords);

    assign_dynamic('article_cat');

}



$smarty->assign('feed_url',         ($_CFG['rewrite'] == 1) ? "feed-typearticle_cat" . $cat_id . ".xml" : 'feed.php?type=article_cat' . $cat_id); // RSS URL



$smarty->display('article_cat.dwt', $cache_id);







//2012-4-7

//文章方法

function index_new_articles($cat_num)

{

	

$sql = "SELECT article_id, title,open_type,cat_id,file_url,description,content,keywords FROM " .$GLOBALS['ecs']->table



('article'). " WHERE cat_id>2  and is_open = 1 and article_type=0 ORDER BY article_id desc LIMIT " . $cat_num;

$res = $GLOBALS['db']->getAll($sql);

$arr = array();

foreach ($res AS $idx => $row)

{

       $arr[$idx]['id']       = $row['article_id'];

       $arr[$idx]['title']    = $row['title'];

	    $arr[$idx]['content']    = $row['content'];

		

		$arr[$idx]['keywords']    = $row['keywords'];

		

		$arr[$idx]['cat_name'] = get_articlecat($row['cat_id']);

		

       $arr[$idx]['short_title'] = $GLOBALS['_CFG']['article_title_length'] > 0 ?

                                    sub_str($row['title'], $GLOBALS['_CFG']



['article_title_length']) : $row['title'];

									

      

	   

	   $arr[$idx]['description'] = $row['description'];

       $arr[$idx]['add_time'] = local_date($GLOBALS['_CFG']['date_format'], $row['add_time']);

       $arr[$idx]['url']       =build_uri('article', array('aid' => $row['article_id']));

	   

       $arr[$idx]['cat_url']     = build_uri('article_cat', array('acid' => $row['cat_id']));

}

return $arr;

}







/*热销产品调用*/

function get_search_hotgoods(){

$sql = 'SELECT g.goods_id, g.goods_name, g.goods_thumb,g.goods_img, g.shop_price, g.market_price ' .

            'FROM ' . $GLOBALS['ecs']->table('goods') . ' AS g ' .

			"LEFT JOIN " . $GLOBALS['ecs']->table('category') . " AS gc " .

                    "ON gc.cat_id = g.cat_id " .

            "WHERE  g.is_on_sale =1 AND g.is_alone_sale =1  AND g.is_delete =0 AND g.is_hot =1" .

			" ORDER BY g.last_update DESC " .

            " LIMIT 3";

	//echo $sql;		

    $res = $GLOBALS['db']->query($sql);

    $arr = array();

    while ($row = $GLOBALS['db']->fetchRow($res))

    {

        $arr[$row['goods_id']]['goods_id']     = $row['goods_id'];

        $arr[$row['goods_id']]['goods_name']   = $row['goods_name'];

        $arr[$row['goods_id']]['short_name']   = $GLOBALS['_CFG']['goods_name_length'] > 0 ?

            sub_str($row['goods_name'], $GLOBALS['_CFG']['goods_name_length']) : $row['goods_name'];

        $arr[$row['goods_id']]['goods_thumb']  = get_image_path($row['goods_id'], $row['goods_thumb'], true);

        $arr[$row['goods_id']]['goods_img']    = get_image_path($row['goods_id'], $row['goods_img']);

        $arr[$row['goods_id']]['market_price'] = price_format($row['market_price']);

        $arr[$row['goods_id']]['shop_price']   = price_format($row['shop_price']);

        $arr[$row['goods_id']]['url']          = build_uri('goods', array('gid'=>$row['goods_id']), $row['goods_name']);

$sqlmember="SELECT rank_id, IFNULL(m.user_price, u.discount * ".$row['shop_price']." / 100) AS price, u.rank_name, u.discount from " .$GLOBALS['ecs']->table('user_rank') ." as u";

$sqlmember.=" left join " .$GLOBALS['ecs']->table('member_price')." as m on u.rank_id=m.user_rank and m.goods_id= ".$row['goods_id'];

$sqlmember.=" where u.show_price = 1 ";

$resmember=$GLOBALS['db']->getALL($sqlmember);

foreach($resmember as $key=>$value){

$arr[$row['goods_id']]['rank'][$key]['rand_name']=$value['rank_name'];

$arr[$row['goods_id']]['rank'][$key]['rand_price']=price_format($value['price']); 

}

    }



    return $arr;	

}





/*相关产品调用*/

function get_search_xiangguangoods(){

$sql = 'SELECT g.goods_id, g.goods_name, g.goods_thumb,g.goods_img, g.shop_price, g.market_price ' .

            'FROM ' . $GLOBALS['ecs']->table('goods') . ' AS g ' .

			"LEFT JOIN " . $GLOBALS['ecs']->table('category') . " AS gc " .

                    "ON gc.cat_id = g.cat_id " .

            "WHERE  g.is_on_sale =1 AND g.is_alone_sale =1  AND g.is_delete =0 " .

			" ORDER BY  g.goods_id desc " .

            " LIMIT 2";

	//echo $sql;		

    $res = $GLOBALS['db']->query($sql);

    $arr = array();

    while ($row = $GLOBALS['db']->fetchRow($res))

    {

        $arr[$row['goods_id']]['goods_id']     = $row['goods_id'];

        $arr[$row['goods_id']]['goods_name']   = $row['goods_name'];

        $arr[$row['goods_id']]['short_name']   = $GLOBALS['_CFG']['goods_name_length'] > 0 ?

            sub_str($row['goods_name'], $GLOBALS['_CFG']['goods_name_length']) : $row['goods_name'];

        $arr[$row['goods_id']]['goods_thumb']  = get_image_path($row['goods_id'], $row['goods_thumb'], true);

        $arr[$row['goods_id']]['goods_img']    = get_image_path($row['goods_id'], $row['goods_img']);

        $arr[$row['goods_id']]['market_price'] = price_format($row['market_price']);

        $arr[$row['goods_id']]['shop_price']   = price_format($row['shop_price']);

        $arr[$row['goods_id']]['url']          = build_uri('goods', array('gid'=>$row['goods_id']), $row['goods_name']);

$sqlmember="SELECT rank_id, IFNULL(m.user_price, u.discount * ".$row['shop_price']." / 100) AS price, u.rank_name, u.discount from " .$GLOBALS['ecs']->table('user_rank') ." as u";

$sqlmember.=" left join " .$GLOBALS['ecs']->table('member_price')." as m on u.rank_id=m.user_rank and m.goods_id= ".$row['goods_id'];

$sqlmember.=" where u.show_price = 1 ";

$resmember=$GLOBALS['db']->getALL($sqlmember);

foreach($resmember as $key=>$value){

$arr[$row['goods_id']]['rank'][$key]['rand_name']=$value['rank_name'];

$arr[$row['goods_id']]['rank'][$key]['rand_price']=price_format($value['price']); 

}

    }



    return $arr;	

}

?>