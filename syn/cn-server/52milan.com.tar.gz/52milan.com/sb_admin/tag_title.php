<?php



/**

 * ECSHOP 友情链接管理

 * ============================================================================

 * 版权所有 2005-2010 上海商派网络科技有限公司，并保留所有权利。

 * 网站地址: http://www.ecshop.com；

 * ----------------------------------------------------------------------------

 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和

 * 使用；不允许对程序代码以任何形式任何目的的再发布。

 * ============================================================================

 * $Author: liuhui $

 * $Id: friend_link.php 17063 2010-03-25 06:35:46Z liuhui $

*/



define('IN_ECS', true);



require(dirname(__FILE__) . '/includes/init.php');

include_once(ROOT_PATH . 'includes/cls_image.php');

$image = new cls_image($_CFG['bgcolor']);



$exc = new exchange($ecs->table('friend_link'), $db, 'link_id', 'link_name');



/* act操作项的初始化 */

if (empty($_REQUEST['act']))

{

    $_REQUEST['act'] = 'list';

}

else

{

    $_REQUEST['act'] = trim($_REQUEST['act']);

}



/*------------------------------------------------------ */

//-- 友情链接列表页面

/*------------------------------------------------------ */

if ($_REQUEST['act'] == 'list')

{

    /* 模板赋值 */

    /*$smarty->assign('ur_here',     $_LANG['list_title']);

    $smarty->assign('action_link', array('text' => $_LANG['add_title'], 'href' => '=tag_title.php?act=add'));*/

     $smarty->assign('full_page',   1);



    /* 获取友情链接数据 */

    $links_list = get_tag_list();



    $smarty->assign('links_list',      $links_list['list']);

    $smarty->assign('filter',          $links_list['filter']);

    $smarty->assign('record_count',    $links_list['record_count']);

    $smarty->assign('page_count',      $links_list['page_count']);



    $sort_flag  = sort_flag($links_list['filter']);

    $smarty->assign($sort_flag['tag'], $sort_flag['img']);



    assign_query_info();

    $smarty->display('tag_list.htm');

}



/*------------------------------------------------------ */

//-- 排序、分页、查询

/*------------------------------------------------------ */

elseif ($_REQUEST['act'] == 'query')

{

    /* 获取友情链接数据 */

    $links_list = get_tag_list();



    $smarty->assign('links_list',      $links_list['list']);

    $smarty->assign('filter',          $links_list['filter']);

    $smarty->assign('record_count',    $links_list['record_count']);

    $smarty->assign('page_count',      $links_list['page_count']);



    $sort_flag  = sort_flag($links_list['filter']);

    $smarty->assign($sort_flag['tag'], $sort_flag['img']);



    make_json_result($smarty->fetch('tag_list.htm'), '',

        array('filter' => $links_list['filter'], 'page_count' => $links_list['page_count']));

}



/*------------------------------------------------------ */

//-- 添加新链接页面

/*------------------------------------------------------ */

elseif ($_REQUEST['act'] == 'add')

{

    admin_priv('friendlink');



    $smarty->assign('ur_here',     $_LANG['add_link']);

    $smarty->assign('action_link', array('href'=>'friend_link.php?act=list', 'text' => $_LANG['list_link']));

    $smarty->assign('action',      'add');

    $smarty->assign('form_act',    'insert');



    assign_query_info();

    $smarty->display('tag_info.htm');

}



/*------------------------------------------------------ */

//-- 处理添加的链接

/*------------------------------------------------------ */

elseif ($_REQUEST['act'] == 'insert')

{

    /* 变量初始化 */

  

$typeid =$_POST['typeid'];
$tag =$_POST['tag'];
$title = $_POST['title'];
$keywords = $_POST['keywords'];
$description =$_POST['description'];

$goodsdesc =$_POST['goodsdesc'];

    /* 查看链接名称是否有重复 */

    if ($tag!='')

    {

        

        /* 插入数据 */

        $sql    = "INSERT INTO ".$ecs->table('title')." (typeid, tag, title, keywords,description,goodsdesc) ".

                  "VALUES ('$typeid', '$tag', '$title', '$keywords', '$description','$goodsdesc')";

        $db->query($sql);



        /* 记录管理员操作 */

        //admin_log($_POST['link_name'], 'add', 'friendlink');



        /* 清除缓存 */

        clear_cache_files();



        /* 提示信息 */

        $link[0]['text'] = $_LANG['continue_add'];

        $link[0]['href'] = 'tag_title.php?act=add';



        $link[1]['text'] = $_LANG['back_list'];

        $link[1]['href'] = 'tag_title.php?act=list';



        sys_msg($_LANG['add'] . "&nbsp;" .stripcslashes($_POST['tag']) . " " . $_LANG['attradd_succed'],0, $link);



    }

    else

    {

        $link[] = array('text' => $_LANG['go_back'], 'href'=>'javascript:history.back(-1)');

        sys_msg($_LANG['link_name_exist'], 0, $link);

    }

}



/*------------------------------------------------------ */

//-- 友情链接编辑页面

/*------------------------------------------------------ */

elseif ($_REQUEST['act'] == 'edit')

{

   


    /* 取得友情链接数据 */

   $sql = "SELECT * ".

           "FROM " .$ecs->table('title'). " WHERE id = '".intval($_REQUEST['id'])."'";

    $link_arr = $db->getRow($sql);



   
$smarty->assign('form_act',    'update');




    /* 模板赋值 */


    $smarty->assign('link_arr',    $link_arr);



    assign_query_info();

    $smarty->display('tag_info.htm');

}



/*------------------------------------------------------ */

//-- 编辑链接的处理页面

/*------------------------------------------------------ */

elseif ($_REQUEST['act'] == 'update')

{

    /* 变量初始化 */

    $id         = (!empty($_REQUEST['id']))      ? intval($_REQUEST['id'])      : 0;


$typeid = $_REQUEST['typeid'];
$tag =$_REQUEST['tag'];
$title = $_REQUEST['title'];
$keywords =$_REQUEST['keywords'];
$description =$_REQUEST['description'];
 $goodsdesc =$_REQUEST['goodsdesc'];




    /* 更新信息 */

    $sql = "UPDATE " .$ecs->table('title'). " SET ".

            "typeid = '$typeid', ".

            "tag = '$tag',".
			"title = '$title' ,".
			
            "keywords = '$keywords' ,".
			
             "description = '$description' ,".
			 
			 "goodsdesc = '$goodsdesc' ".

            "WHERE id = '$id'";



    $db->query($sql);

    /* 记录管理员操作 */

    //admin_log($_POST['link_name'], 'edit', 'friendlink');



    /* 清除缓存 */

    clear_cache_files();



    /* 提示信息 */

    $link[0]['text'] = $_LANG['back_list'];

    $link[0]['href'] = 'tag_title.php?act=list&' . list_link_postfix();



    sys_msg($_LANG['edit'] . "&nbsp;" .stripcslashes($_POST['tag']) . "&nbsp;" . $_LANG['attradd_succed'],0, $link);

}



/*------------------------------------------------------ */

//-- 编辑链接名称

/*------------------------------------------------------ */

elseif ($_REQUEST['act'] == 'edit_link_name')

{

    check_authz_json('friendlink');



    $id        = intval($_POST['id']);

    $link_name = json_str_iconv(trim($_POST['val']));



    /* 检查链接名称是否重复 */

    if ($exc->num("link_name", $link_name, $id) != 0)

    {

        make_json_error(sprintf($_LANG['link_name_exist'], $link_name));

    }

    else

    {

        if ($exc->edit("link_name = '$link_name'", $id))

        {

            admin_log($link_name, 'edit', 'friendlink');

            clear_cache_files();

            make_json_result(stripslashes($link_name));

        }

        else

        {

            make_json_error($db->error());

        }

    }

}



/*------------------------------------------------------ */

//-- 删除友情链接

/*------------------------------------------------------ */

elseif ($_REQUEST['act'] == 'remove')

{

    //check_authz_json('friendlink');



    $id = intval($_GET['id']);



   



    //$exc->drop($id);

    $sql = "DELETE FROM " .$ecs->table('title'). " WHERE id = '$id'";

    $db->query($sql);

    clear_cache_files();



    $url = 'tag_title.php?act=query&' . str_replace('act=remove', '', $_SERVER['QUERY_STRING']);



    ecs_header("Location: $url\n");

    exit;

}



/*------------------------------------------------------ */

//-- 编辑排序

/*------------------------------------------------------ */

elseif ($_REQUEST['act'] == 'edit_show_order')

{

    check_authz_json('friendlink');



    $id    = intval($_POST['id']);

    $order = json_str_iconv(trim($_POST['val']));



    /* 检查输入的值是否合法 */

    if (!preg_match("/^[0-9]+$/", $order))

    {

        make_json_error(sprintf($_LANG['enter_int'], $order));

    }

    else

    {

        if ($exc->edit("show_order = '$order'", $id))

        {

            clear_cache_files();

            make_json_result(stripslashes($order));

        }

    }

}



/* 获取友情链接数据列表 */

function get_tag_list()

{

    $result = get_filter();

    if ($result === false)

    {

        $filter = array();

        $filter['sort_by']    = empty($_REQUEST['sort_by']) ? 'id' : trim($_REQUEST['sort_by']);

        $filter['sort_order'] = empty($_REQUEST['sort_order']) ? 'DESC' : trim($_REQUEST['sort_order']);



        /* 获得总记录数据 */

        $sql = 'SELECT COUNT(*) FROM ' .$GLOBALS['ecs']->table('title');

        $filter['record_count'] = $GLOBALS['db']->getOne($sql);



        $filter = page_and_size($filter);



        /* 获取数据 */

        $sql  = 'SELECT  *'.

               ' FROM ' .$GLOBALS['ecs']->table('title').

                " ORDER by $filter[sort_by] $filter[sort_order]";



        set_filter($filter, $sql);

    }

    else

    {

        $sql    = $result['sql'];

        $filter = $result['filter'];

    }

    $res = $GLOBALS['db']->selectLimit($sql, $filter['page_size'], $filter['start']);



    $list = array();

    while ($rows = $GLOBALS['db']->fetchRow($res))

    {

        if (empty($rows['link_logo']))

        {

            $rows['link_logo'] = '';

        }

        else

        {

            if ((strpos($rows['link_logo'], 'http://') === false) && (strpos($rows['link_logo'], 'https://') === false))

            {

                $rows['link_logo'] = "<img src='" .'../'.$rows['link_logo']. "' width=88 height=31 />";

            }

            else

            {

                $rows['link_logo'] = "<img src='".$rows['link_logo']."' width=88 height=31 />";

            }

        }



        $list[] = $rows;

    }



    return array('list' => $list, 'filter' => $filter, 'page_count' => $filter['page_count'], 'record_count' => $filter['record_count']);

}



?>