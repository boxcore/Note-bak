<?php

/**
 * ECSHOP 文章分类
 * ============================================================================
 * 版权所有 2005-2010 上海商派网络科技有限公司，并保留所有权利。
 * 网站地址: http://www.ecshop.com；
 * ----------------------------------------------------------------------------
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和
 * 使用；不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * $Author: sxc_shop $
 * $Id: article_cat.php 17074 2010-03-26 10:38:21Z sxc_shop $
*/


define('IN_ECS', true);

require(dirname(__FILE__) . '/includes/init.php');

if ((DEBUG_MODE & 2) != 2)
{
    $smarty->caching = true;
}

/* 清除缓存 */
clear_cache_files();

/*------------------------------------------------------ */
//-- INPUT
/*------------------------------------------------------ */

 /* 商品分类 foreach 循环数组 */
     $sql = "SELECT cat_id,cat_name FROM " .$ecs->table('category'). " ORDER BY parent_id";
     $res = $GLOBALS['db']->getAll($sql);
     $categoryarr=array();
     foreach ($res AS $idx => $row)
	 {
      
		$categoryarr[$idx]['cat_name']=$row['cat_name'];
		$categoryarr[$idx]['url']="$site_url/" . build_uri('category', array('cid' => $row['cat_id']), $row['cat_name']);
    }
      $smarty->assign('categories',      get_categories_tree()); // 分类树
	 //$smarty->assign('categorylist', $categoryarr);
	 $smarty->assign('article_categories',   get_categories_tree3()); //文章分类树
	 
	    /* 文章分类 */
     $sqlact = "SELECT cat_id,cat_name FROM " .$ecs->table('article_cat'). " ";
	 $resact = $GLOBALS['db']->getAll($sqlact);
     $arctyarr=array();
     foreach ($resact AS $idx => $row)
	 {
       
       
	    $arctyarr[$idx]['cat_name']=$row['cat_name'];
		$arctyarr[$idx]['url']="$site_url/" . build_uri('article_cat', array('acid' => $row['cat_id']), $row['cat_name']);
	  }
	  $smarty->assign('actlist', $arctyarr);
	  
	  
	  
	   /* 商品 */
    $goodssql = "SELECT goods_id, goods_name, last_update FROM " .$ecs->table('goods'). " WHERE is_delete = 0 ORDER BY goods_id desc LIMIT 30";
    $resgoods = $GLOBALS['db']->getAll($goodssql);
     $goodsarr=array();
     foreach ($resgoods AS $idx => $row)
     {
 
        $goodsarr[$idx]['goods_name']=$row['goods_name'];
		$goodsarr[$idx]['url']="$site_url/" . build_uri('goods', array('gid' => $row['goods_id']), $row['goods_name']);
    }
	$smarty->assign('goodslist', $goodsarr); 
	
	    /* 文章 */
    $articlesql = "SELECT article_id,title,file_url,open_type, add_time FROM " .$ecs->table('article'). " WHERE is_open=1 ORDER BY article_id desc limit 30";
     $resarticle = $GLOBALS['db']->getAll($articlesql);
     $articlearr=array();
     foreach ($resarticle AS $idx => $row)
    {
   
		 $articlearr[$idx]['title']=$row['title'];
		$articlearr[$idx]['url']=$row['open_type'] != 1 ? build_uri('article', array('aid'=>$row['article_id']), $row['title']) : trim($row['file_url']);
      
    }
$smarty->assign('articlelist', $articlearr); 
$smarty->display('sitemap.dwt');	 

?>