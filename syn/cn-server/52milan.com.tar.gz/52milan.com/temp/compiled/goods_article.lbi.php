<?php if ($this->_var['goods_article_list']): ?>
<div id="news_list">
  <div class="tab">
    <ul>
      <li class="cur">相关文章</li>
    </ul>
  </div>
  <div class="page cur">
    <ul>
      <?php $_from = $this->_var['goods_article_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'article');if (count($_from)):
    foreach ($_from AS $this->_var['article']):
?>
      <li><a href="<?php echo $this->_var['article']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['article']['title']); ?>" rel="nofollow"><?php echo sub_str($this->_var['article']['title'],13); ?></a></li>
      <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </ul>
  </div>
</div>
<div class="blank5"></div>
<?php endif; ?>
