<?php if ($this->_var['top_goods']): ?>  
<div id="hot_sale">
        	<div class="l__hot_sale"></div>
            <ul>
            <?php $_from = get_top10(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'goodss');$this->_foreach['top_goods'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['top_goods']['total'] > 0):
    foreach ($_from AS $this->_var['goodss']):
        $this->_foreach['top_goods']['iteration']++;
?>  
			  <li>
                	<a href="/<?php echo $this->_var['goodss']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['goodss']['short_name']); ?>" target="_blank" class="img"><img src="<?php echo $this->_var['goodss']['thumb']; ?>" alt="<?php echo htmlspecialchars($this->_var['goodss']['short_name']); ?>">
                               <?php if ($this->_foreach['top_goods']['iteration'] < 4): ?><span class="rank no<?php echo ($this->_foreach['top_goods']['iteration'] - 1); ?>"></span><?php endif; ?>
                                        </a>
                	<a href="/<?php echo $this->_var['goodss']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['goodss']['short_name']); ?>" target="_blank" class="txt"><?php echo htmlspecialchars($this->_var['goodss']['short_name']); ?></a>
                    <span class="price"><?php echo $this->_var['goodss']['price']; ?></span>
            </li>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
             </ul>
        </div>
   <div class="blank5"></div> 
<?php endif; ?>  