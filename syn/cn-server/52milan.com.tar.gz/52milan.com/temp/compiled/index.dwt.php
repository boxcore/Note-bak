<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<base href="http://www.52milan.com/" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="<?php echo $this->_var['keywords']; ?>" />
<meta name="Description" content="<?php echo $this->_var['description']; ?>" />
<title><?php echo $this->_var['page_title']; ?></title>
<link rel="shortcut icon" href="favicon.ico" />
<link href="<?php echo $this->_var['ecs_css_path']; ?>" rel="stylesheet" type="text/css" />
<link href="/themes/wbw2012/home.css" rel="stylesheet" type="text/css" />
<link href="/themes/wbw2012/baobao.css" rel="stylesheet" type="text/css" />
<link rel="alternate" type="application/rss+xml" title="RSS|<?php echo $this->_var['page_title']; ?>" href="<?php echo $this->_var['feed_url']; ?>" />
<link rel="stylesheet" type="text/css" href="/themes/wbw2012/index.css" media="all" />

<?php echo $this->smarty_insert_scripts(array('files'=>'common.js')); ?>
<script type="text/javascript" src="/js/jquery-1.4.4.min.js" ></script>
<script type="text/javascript" src="/themes/wbw2012/js/all.js"></script>
<script type="text/javascript" src="/themes/wbw2012/js/index.js"></script>
<script type="text/javascript" src="/themes/wbw2012/js/beand.js"></script>
<script type="text/javascript" src="/themes/wbw2012/js/globals.js"></script>

<script type="text/javascript">
cats_in_index = true;
is_ie67 = false;
</script>

<style type="text/css">
/* maxwidth limit for content images */
#content img, .content img, .archive img, .post img {
	margin-top:3px;
	max-width:600px;
_width:expression(this.width>600?600:auto);
}
/* style for slideshow images */
.slideshow_imgs {
	cursor:url(/zoomin.cur), pointer;
}
.slideshow_imgs:hover {
	opacity:0.5;
	filter:alpha(opacity=50);
}
</style>


<style type="text/css">
.lh_lazyimg {
	opacity:0.2;
	filter:alpha(opacity=20);
	background:url(/placeholder.png) no-repeat center center;
}
</style>


<noscript>
<style type="text/css">
.lh_lazyimg {
	display:none;
}
</style>
</noscript>


<script type="text/javascript">
jQuery(document).ready(function($) {
	function lazyload(){
		$("img.lh_lazyimg").each(function(){
			_self = $(this);
			if (_self.attr("lazyloadpass")===undefined
					&& _self.attr("file")
					&& (!_self.attr("src")
							|| (_self.attr("src") && _self.attr("file")!=_self.attr("src"))
						)
				) {
				if((_self.offset().top) < $(window).height()+$(document).scrollTop()
						&& (_self.offset().left) < $(window).width()+$(document).scrollLeft()
					) {
					_self.attr("src",_self.attr("file"));
					_self.attr("lazyloadpass", "1");
					_self.animate({opacity:1}, 500);
				}
			}
		});
	}
	lazyload();

	var itv;
	$(window).scroll(function(){clearTimeout(itv);itv=setTimeout(lazyload,200);});
	$(window).resize(function(){clearTimeout(itv);itv=setTimeout(lazyload,200);});
});
</script>

<!--<script type="text/javascript"> 


$(document).ready(function() {  
       $(".dt_small a img").each(function(i) {  
         $(this).width("100%");  
       });  
   });

$(document).ready(function() {  
       $(".dt_big a img").each(function(i) {  
         $(this).width("100%");  
       });  
   }); 

</script>-->
<?php 
   require_once("themes/".$GLOBALS['_CFG']['template']."/diyfile.php");
   $this->assign('TemplatePath','themes/'.$GLOBALS['_CFG']['template']);
?>
</head><body onload="datasrc();">

<?php echo $this->fetch('library/index_header.lbi'); ?>
<div id="main">
  <div class="fcSlider" id="focus_ad">
    <ul>
      <li class="cur" rel="0" style="display: list-item;"><a target="_blank" title="LV" href="/lv/"><img alt="LV" src1="/images/tm.png" src="/data/afficheimg/20121229glxhpo.jpg"></a></li>
      <li rel="1" class="" style="display: none;"><a target="_blank" title="香奈儿" href="/chanel/"><img alt="香奈儿" src="/images/tm.png" data-src="/data/afficheimg/20121229etfqnh.jpg"></a></li>
      <li rel="2" class="" style="display: none;"><a target="_blank" title="爱马仕" href="/hermes/"><img alt="爱马仕" src="/images/tm.png" data-src="/data/afficheimg/20121229qzvcsf.jpg"></a></li>
    </ul>
    <div> <span> <a class="cur" title="LV" href="javascript:void(0);" rel="0">1</a> <a title="香奈儿" href="javascript:void(0);" rel="1" class="">2</a> <a title="爱马仕" href="javascript:void(0);" rel="2" class="">3</a> </span> </div>
  </div>
  <div class="ad_left"> <a target="_blank" href="/bvpidai/"> <img width="287" height="118" border="0" src="/ad/ad2.jpg"></a> <a target="_blank" href="/chanel/"><img width="287" height="118" border="0" src="/ad/ad3.jpg"></a>
    <div>
      <ul>
        <?php $_from = $this->_var['new_articles']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'article');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['article']):
        $this->_foreach['curn']['iteration']++;
?>
        <li><a href="<?php echo $this->_var['article']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['article']['title']); ?>" <?php if ($this->_foreach['curn']['iteration'] == 1 || $this->_foreach['curn']['iteration'] == 3): ?> class="red"<?php endif; ?> ><?php echo $this->_var['article']['short_title']; ?></a></li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
  </div>
</div>
<div class="floor floor-2 lazybox">
  <div class="f-title clearfix">
    <h3 class="name"><a target="_blank" href="javascript:;"></a></h3>
    <div class="brand">
      
      <span class="txt">热门品牌推荐：</span>
      <ul class="item">
        <li><a target="_blank" href="/ding-b100/" title="LV路易威登">LV路易威登</a></li>
        <li><a target="_blank" href="/ding-b101/" title="Hermes爱马仕">Hermes爱马仕</a></li>
        <li><a target="_blank" href="/ding-b102/" title="prada普拉达">prada普拉达</a></li>
        <li><a target="_blank" href="/ding-b103/" title="gucci古奇">gucci古奇</a></li>
        <li><a target="_blank" href="/ding-b104/" title="chanel香奈儿">chanel香奈儿</a></li>
        <li><a target="_blank" href="/ding-b105/" title="miumiu缪缪">miumiu缪缪</a></li>
        <li><a target="_blank" href="/ding-b106/" title="burberry巴宝莉">burberry巴宝莉</a></li>
      </ul>
      
    </div>
  </div>
  <div class="f-main clearfix">
    <div class="left-part clearfix">
      <dl class="f-cate">
        <dt>人群</dt>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/nanshibao/" title="男士包包"><font color="red">男士包包</font> </a></dd>
        <dd class=""><span class="f-point"></span><a class="c-item" target="_blank" href="/nvshibao/" title="女士包包">女士包包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr2421-0-0-0-0-0-0-0-0-0-0/" title="中性包包">中性包包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr1874-0-0-0-0-0-0-0-0-0-0/" title="男士钱包">男士钱包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr2090-0-0-0-0-0-0-0-0-0-0/" title="女士钱包"><font color="red">女士钱包</font> </a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr1846-0-0-0-0-0-0-0-0-0-0/" title="中性钱包">中性钱包</a></dd>
      </dl>
      <dl class="f-cate ">
        <dt>基本款式</dt>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-2355-0-0-0-0-0-0-0-0/" title="单肩包">单肩包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-1887-0-0-0-0-0-0-0-0/" title="斜挎包">斜挎包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-1847-0-0-0-0-0-0-0-0/" title="手提包">手提包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-6809-0-0-0-0-0-0-0-0/" title="多用包">多用包</a></dd>
      </dl>
      <dl class="f-cate  last">
        <dt>用途</dt>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-5619-0-0-0-0-0-0-0-0/" title="公文包">公文包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-6429-0-0-0-0-0-0-0-0/" title="旅行包">旅行包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-7628-0-0-0-0-0-0-0-0/" title="购物袋">购物袋</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-7588-0-0-0-0-0-0-0-0/" title="钥匙扣">钥匙扣</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-1844-0-0-0-0-0-0-0-0/" title="双用包">双用包</a></dd>
      </dl>
    </div>
    
    <div class="center-part">
      <div class="slidebox-01">
        <ul class="slidepic-01">
          <li><a href="/lv"><img width="576" height="300" alt="包包" src="/ad/ad6.jpg" /></a></li>
          <li><a href="/hermes/"><img width="576" height="300" alt="包包" src="/images/tm.png" data-src="/ad/ad7.jpg" /></a></li>
          <li><a href="/bv/"><img width="576" height="300" alt="包包" src="/images/tm.png" data-src="/ad/ad8.jpg" /></a></li>
        </ul>
        <div class="slidebtn-01">
          <ul>
            <li class="current">1</li>
            <li>2</li>
            <li>3</li>
          </ul>
        </div>
      </div>
    </div>
    
    
    <div class="right-part"> <a target="_blank" href="/ding/"><img width="230" height="300" title="" alt="" src="/ad/ad5.jpg"></a> </div>
    
  </div>
  
  <div class="pro_wrap" id="news1">
    <div class="tab">
      <ul>
        <li class="cur  t1"></li>
        <li class="t2"></li>
        <li class="t3"></li>
      </ul>
    </div>
    <div class="cur page">
      <ul class="pro_list clearfix">
        <?php $_from = $this->_var['cat1_hot_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'goods');$this->_foreach['gcurn2'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['gcurn2']['total'] > 0):
    foreach ($_from AS $this->_var['goods']):
        $this->_foreach['gcurn2']['iteration']++;
?>
        <li> <a target="_blank" class="pic" href="<?php echo $this->_var['goods']['url']; ?>"> <img  src="/placeholder.png" file="<?php echo $this->_var['goods']['thumb']; ?>" alt="<?php echo htmlspecialchars($this->_var['goods']['name']); ?>" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/<?php echo $this->_var['goods']['thumb']; ?>" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="<?php echo htmlspecialchars($this->_var['goods']['name']); ?>" class="name" target="_blank" href="<?php echo $this->_var['goods']['url']; ?>"><?php echo $this->_var['goods']['short_name']; ?></a>
            <div class="price">
              <?php if ($this->_var['goods']['promote_price'] != ""): ?>
              <span class="gray"><?php echo $this->_var['lang']['promote_price']; ?></span><strong class="red"><?php echo $this->_var['goods']['promote_price']; ?></strong>
              <?php else: ?>
              <span class="gray"><?php echo $this->_var['lang']['shop_price']; ?></span><strong class="red"><?php echo $this->_var['goods']['shop_price']; ?></strong>
              <?php endif; ?>
              <p class="red">
                <?php if ($_SESSION['user_rank'] > 1): ?>
                <?php $_from = $this->_var['goods']['rank']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'rank');if (count($_from)):
    foreach ($_from AS $this->_var['rank']):
?>
                <?php echo $this->_var['rank']['rank_name']; ?>:<?php echo $this->_var['rank']['rank_price']; ?>
                <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
                <?php else: ?>
                <img src="/ad/price.jpg" alt="批发请联系客服">
                <?php endif; ?>
              </P>
            </div>
          </div>
        </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
    <div class="page">
      <ul class="pro_list clearfix">
        <?php $_from = $this->_var['cat1_new_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'hotgoods');$this->_foreach['gcurn3'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['gcurn3']['total'] > 0):
    foreach ($_from AS $this->_var['hotgoods']):
        $this->_foreach['gcurn3']['iteration']++;
?>
        <li> <a target="_blank" class="pic" href="<?php echo $this->_var['hotgoods']['url']; ?>"><img width="200" height="200" src="/images/tm.png" data-src="<?php echo $this->_var['hotgoods']['thumb']; ?>" alt="<?php echo htmlspecialchars($this->_var['hotgoods']['name']); ?>" ></a>
          <div class="pro_info"> <a title="<?php echo htmlspecialchars($this->_var['hotgoods']['name']); ?>" class="name" target="_blank" href="<?php echo $this->_var['hotgoods']['url']; ?>"><?php echo $this->_var['hotgoods']['short_name']; ?></a>
            <div class="price">
              <?php if ($this->_var['hotgoods']['promote_price'] != ""): ?>
              <span class="gray"><?php echo $this->_var['lang']['promote_price']; ?></span><strong class="red"><?php echo $this->_var['hotgoods']['promote_price']; ?></strong>
              <?php else: ?>
              <span class="gray"><?php echo $this->_var['lang']['shop_price']; ?></span><strong class="red"><?php echo $this->_var['hotgoods']['shop_price']; ?></strong>
              <?php endif; ?>
              <p class="red">
                <?php if ($_SESSION['user_rank'] > 1): ?>
                <?php $_from = $this->_var['hotgoods']['rank']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'rank');if (count($_from)):
    foreach ($_from AS $this->_var['rank']):
?>
                <?php echo $this->_var['rank']['rank_name']; ?>:<?php echo $this->_var['rank']['rank_price']; ?>
                <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
                <?php else: ?>
               <img src="/ad/price.jpg" alt="批发请联系客服">
                <?php endif; ?>
              </P>
            </div>
          </div>
        </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
    <div class="page">
      <ul class="pro_list clearfix">
        <?php $_from = $this->_var['cat1_dingji_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'dingjigoods');$this->_foreach['gcurn5'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['gcurn5']['total'] > 0):
    foreach ($_from AS $this->_var['dingjigoods']):
        $this->_foreach['gcurn5']['iteration']++;
?>
        <li> <a target="_blank" class="pic" href="<?php echo $this->_var['dingjigoods']['url']; ?>"><img width="200" height="200" src="/images/tm.png" data-src="<?php echo $this->_var['dingjigoods']['thumb']; ?>" alt="<?php echo htmlspecialchars($this->_var['dingjigoods']['name']); ?>" ></a>
          <div class="pro_info"> <a title="<?php echo htmlspecialchars($this->_var['dingjigoods']['name']); ?>" class="name" target="_blank" href="<?php echo $this->_var['dingjigoods']['url']; ?>"><?php echo $this->_var['dingjigoods']['short_name']; ?></a>
            <div class="price">
              <?php if ($this->_var['dingjigoods']['promote_price'] != ""): ?>
              <span class="gray"><?php echo $this->_var['lang']['promote_price']; ?></span><strong class="red"><?php echo $this->_var['dingjigoods']['promote_price']; ?></strong>
              <?php else: ?>
              <span class="gray"><?php echo $this->_var['lang']['shop_price']; ?></span><strong class="red"><?php echo $this->_var['dingjigoods']['shop_price']; ?></strong>
              <?php endif; ?>
              <p class="red">
                <?php if ($_SESSION['user_rank'] > 1): ?>
                <?php $_from = $this->_var['dingjigoods']['rank']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'rank');if (count($_from)):
    foreach ($_from AS $this->_var['rank']):
?>
                <?php echo $this->_var['rank']['rank_name']; ?>:<?php echo $this->_var['rank']['rank_price']; ?>
                <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
                <?php else: ?>
                <img src="/ad/price.jpg" alt="批发请联系客服">
                <?php endif; ?>
              </P>
            </div>
          </div>
        </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
  </div>
  
</div>

<div class="w floorMap f3">
  <div class="floorHeader">
    <div  class="floorName" id="JS_hide_floor_menu_3">
      <div class="floorMenu">
        <ul class="catList">
          <li>• <a title="男士鞋子" target="_blank" href="/xiezi-attr15593-0-0-0-0-0-0-0-0-0-0/">男士鞋子</a></li>
          <li>• <a title="女士鞋子" target="_blank" href="/xiezi-attr21659-0-0-0-0-0-0-0-0-0-0/">女士鞋子</a></li>
          <li>• <a title="牛皮" target="_blank" href="/xiezi-attr0-0-0-4333-0-0-0-0-0-0-0/">牛皮</a></li>
          <li>• <a title="布配皮" target="_blank" href="/xiezi-attr0-0-0-4243-0-0-0-0-0-0-0/">布配皮</a></li>
        </ul>
        <h4>推荐品牌</h4>
        <ul class="brand">
          <li>
            <div class="inbox">
              <div class="img"><a title="LV路易威登 " target="_blank" href="/lvxiezi/"><img width="80" height="50" alt="LV路易威登 " data-src="/data/brandlogo/1357077708628288301.jpg" src="/images/tm.png" ></a></div>
              <p><a title="LV路易威登 " target="_blank" href="/lvxiezi/">LV路易威登 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="Hermes爱马仕" target="_blank" href="/hermesxie/"><img width="80" height="50" alt="Hermes爱马仕" data-src="/data/brandlogo/1357077911087601515.jpg" src="/images/tm.png"></a></div>
              <p><a title="Hermes爱马仕" target="_blank" href="/hermesxie/">Hermes爱马仕</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="prada普拉达 " target="_blank" href="/pradaxie/"><img width="80" height="50" alt="prada普拉达 " data-src="/data/brandlogo/1357077806274511679.jpg" src="/images/tm.png"></a></div>
              <p><a title="prada普拉达 " target="_blank" href="/pradaxie/">prada普拉达</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="burberry巴宝莉 " target="_blank" href="/burberrytyj/"><img width="80" height="50" alt="burberry巴宝莉" data-src="/data/brandlogo/1357078351404307774.jpg" src="/images/tm.png"></a></div>
              <p><a title="burberry巴宝莉 " target="_blank" href="/burberrytyj/">burberry巴宝莉</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="gucci古奇 " target="_blank" href="/guccixie/"><img width="80" height="50" alt="gucci古奇" data-src="/data/brandlogo/1357077959227874651.jpg" ssrc="/images/tm.png"></a></div>
              <p><a title="gucci古奇 " target="_blank" href="/guccixie/">gucci古奇</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="BV宝缇嘉 " target="_blank" href="/bvxiezi/"><img width="80" height="50" alt="BV宝缇嘉" data-src="/data/brandlogo/1357078740679832302.jpg" src="/images/tm.png"></a></div>
              <p><a title="BV宝缇嘉 " target="_blank" href="/bvxiezi/">BV宝缇嘉</a></p>
            </div>
          </li>
        </ul>
      </div>
      <a href="javascript:;" class="showName"></a> </div>
    <div class="floorLink">
      <div class="kw Left">热门推荐：<a title="时尚百搭" target="_blank" href="/xiezi-attr0-7208-0-0-0-0-0-0-0-0-0/">时尚百搭</a> <span class="line">|</span> <a title="潮流风格" target="_blank" href="/xiezi-attr0-7363-0-0-0-0-0-0-0-0-0/">潮流风格</a> <span class="line">|</span> <a title="甜美淑女" target="_blank" href="/xiezi-attr0-7246-0-0-0-0-0-0-0-0-0/">甜美淑女</a> <span class="line">|</span> <a title="经典商务" target="_blank" href="/xiezi-attr0-7203-0-0-0-0-0-0-0-0-0/">经典商务</a> 
      
      <span class="line">|</span> <a title="Hermes爱马仕鞋子" target="_blank" href="/xiezi-b100/">Hermes爱马仕鞋子</a>
      
      <span class="line">|</span> <a title="LV路易威登鞋子" target="_blank" href="/xiezi-b101/">LV路易威登鞋子</a>
      
      <span class="line">|</span> <a title="prada普拉达鞋子" target="_blank" href="/xiezi-b102/">prada普拉达鞋子</a>
      
      </div>
      <a title="查看更多" target="_blank" href="/xiezi/" class="more">查看更多</a> </div>
  </div>
  <div class="floorBody clearfix">
    <div class="mainMap">
      <div class="groupTop">
        <div class="focus Left">
          <div class="slidebox-02">
            <ul class="slidepic-02">
              <li><a href="/fendixie/" title="鞋子"><img width="540" height="340" alt="鞋子" src="/ad/xiezi1.jpg" /></a></li>
              <li><a href="/guccixie/"><img width="540" height="340" alt="鞋子" src="/images/tm.png" data-src="/ad/xiezi2.jpg" /></a></li>
              <li><a href="/lvxiezi/"><img width="540" height="340" alt="鞋子" src="/images/tm.png" data-src="/ad/xiezi3.jpg" /></a></li>
            </ul>
            <div class="slidebtn-02">
              <ul>
                <li class="current">1</li>
                <li>2</li>
                <li>3</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="sideSwitch Right">
          <div class="header"><strong class="txt">点击排行</strong></div>
          <ul class="clickMap" id="JS_switch_stage_0">
            <?php $_from = $this->_var['cat1_xieziph_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'xieziphgoods');if (count($_from)):
    foreach ($_from AS $this->_var['xieziphgoods']):
?>
            <li class="list open">
              <p class="showItem"><a class="link"  target="_blank" title="<?php echo htmlspecialchars($this->_var['xieziphgoods']['name']); ?>" href="<?php echo $this->_var['xieziphgoods']['url']; ?>"><?php echo $this->_var['xieziphgoods']['short_name']; ?></a></p>
              <div class="hideItem">
                <div class="img"><a title="<?php echo htmlspecialchars($this->_var['xieziphgoods']['name']); ?>" href="<?php echo $this->_var['xieziphgoods']['url']; ?>" target="_blank" ><img width="170" height="170" alt="<?php echo htmlspecialchars($this->_var['xieziphgoods']['name']); ?>" src="/images/tm.png" data-src="<?php echo $this->_var['xieziphgoods']['thumb']; ?>"></a></div>
                <a class="name" title="<?php echo htmlspecialchars($this->_var['xieziphgoods']['name']); ?>" href="<?php echo $this->_var['xieziphgoods']['url']; ?>" target="_blank" ><?php echo sub_str($this->_var['xieziphgoods']['short_name'],35); ?></a>
                <div class="count">
                  <div class="Left"><span class="icon"><?php echo $this->_var['xieziphgoods']['click_count']; ?></span><span>人喜欢</span></div>
                  <div class="Right"><span class="orange"><?php echo $this->_var['xieziphgoods']['click_count']; ?></span><span>人浏览过</span></div>
                </div>
              </div>
            </li>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
//滑动门效果
function setSlide(m,n){
	var $ = function(id){return document.getElementById(id);}
	var mli=$("slideTit"+m).getElementsByTagName("span");
	//alert(mli);
	var sul=$("slide"+m).getElementsByTagName("div");
	for(i=0;i<mli.length;i++){
		mli[i].className=i==n?"current":"";
		sul[i].style.display=i==n?"block":"none";
	}
}
</script>
<div class="w mt20">
  <div class="pro_wrap2" id="news2">
    <div class="tab">
     
    </div>
    <div class="cur page">
      <ul class="pro_list clearfix">
        <?php $_from = $this->_var['cat1_xiezilv_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'lvgoods');if (count($_from)):
    foreach ($_from AS $this->_var['lvgoods']):
?>
        <li> <a target="_blank" class="pic" href="<?php echo $this->_var['lvgoods']['url']; ?>"> <img  src="/placeholder.png" file="<?php echo $this->_var['lvgoods']['thumb']; ?>" alt="<?php echo htmlspecialchars($this->_var['lvgoods']['name']); ?>" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/<?php echo $this->_var['lvgoods']['thumb']; ?>" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="<?php echo htmlspecialchars($this->_var['lvgoods']['name']); ?>" class="name" target="_blank" href="<?php echo $this->_var['lvgoods']['url']; ?>"><?php echo $this->_var['lvgoods']['short_name']; ?></a>
            <div class="price">
              <?php if ($this->_var['lvgoods']['promote_price'] != ""): ?>
              <span class="gray"><?php echo $this->_var['lang']['promote_price']; ?></span><strong class="red"><?php echo $this->_var['lvgoods']['promote_price']; ?></strong>
              <?php else: ?>
              <span class="gray"><?php echo $this->_var['lang']['shop_price']; ?></span><strong class="red"><?php echo $this->_var['lvgoods']['shop_price']; ?></strong>
              <?php endif; ?>
              <p class="red">
                <?php if ($_SESSION['user_rank'] > 1): ?>
                <?php $_from = $this->_var['lvgoods']['rank']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'rank');if (count($_from)):
    foreach ($_from AS $this->_var['rank']):
?>
                <?php echo $this->_var['rank']['rank_name']; ?>:<?php echo $this->_var['rank']['rank_price']; ?>
                <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
                <?php else: ?>
                <img src="/ad/price.jpg" alt="批发请联系客服">
                <?php endif; ?>
              </P>
            </div>
          </div>
        </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
  </div>
</div>


<div class="w floorMap f6">
  <div class="floorHeader">
    <div  class="floorName" id="JS_hide_floor_menu_3">
      <div class="floorMenu">
        <ul class="catList">
          <li>• <a title="男士皮带" target="_blank" href="/pidai-attr12869-0-0-0-0-0-0-0-0-0-0/">男士皮带</a></li>
          <li>• <a title="女士皮带" target="_blank" href="/pidai-attr14478-0-0-0-0-0-0-0-0-0-0/">女士皮带</a></li>
          <li>• <a title="300～600皮带" target="_blank" href="/pidai-attr0-0-0-0-10504-0-0-0-0-0-0/">300～600</a></li>
          <li>• <a title="300～600皮带" target="_blank" href="/pidai-attr0-0-0-0-11970-0-0-0-0-0-0/">600～1200</a></li>
        </ul>
        <h4>推荐品牌</h4>
        <ul class="brand">
          <li>
            <div class="inbox">
              <div class="img"><a title="LV路易威登 " target="_blank" href="/lvpidai/"><img width="80" height="50" alt="LV路易威登 " data-src="/data/brandlogo/1357077708628288301.jpg" src="/images/tm.png" ></a></div>
              <p><a title="LV路易威登  " target="_blank" href="/lvpidai/"> LV路易威登  </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="Hermes爱马仕" target="_blank" href="/hermespidai/"><img width="80" height="50" alt="Hermes爱马仕" data-src="/data/brandlogo/1357077911087601515.jpg" src="/images/tm.png"></a></div>
              <p><a title="Hermes爱马仕" target="_blank" href="/hermespidai/">Hermes爱马仕</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="chanel香奈儿" target="_blank" href="/chanelpidai/"><img width="80" height="50" alt="chanel香奈儿" data-src="/data/brandlogo/1357078202840981454.jpg" src="/images/tm.png"></a></div>
              <p><a title="chanel香奈儿" target="_blank" href="/chanelpidai/">chanel香奈儿</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="burberry巴宝莉 " target="_blank" href="/burberrypidai/"><img width="80" height="50" alt="burberry巴宝莉" data-src="/data/brandlogo/1357078351404307774.jpg" src="/images/tm.png"></a></div>
              <p><a title="burberry巴宝莉 " target="_blank" href="/burberrypidai/">burberry巴宝莉</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="gucci古奇 " target="_blank" href="/guccipidai/"><img width="80" height="50" alt="gucci古奇" data-src="/data/brandlogo/1357077959227874651.jpg" src="/images/tm.png"></a></div>
              <p><a title="gucci古奇 " target="_blank" href="/guccipidai/">gucci古奇</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="BV宝缇嘉 " target="_blank" href="/bvpidai/"><img width="80" height="50" alt="BV宝缇嘉" data-src="/data/brandlogo/1357078740679832302.jpg" src="/images/tm.png"></a></div>
              <p><a title="BV宝缇嘉 " target="_blank" href="/bvpidai/">BV宝缇嘉</a></p>
            </div>
          </li>
        </ul>
      </div>
      <a href="javascript:;" class="showName"><span class="icon"><em class="hLine"></em><em class="vLine"></em></span></a> </div>
    <div class="floorLink">
      <div class="kw Left">热门推荐：<a title="LV路易威登皮带" target="_blank" href="/pidai-b100/">LV皮带</a> <span class="line">|</span> 
      
      <a title="Hermes爱马仕皮带" target="_blank" href="/pidai-b101/">Hermes爱马仕皮带</a> <span class="line">|</span> 
      <a title="prada普拉达皮带" target="_blank" href="/pidai-b102/">prada普拉达皮带</a> <span class="line">|</span> 
      <a title="gucci古奇皮带" target="_blank" href="/pidai-b103/">gucci古奇皮带</a> <span class="line">|</span> 
      <a title="chanel香奈儿皮带" target="_blank" href="/pidai-b104/">chanel香奈儿皮带</a> <span class="line">|</span> 
      <a title="burberry巴宝莉皮带" target="_blank" href="/pidai-b105/">burberry巴宝莉皮带</a> <span class="line">|</span> 
      </div>
      <a title="查看更多" target="_blank" href="/pidai/" class="more">查看更多</a> </div>
  </div>
  <div class="floorBody clearfix">
    <div class="mainMap">
      <div class="groupTop">
        <div class="focus Left">
          <div class="slidebox-03">
            <ul class="slidepic-03">
              <li><a href="/pidai/"><img width="540" height="340" alt="皮带" src="/ad/pidai-01.jpg" /></a></li>
              <li><a href="/guccipidai/"><img width="540" height="340" alt="皮带" src="/images/tm.png" data-src="/ad/pidai02.jpg" /></a></li>
              <li><a href="/lvpidai/"><img width="540" height="340" alt="皮带" src="/images/tm.png" data-src="/ad/pidai03.jpg" /></a></li>
            </ul>
            <div class="slidebtn-03">
              <ul>
                <li class="current">1</li>
                <li>2</li>
                <li>3</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="sideSwitch Right">
          <div class="header"><strong class="txt">点击排行</strong></div>
          <ul class="clickMap" id="JS_switch_stage_0">
            <?php $_from = $this->_var['cat1_yaodaiph_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'yaodaiphgoods');if (count($_from)):
    foreach ($_from AS $this->_var['yaodaiphgoods']):
?>
            <li class="list open">
              <p class="showItem"><a class="link"  target="_blank" title="<?php echo htmlspecialchars($this->_var['yaodaiphgoods']['name']); ?>" href="<?php echo $this->_var['yaodaiphgoods']['url']; ?>"><?php echo $this->_var['yaodaiphgoods']['short_name']; ?></a></p>
              <div class="hideItem">
                <div class="img"><a title="<?php echo htmlspecialchars($this->_var['yaodaiphgoods']['name']); ?>" href="<?php echo $this->_var['yaodaiphgoods']['url']; ?>" target="_blank" ><img width="170" height="170" alt="<?php echo htmlspecialchars($this->_var['yaodaiphgoods']['name']); ?>" src="/images/tm.png" data-src="<?php echo $this->_var['yaodaiphgoods']['thumb']; ?>"></a></div>
                <a class="name" title="<?php echo htmlspecialchars($this->_var['yaodaiphgoods']['name']); ?>" href="<?php echo $this->_var['yaodaiphgoods']['url']; ?>" target="_blank" ><?php echo sub_str($this->_var['yaodaiphgoods']['short_name'],35); ?></a>
                <div class="count">
                  <div class="Left"><span class="icon"><?php echo $this->_var['yaodaiphgoods']['click_count']; ?></span><span>人喜欢</span></div>
                  <div class="Right"><span class="orange"><?php echo $this->_var['yaodaiphgoods']['click_count']; ?></span><span>人浏览过</span></div>
                </div>
              </div>
            </li>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="w mt20">
  <div class="pro_wrap3" id="news3">
    <div class="tab">
   
    </div>
    <div class="cur page">
      <ul class="pro_list clearfix">
        <?php $_from = $this->_var['cat1_yaodailv_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'yaodailv');if (count($_from)):
    foreach ($_from AS $this->_var['yaodailv']):
?>
        <li> <a target="_blank" class="pic" href="<?php echo $this->_var['yaodailv']['url']; ?>"><img  src="/placeholder.png" file="<?php echo $this->_var['yaodailv']['thumb']; ?>" alt="<?php echo htmlspecialchars($this->_var['yaodailv']['name']); ?>" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/<?php echo $this->_var['yaodailv']['thumb']; ?>" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="<?php echo htmlspecialchars($this->_var['yaodailv']['name']); ?>" class="name" target="_blank" href="<?php echo $this->_var['yaodailv']['url']; ?>"><?php echo $this->_var['yaodailv']['short_name']; ?></a>
            <div class="price">
              <?php if ($this->_var['yaodailv']['promote_price'] != ""): ?>
              <span class="gray"><?php echo $this->_var['lang']['promote_price']; ?></span><strong class="red"><?php echo $this->_var['yaodailv']['promote_price']; ?></strong>
              <?php else: ?>
              <span class="gray"><?php echo $this->_var['lang']['shop_price']; ?></span><strong class="red"><?php echo $this->_var['yaodailv']['shop_price']; ?></strong>
              <?php endif; ?>
              <p class="red">
                <?php if ($_SESSION['user_rank'] > 1): ?>
                <?php $_from = $this->_var['yaodailv']['rank']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'rank');if (count($_from)):
    foreach ($_from AS $this->_var['rank']):
?>
                <?php echo $this->_var['rank']['rank_name']; ?>:<?php echo $this->_var['rank']['rank_price']; ?>
                <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
                <?php else: ?>
                <img src="/ad/price.jpg" alt="批发请联系客服">
                <?php endif; ?>
              </P>
            </div>
          </div>
        </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
  </div>
</div>


<div class="w floorMap f8">
  <div class="floorHeader">
    <div  class="floorName" id="JS_hide_floor_menu_3">
      <div class="floorMenu">
        <ul class="catList">
          <li>• <a title="男士眼镜" target="_blank" href="/mojing-attr26803-0-0-0-0-0-0-0-0-0-0/">男士眼镜</a></li>
          <li>• <a title="女士眼镜" target="_blank" href="/mojing-attr26808-0-0-0-0-0-0-0-0-0-0/">女士眼镜</a></li>
          <li>• <a title="板材" target="_blank" href="/mojing-attr0-0-0-26802-0-0-0-0-0-0-0/">板材</a></li>
          <li>• <a title="金属" target="_blank" href="/mojing-attr0-0-0-26812-0-0-0-0-0-0-0/">金属</a></li>
        </ul>
        <h4>推荐品牌</h4>
        <ul class="brand">
          <li>
            <div class="inbox">
              <div class="img"><a title="chanel香奈儿" target="_blank" href="/Chaneltyj/"><img width="80" height="50" alt="chanel香奈儿" data-src="/data/brandlogo/1357078202840981454.jpg" src="/images/tm.png" ></a></div>
              <p><a title="chanel香奈儿" target="_blank" href="/Chaneltyj/">chanel香奈儿</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="bvlgari宝格丽" target="_blank" href="/bvlgarityj/"><img width="80" height="50" alt="bvlgari宝格丽" data-src="/data/brandlogo/1357078785729779801.jpg" src="/images/tm.png"></a></div>
              <p><a title="bvlgari宝格丽" target="_blank" href="/bvlgarityj/">bvlgari宝格丽 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="LV路易威登 " target="_blank" href="/lvmojing/"><img width="80" height="50" alt="LV路易威登 " data-src="/data/brandlogo/1357077708628288301.jpg" src="/images/tm.png"></a></div>
              <p><a title="LV路易威登 " target="_blank" href="/lvmojing/">LV路易威登 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="Hermes爱马仕 " target="_blank" href="/hermestyj/"><img width="80" height="50" alt="Hermes爱马仕 " data-src="/data/brandlogo/1357077806274511679.jpg" src="/images/tm.png"></a></div>
              <p><a title="Hermes爱马仕" target="_blank" href="/hermestyj/">Hermes爱马仕 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="burberry巴宝莉" target="_blank" href="/burberrytyj/"><img width="80" height="50" alt="burberry巴宝莉" data-src="/data/brandlogo/1357078351404307774.jpg" src="/images/tm.png"></a></div>
              <p><a title="burberry巴宝莉 " target="_blank" href="/burberrytyj/">burberry巴宝莉</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="Armani阿玛尼 " target="_blank" href="/amntyj/"><img width="80" height="50" alt="Armani阿玛尼" data-src="/data/brandlogo/1357080405114386887.jpg" src="/images/tm.png"></a></div>
              <p><a title="Armani阿玛尼" target="_blank" href="/amntyj/">Armani阿玛尼</a></p>
            </div>
          </li>
        </ul>
      </div>
      <a href="javascript:;" class="showName"><span class="icon"><em class="hLine"></em><em class="vLine"></em></span></a> </div>
    <div class="floorLink">
      <div class="kw Left">热门推荐：<a title="眼镜" target="_blank" href="/ferrari/">眼镜</a> <span class="line">|</span>
      
      <a title="LV路易威登" target="_blank" href="/mojing-b100/">LV路易威登</a> <span class="line">|</span>
      <a title="Hermes爱马仕眼镜" target="_blank" href="/mojing-b101/">Hermes爱马仕眼镜</a> <span class="line">|</span>
      <a title="prada普拉达眼镜" target="_blank" href="/mojing-b102/">prada普拉达眼镜</a> <span class="line">|</span>
      <a title="gucci古奇眼镜" target="_blank" href="/mojing-b103/">gucci古奇眼镜</a> <span class="line">|</span>
      <a title="chanel香奈儿眼镜" target="_blank" href="/mojing-b104/">chanel香奈儿眼镜</a> <span class="line">|</span>
      </div>
      <a title="查看更多" target="_blank" href="/ferrari/" class="more">查看更多</a> </div>
  </div>
  <div class="floorBody clearfix">
    <div class="mainMap">
      <div class="groupTop">
        <div class="focus Left">
          <div class="slidebox-05">
            <ul class="slidepic-05">
              <li><a href="/ferrari/"><img width="540" height="340" alt="眼镜" src="/images/tm.png" data-src="/ad/yanjing1.jpg" /></a></li>
              <li><a href="/porsche/"><img width="540" height="340" alt="眼镜" src="/images/tm.png" data-src="/ad/yanjing2.jpg" /></a></li>
              <li><a href="/mojing/"><img width="540" height="340" alt="眼镜" src="/images/tm.png" data-src="/ad/yanjing3.jpg" /></a></li>
            </ul>
            <div class="slidebtn-05">
              <ul>
                <li class="current">1</li>
                <li>2</li>
                <li>3</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="sideSwitch Right">
          <div class="header"><strong class="txt">点击排行</strong></div>
          <ul class="clickMap" id="JS_switch_stage_0">
            <?php $_from = $this->_var['cat1_yanjingph_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'yanjingphgoods');if (count($_from)):
    foreach ($_from AS $this->_var['yanjingphgoods']):
?>
            <li class="list open">
              <p class="showItem"><a class="link"  target="_blank" title="<?php echo htmlspecialchars($this->_var['yanjingphgoods']['name']); ?>" href="<?php echo $this->_var['yanjingphgoods']['url']; ?>"><?php echo $this->_var['yanjingphgoods']['short_name']; ?></a></p>
              <div class="hideItem">
                <div class="img"><a title="<?php echo htmlspecialchars($this->_var['yanjingphgoods']['name']); ?>" href="<?php echo $this->_var['yanjingphgoods']['url']; ?>" target="_blank" ><img width="170" height="170" alt="<?php echo htmlspecialchars($this->_var['yanjingphgoods']['name']); ?>" src="/images/tm.png" data-src="<?php echo $this->_var['yanjingphgoods']['thumb']; ?>"></a></div>
                <a class="name" title="<?php echo htmlspecialchars($this->_var['yaodaiphgoods']['name']); ?>" href="<?php echo $this->_var['yanjingphgoods']['url']; ?>" target="_blank" ><?php echo sub_str($this->_var['yanjingphgoods']['short_name'],35); ?></a>
                <div class="count">
                  <div class="Left"><span class="icon"><?php echo $this->_var['yanjingphgoods']['click_count']; ?></span><span>人喜欢</span></div>
                  <div class="Right"><span class="orange"><?php echo $this->_var['yanjingphgoods']['click_count']; ?></span><span>人浏览过</span></div>
                </div>
              </div>
            </li>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="w mt20">
  <div class="pro_wrap5" id="news5">
    <div class="tab">
      
    </div>
    <div class="cur page">
      <ul class="pro_list clearfix">
        <?php $_from = $this->_var['cat1_yaoyjklx_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'yjklxgoods');if (count($_from)):
    foreach ($_from AS $this->_var['yjklxgoods']):
?>
        <li> <a target="_blank" class="pic" href="<?php echo $this->_var['yjklxgoods']['url']; ?>"> <img  src="/placeholder.png" file="<?php echo $this->_var['yjklxgoods']['thumb']; ?>" alt="<?php echo htmlspecialchars($this->_var['yjklxgoods']['name']); ?>" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/<?php echo $this->_var['yjklxgoods']['thumb']; ?>" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="<?php echo htmlspecialchars($this->_var['yjklxgoods']['name']); ?>" class="name" target="_blank" href="<?php echo $this->_var['yjklxgoods']['url']; ?>"><?php echo $this->_var['yjklxgoods']['short_name']; ?></a>
            <div class="price">
              <?php if ($this->_var['yjklxgoods']['promote_price'] != ""): ?>
              <span class="gray"><?php echo $this->_var['lang']['promote_price']; ?></span><strong class="red"><?php echo $this->_var['yjklxgoods']['promote_price']; ?></strong>
              <?php else: ?>
              <span class="gray"><?php echo $this->_var['lang']['shop_price']; ?></span><strong class="red"><?php echo $this->_var['yjklxgoods']['shop_price']; ?></strong>
              <?php endif; ?>
              <p class="red">
                <?php if ($_SESSION['user_rank'] > 1): ?>
                <?php $_from = $this->_var['yjklxgoods']['rank']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'rank');if (count($_from)):
    foreach ($_from AS $this->_var['rank']):
?>
                <?php echo $this->_var['rank']['rank_name']; ?>:<?php echo $this->_var['rank']['rank_price']; ?>
                <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
                <?php else: ?>
                <img src="/ad/price.jpg" alt="批发请联系客服">
                <?php endif; ?>
              </P>
            </div>
          </div>
        </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
  </div>
</div>


<div class="w floorMap f9">
  <div class="floorHeader">
    <div  class="floorName" id="JS_hide_floor_menu_3">
      <div class="floorMenu">
        <ul class="catList">
          <li>• <a title="男士帽子" target="_blank" href="/mao-attr20444-0-0-0-0-0-0-0-0-0-0/">男士帽子</a></li>
          <li>• <a title="女士帽子" target="_blank" href="/mao-attr20459-0-0-0-0-0-0-0-0-0-0/">女士帽子</a></li>
          <li>• <a title="300元以下" target="_blank" href="/mao-attr0-0-0-0-7040-0-0-0-0-0-0/">300元以下</a></li>
          <li>• <a title="300～600" target="_blank" href="/mao-attr0-0-0-0-10674-0-0-0-0-0-0/">300～600</a></li>
        </ul>
        <h4>推荐品牌</h4>
        <ul class="brand">
          <li>
            <div class="inbox">
              <div class="img"><a title="Hermes爱马仕 " target="_blank" href="/hermesmaozi/"><img width="80" height="50" alt="Hermes爱马仕" data-src="/data/brandlogo/1357077806274511679.jpg" src="/images/tm.png" ></a></div>
              <p><a title="Hermes爱马仕 " target="_blank" href="/hermesmaozi/">Hermes爱马仕 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="LV路易威登" target="_blank" href="/lvmaozi/"><img width="80" height="50" alt="LV路易威登  " data-src="/data/brandlogo/1357077708628288301.jpg" src="/images/tm.png"></a></div>
              <p><a title="LV路易威登  " target="_blank" href="/lvmaozi/">LV路易威登 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="gucci古奇" target="_blank" href="/guccimaozi/"><img width="80" height="50" alt="gucci古奇" data-src="/data/brandlogo/1357077959227874651.jpg" src="/images/tm.png"></a></div>
              <p><a title="gucci古奇" target="_blank" href="/guccimaozi/">gucci古奇 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="chanel香奈儿" target="_blank" href="/chanelmao/"><img width="80" height="50" alt="chanel香奈儿" data-src="/data/brandlogo/1357078202840981454.jpg" src="/images/tm.png"></a></div>
              <p><a title="chanel香奈儿" target="_blank" href="/chanelmao/">chanel香奈儿</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="burberry巴宝莉" target="_blank" href="/burberrymaozi/"><img width="80" height="50" alt="burberry巴宝莉" data-src="/data/brandlogo/1357078351404307774.jpg" src="/images/tm.png"></a></div>
              <p><a title="burberry巴宝莉" target="_blank" href="/burberrymaozi/">burberry巴宝莉</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="fendi芬迪" target="_blank" href="/fendimaozi/"><img width="80" height="50" alt="fendi芬迪" data-src="/data/brandlogo/1357078504621390300.jpg" src="/images/tm.png"></a></div>
              <p><a title="fendi芬迪" target="_blank" href="/fendimaozi/">fendi芬迪</a></p>
            </div>
          </li>
        </ul>
      </div>
      <a href="javascript:;" class="showName"><span class="icon"><em class="hLine"></em><em class="vLine"></em></span></a> </div>
    <div class="floorLink">
      <div class="kw Left">热门推荐：<a title="时尚百搭" target="_blank" href="/mao-attr0-7038-0-0-0-0-0-0-0-0-0/">时尚百搭</a> <span class="line">|</span>
      
      <a title="LV路易威登帽子" target="_blank" href="/mao-b100/">LV路易威登帽子</a> <span class="line">|</span>
      
      <a title="Hermes爱马仕帽子" target="_blank" href="/mao-b101/">Hermes爱马仕帽子</a> <span class="line">|</span>
      <a title="gucci古奇帽子" target="_blank" href="/mao-b102/">gucci古奇帽子</a> <span class="line">|</span>
      <a title="chanel香奈儿帽子" target="_blank" href="/mao-b103/">chanel香奈儿帽子</a> <span class="line">|</span>
      
      </div>
      <a title="查看更多" target="_blank" href="/mao/" class="more">查看更多</a> </div>
  </div>
  <div class="floorBody clearfix">
    <div class="mainMap">
      <div class="groupTop">
        <div class="focus Left">
          <div class="slidebox-06">
            <ul class="slidepic-06">
              <li><a href="/mao/"><img width="540" height="340" alt="帽子" src="/images/tm.png" data-src="/ad/maozi01.jpg" /></a></li>
              <li><a href="/guccimaozi/"><img width="540" height="340" alt="帽子" src="/images/tm.png" data-src="/ad/maozi02.jpg" /></a></li>
              <li><a href="/chanelmao/"><img width="540" height="340" alt="帽子" src="/images/tm.png" data-src="/ad/ad8.jpg" /></a></li>
            </ul>
            <div class="slidebtn-06">
              <ul>
                <li class="current">1</li>
                <li>2</li>
                <li>3</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="sideSwitch Right">
          <div class="header"><strong class="txt">点击排行</strong></div>
          <ul class="clickMap" id="JS_switch_stage_0">
            <?php $_from = $this->_var['cat1_maoziph_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'maoziphgoods');if (count($_from)):
    foreach ($_from AS $this->_var['maoziphgoods']):
?>
            <li class="list open">
              <p class="showItem"><a class="link"  target="_blank" title="<?php echo htmlspecialchars($this->_var['maoziphgoods']['name']); ?>" href="<?php echo $this->_var['maoziphgoods']['url']; ?>"><?php echo $this->_var['maoziphgoods']['short_name']; ?></a></p>
              <div class="hideItem">
                <div class="img"><a title="<?php echo htmlspecialchars($this->_var['maoziphgoods']['name']); ?>" href="<?php echo $this->_var['maoziphgoods']['url']; ?>" target="_blank" ><img width="170" height="170" alt="<?php echo htmlspecialchars($this->_var['maoziphgoods']['name']); ?>" src="/images/tm.png" data-src="<?php echo $this->_var['maoziphgoods']['thumb']; ?>"></a></div>
                <a class="name" title="<?php echo htmlspecialchars($this->_var['maoziphgoods']['name']); ?>" href="<?php echo $this->_var['maoziphgoods']['url']; ?>" target="_blank" ><?php echo sub_str($this->_var['maoziphgoods']['short_name'],35); ?></a>
                <div class="count">
                  <div class="Left"><span class="icon"><?php echo $this->_var['maoziphgoods']['click_count']; ?></span><span>人喜欢</span></div>
                  <div class="Right"><span class="orange"><?php echo $this->_var['maoziphgoods']['click_count']; ?></span><span>人浏览过</span></div>
                </div>
              </div>
            </li>
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="w mt20">
  <div class="pro_wrap6" id="news6">
    <div class="tab">
    </div>
    <div class="cur page">
      <ul class="pro_list clearfix">
        <?php $_from = $this->_var['cat1_maozilv_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'maozilvgoods');if (count($_from)):
    foreach ($_from AS $this->_var['maozilvgoods']):
?>
        <li> <a target="_blank" class="pic" href="<?php echo $this->_var['maozilvgoods']['url']; ?>"> <img  src="/placeholder.png" file="<?php echo $this->_var['maozilvgoods']['thumb']; ?>" alt="<?php echo htmlspecialchars($this->_var['maozilvgoods']['name']); ?>" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/<?php echo $this->_var['maozilvgoods']['thumb']; ?>" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="<?php echo htmlspecialchars($this->_var['maozilvgoods']['name']); ?>" class="name" target="_blank" href="<?php echo $this->_var['maozilvgoods']['url']; ?>"><?php echo $this->_var['maozilvgoods']['short_name']; ?></a>
            <div class="price">
              <?php if ($this->_var['maozilvgoods']['promote_price'] != ""): ?>
              <span class="gray"><?php echo $this->_var['lang']['promote_price']; ?></span><strong class="red"><?php echo $this->_var['maozilvgoods']['promote_price']; ?></strong>
              <?php else: ?>
              <span class="gray"><?php echo $this->_var['lang']['shop_price']; ?></span><strong class="red"><?php echo $this->_var['maozilvgoods']['shop_price']; ?></strong>
              <?php endif; ?>
              <p class="red">
                <?php if ($_SESSION['user_rank'] > 1): ?>
                <?php $_from = $this->_var['maozilvgoods']['rank']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'rank');if (count($_from)):
    foreach ($_from AS $this->_var['rank']):
?>
                <?php echo $this->_var['rank']['rank_name']; ?>:<?php echo $this->_var['rank']['rank_price']; ?>
                <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
                <?php else: ?>
                <img src="/ad/price.jpg" alt="批发请联系客服">
                <?php endif; ?>
              </P>
            </div>
          </div>
        </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
  </div>
</div>

<div id="main">
  <div id="news">
    <div class="tab">
     <ul>
        <li class="t1"></li>
        <li class="t2"></li>
        <li class="t3"></li>
        <li class="cur t4"></li>
        <li class="t5"></li>
      </ul>
    </div>
    <div class="page">
      <div class="left">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=100&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661629255997055.jpg' width='520' height='340'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
      </div>
      <div class="right">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=105&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661098046511054.jpg' width='432' height='114'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
         <?php $this->assign('articles',$this->_var['articles_18']); ?><?php $this->assign('articles_cat',$this->_var['articles_cat_18']); ?><?php echo $this->fetch('library/cat_articles.lbi'); ?>  </div>
    </div>
    <div class="page">
      <div class="left">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=101&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661698095983363.jpg' width='520' height='340'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
      </div>
      <div class="right">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=106&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661081859432492.jpg' width='432' height='114'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
         <?php $this->assign('articles',$this->_var['articles_27']); ?><?php $this->assign('articles_cat',$this->_var['articles_cat_27']); ?><?php echo $this->fetch('library/cat_articles.lbi'); ?>  </div>
    </div>
    <div class="page">
      <div class="left">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=102&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661684374509295.jpg' width='520' height='340'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
      </div>
      <div class="right">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=107&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661060373760405.jpg' width='432' height='114'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
         <?php $this->assign('articles',$this->_var['articles_28']); ?><?php $this->assign('articles_cat',$this->_var['articles_cat_28']); ?><?php echo $this->fetch('library/cat_articles.lbi'); ?>  </div>
    </div>
    <div class="cur page">
      <div class="left">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=103&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661668058149618.jpg' width='520' height='340'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
      </div>
      <div class="right">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=108&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661042046247116.jpg' width='432' height='114'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
         <?php $this->assign('articles',$this->_var['articles_32']); ?><?php $this->assign('articles_cat',$this->_var['articles_cat_32']); ?><?php echo $this->fetch('library/cat_articles.lbi'); ?>  </div>
    </div>
    <div class="page">
      <div class="left">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=104&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661654594153372.jpg' width='520' height='340'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
      </div>
      <div class="right">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=109&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356660999994195673.jpg' width='432' height='114'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
        <?php echo $this->fetch('library/index_comm.lbi'); ?> </div>
    </div>
  </div>
</div>

<div class="blank"></div>
<?php echo $this->fetch('library/help.lbi'); ?> <?php echo $this->fetch('library/page_footer.lbi'); ?>
<script type="text/javascript"> 


</script>
</body>
</html>
