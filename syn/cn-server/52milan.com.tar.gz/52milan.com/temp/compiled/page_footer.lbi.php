<style>
.weixin_pic {
    background-image: none;
    position: absolute;
    z-index: 9999;
	right:367px;
	margin-top:16px;
	_margin-top:18px;
	
}
.weixin_pic img{


	z-index: 9999;

	}
</style>
<div id="footer">
  <div class="info">
    <p> 
      <?php $_from = $this->_var['navigator_list']['bottom']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'nav_0_29169600_1388938643');$this->_foreach['nav_bottom_list'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['nav_bottom_list']['total'] > 0):
    foreach ($_from AS $this->_var['nav_0_29169600_1388938643']):
        $this->_foreach['nav_bottom_list']['iteration']++;
?> 
      <a href="<?php echo $this->_var['nav_0_29169600_1388938643']['url']; ?>" <?php if ($this->_var['nav_0_29169600_1388938643']['opennew'] == 1): ?>target="_blank"<?php endif; ?>  rel="nofollow" ><?php echo $this->_var['nav_0_29169600_1388938643']['name']; ?></a><?php if (! ($this->_foreach['nav_bottom_list']['iteration'] == $this->_foreach['nav_bottom_list']['total'])): ?>&nbsp;&nbsp;|&nbsp;&nbsp;<?php endif; ?> 
      <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
        |
      <a  href="/sitemap.html" target="_blank">网站地图</a>
    </p>
    
    <?php if ($this->_var['img_links'] || $this->_var['txt_links']): ?> 
    <span>友情链接（申请链接：QQ：1173013280 ）：</span>
    <div class="friendlinks">
      <ul>
        <li> 
          <?php $_from = $this->_var['txt_links']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'link');$this->_foreach['lcurn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['lcurn']['total'] > 0):
    foreach ($_from AS $this->_var['link']):
        $this->_foreach['lcurn']['iteration']++;
?> 
          <?php if ($this->_foreach['lcurn']['iteration'] < 11): ?> <a href="<?php echo $this->_var['link']['url']; ?>" target="_blank" title="<?php echo $this->_var['link']['name']; ?>"><?php echo $this->_var['link']['name']; ?></a> <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
        </li>
        <li> 
          <?php $_from = $this->_var['txt_links']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'link');$this->_foreach['lcurn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['lcurn']['total'] > 0):
    foreach ($_from AS $this->_var['link']):
        $this->_foreach['lcurn']['iteration']++;
?> 
          <?php if ($this->_foreach['lcurn']['iteration'] > 10 || $this->_foreach['lcurn']['iteration'] < 21): ?> <a href="<?php echo $this->_var['link']['url']; ?>" target="_blank" title="<?php echo $this->_var['link']['name']; ?>"><?php echo $this->_var['link']['name']; ?></a> <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
        </li>
        <li> 
          <?php $_from = $this->_var['txt_links']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'link');$this->_foreach['lcurn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['lcurn']['total'] > 0):
    foreach ($_from AS $this->_var['link']):
        $this->_foreach['lcurn']['iteration']++;
?> 
          <?php if ($this->_foreach['lcurn']['iteration'] > 20 || $this->_foreach['lcurn']['iteration'] < 31): ?> <a href="<?php echo $this->_var['link']['url']; ?>" target="_blank" title="<?php echo $this->_var['link']['name']; ?>"><?php echo $this->_var['link']['name']; ?></a> <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
        </li>
        <li> 
          <?php $_from = $this->_var['txt_links']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'link');$this->_foreach['lcurn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['lcurn']['total'] > 0):
    foreach ($_from AS $this->_var['link']):
        $this->_foreach['lcurn']['iteration']++;
?> 
          <?php if ($this->_foreach['lcurn']['iteration'] > 30 || $this->_foreach['lcurn']['iteration'] < 41): ?> <a href="<?php echo $this->_var['link']['url']; ?>" target="_blank" title="<?php echo $this->_var['link']['name']; ?>"><?php echo $this->_var['link']['name']; ?></a> <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
        </li>
        <li> 
          <?php $_from = $this->_var['txt_links']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'link');$this->_foreach['lcurn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['lcurn']['total'] > 0):
    foreach ($_from AS $this->_var['link']):
        $this->_foreach['lcurn']['iteration']++;
?> 
          <?php if ($this->_foreach['lcurn']['iteration'] > 40 || $this->_foreach['lcurn']['iteration'] < 51): ?> <a href="<?php echo $this->_var['link']['url']; ?>" target="_blank" title="<?php echo $this->_var['link']['name']; ?>"><?php echo $this->_var['link']['name']; ?></a> <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> </li>
        <li> 
          <?php $_from = $this->_var['txt_links']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'link');$this->_foreach['lcurn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['lcurn']['total'] > 0):
    foreach ($_from AS $this->_var['link']):
        $this->_foreach['lcurn']['iteration']++;
?> 
          <?php if ($this->_foreach['lcurn']['iteration'] > 50 || $this->_foreach['lcurn']['iteration'] < 61): ?> <a href="<?php echo $this->_var['link']['url']; ?>" target="_blank" title="<?php echo $this->_var['link']['name']; ?>"><?php echo $this->_var['link']['name']; ?></a> <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> </li>
      </ul>
    </div>
    <?php endif; ?>
    <p><?php echo $this->_var['shop_address']; ?> <?php echo $this->_var['shop_postcode']; ?> 
      <?php if ($this->_var['service_phone']): ?> 
      Tel: <?php echo $this->_var['service_phone']; ?> 
      <?php endif; ?> 
      <?php if ($this->_var['service_email']): ?> 
      E-mail: <?php echo $this->_var['service_email']; ?> 
      <?php endif; ?><?php if ($this->_var['icp_number']): ?> 
      <?php echo $this->_var['lang']['icp_number']; ?>:<a href="http://www.miibeian.gov.cn/" target="_blank" class="gray"><?php echo $this->_var['icp_number']; ?></a> 
      <?php endif; ?><?php if ($this->_var['stats_code']): ?><?php echo $this->_var['stats_code']; ?><?php endif; ?></p>
    <p class="copyright"><?php echo $this->_var['copyright']; ?></p>
   
  </div>
</div>
<div class="blank5"></div>
<script type="text/javascript">
function datasrc(){

var imga = document.getElementsByTagName("img");

//alert('网站打开完毕！开始加载图片！');


for(i=0;i<imga.length;i++)
{
imgsrc=imga[i].getAttribute('data-src');

if (imgsrc!=null){


imga[i].setAttribute('src',""+imgsrc+"");

       }


}


}


</script>




<LINK rel=stylesheet type=text/css href="/images/common.css">
<DIV id=floatTools class=float0831>
  <DIV class=floatL> 
  <A style="DISPLAY: none" id="newswt_mini" class="btnOpen" title="查看在线客服"  href="javascript:void(0);">展开</A> 

<A id="newswt_close" class="btnCtn" title="关闭在线客服" href="javascript:void(0);">收缩</A> </DIV>
  <DIV id=divFloatToolsView class=floatR>
    <DIV class=tp></DIV>
    <DIV class=cn>
      <UL>
        <LI class=top>
          <H3 class=titZx>QQ咨询</H3>
        </LI>
        <LI><a rel="nofollow" target="_blank" href="/kefu_1.html?arg=lvbao1688&amp;style=1"><img width="80" height="26" src="/themes/wbw2012/images/zxkf.gif"></a></LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=800009775&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服①</A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1622861430&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服② </A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1764924587&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服③</A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1984216240&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服④</A> </LI>
         <LI><A  href="http://amos.im.alisoft.com/msg.aw?v=2&uid=%E7%BB%B4%E7%BE%8E%E8%BE%BE%E7%9A%AE%E5%85%B7&site=cntaobao&s=1&charset=utf-8" target="_blank" rel="nofollow"><img src="/ad/wangwang.gif"></A> </LI>
      </UL>
      <UL>
        <LI>
          <H3 class=titDh>电话咨询</H3>
        </LI>
        <LI><SPAN class=icoTl>4006-346-588</SPAN> </LI>
        <LI>
        <SPAN class=icoTl>15811883379</SPAN>

        </LI>
        <LI class=bot>
          <H3 class=titDc><A href="/message.php" target="_blank">给我留言</A></H3>
        </LI>
      </UL>
    </DIV>
  </DIV>
</DIV>




<script type="text/javascript">

function mouseOver()
{
    document.getElementById('weixin_pic').style.display = "block";
}
function mouseOut()
{
    document.getElementById('weixin_pic').style.display = "none";
}

$(function(){
 $(".weixin").mouseenter(function () {
        $(this).children('.weixin_pic').show();
    }).mouseleave(function () {
        $(this).children('.weixin_pic').hide();
 })
})




$(function(){
	$('#floatTools').show();
	/*$('.swt_h').prev().addClass('swt_current_t');
	$('.swt_tit').each(function(){
		$(this).click(function(){
			$(this).toggleClass('swt_current_t').next().slideToggle()
		})
	});*/
	$('#newswt_close').click(function(){
		$(this).hide()							  
		$('#divFloatToolsView').animate({
			width:'-=130'
		},400,function(){
			$(this).hide()
			$('#newswt_mini').show().animate({
				width:'+=40'
			},600)
		})
	});
	$('#newswt_mini').click(function(){
	    $(this).hide()								 
		$(this).animate({
			width:'-=40'
		},100,function(){
			$('#divFloatToolsView').show().animate({
				width:'+=130'
			},400,function(){
				$('#newswt_close').show().animate({
				width:'+=0'
			},600)
		  })
		})
	})
}) 
</script>
).animate({
				width:'+=0'
			},600)
		  })
		})
	})
}) 
</script>
