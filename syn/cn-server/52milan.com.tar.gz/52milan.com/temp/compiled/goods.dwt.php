<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<base href="http://www.52milan.com/" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="<?php echo $this->_var['keywords']; ?>" />
<meta name="Description" content="<?php echo $this->_var['description']; ?>" />

<title><?php echo $this->_var['page_title']; ?></title>



<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="<?php echo $this->_var['ecs_css_path']; ?>" rel="stylesheet" type="text/css" />
<link href="themes/wbw2012/MagicZoom.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="themes/wbw2012/js/mzp-packed-me.js"></script>
<script type="text/javascript" src="themes/wbw2012/js/site.js"></script>

<?php echo $this->smarty_insert_scripts(array('files'=>'common.js')); ?>





<script type="text/javascript">
function $id(element) {
  return document.getElementById(element);
}
//切屏--是按钮，_v是内容平台，_h是内容库
function reg(str){
  var bt=$id(str+"_b").getElementsByTagName("div");
  for(var i=0;i<bt.length;i++){
    bt[i].subj=str;
    bt[i].pai=i;
    bt[i].style.cursor="pointer";
    bt[i].onclick=function(){
      $id(this.subj+"_v").innerHTML=$id(this.subj+"_h").getElementsByTagName("blockquote")[this.pai].innerHTML;
      for(var j=0;j<$id(this.subj+"_b").getElementsByTagName("div").length;j++){
        var _bt=$id(this.subj+"_b").getElementsByTagName("div")[j];
        var ison=j==this.pai;
        _bt.className=(ison?"":"h2bg");
      }
    }
  }
  $id(str+"_h").className="none";
  $id(str+"_v").innerHTML=$id(str+"_h").getElementsByTagName("blockquote")[0].innerHTML;
}

</script>
<script type="text/javascript" src="/js/jquery-1.4.4.min.js" ></script>
<!--<script type="text/javascript" src="/themes/wbw2012/js/jquery.lazyload.js"></script>-->



<script type="text/javascript">
/*jQuery(document).ready(
function($){
$("img").lazyload({
     placeholder : "/themes/wbw2012/js/grey.gif", //加载图片前的占位图片
     effect      : "fadeIn" //加载图片使用的效果(淡入)
});
});*/
var desc;
jQuery(document).ready(function($){
desc = $("#desc");


	//desc.find("div.cur").find("img").lazyload({placeholder:"/themes/wb2009/images2/blank.gif", effect:"fadeIn"});
		   
   desc.find(".tab>a").each(function(idx){
		$(this).bind("click", function(){		
			var this_ = $(this);
			if(this_.hasClass("cur")==false){
				desc.find(".tab>a.cur").removeClass("cur");
				desc.find("div.cur").removeClass("cur");
				this_.addClass("cur");
				var page = desc.find("div.page").eq(idx);
				if(page.html() == ""){
					switch(idx){
						case 1:
							page.html('<div class="block"></div>');
							break;
						case 2:
							page.html('<div class="block"></div>');
							break;
						case 3:
							page.html('<div class="block"></div>');
							break;
					}	
				}
				page.addClass("cur");
			}
		});
	});
});   
</script>
</head>
<body>
<?php echo $this->fetch('library/page_header.lbi'); ?>
<div class="blank5"></div>
<div class="block clearfix"> 
  
  <div id="ur_here" style="height:35px;">
    <div class="f_l"><?php echo $this->fetch('library/ur_here.lbi'); ?></div>
    <div class="f_r"><a href="<?php echo $this->_var['goods']['goods_brand_url']; ?>"><img src="themes/wbw2012/images/goodsb.gif" /></a></div>
  </div>
   
</div>
<div class="blank"></div>
<div class="block clearfix"> 
  
  <div id="goodsInfo" class="clearfix"> 
    
    <div class="imgInfo"> 
      <?php if ($this->_var['pictures']['0']['img_url']): ?> 
      <a href="<?php echo $this->_var['pictures']['0']['img_url']; ?>" id="Zoomer" class="MagicZoomPlus" rel="selectors-effect:false;zoom-fade:true;background-opacity:70;zoom-width:450;zoom-height:450;caption-source:img:title;thumb-change:mouseover" title=""  onclick="window.open('gallery.php?id=<?php echo $this->_var['goods']['goods_id']; ?>'); return false;"> 

<img id="img_url" src="<?php echo $this->_var['pictures']['0']['img_url']; ?>" alt="<?php echo htmlspecialchars($this->_var['goods']['goods_name']); ?>" class="thumb" /> </a> 


      <?php else: ?> 
      <img id="img_url" src="<?php echo $this->_var['goods']['goods_img']; ?>" alt="<?php echo htmlspecialchars($this->_var['goods']['goods_name']); ?>" class="thumb" /> 
      <?php endif; ?>
      <div class="blank"></div>
       
      <?php echo $this->fetch('library/goods_gallery.lbi'); ?> 
      
      <div class="blank5"></div>
    </div>
    <div class="textInfo">
      <form action="javascript:addToCart(<?php echo $this->_var['goods']['goods_id']; ?>)" method="post" name="ECS_FORMBUY" id="ECS_FORMBUY">
        <div class="proname"><h1><?php echo $this->_var['goods']['goods_style_name']; ?></h1></div>
        <?php if ($this->_var['goods']['goods_brief']): ?>
        <div class="brief"><?php echo $this->_var['goods']['goods_brief']; ?></div>
        <?php endif; ?>
        <div class="props">
          <dl>
            <dt>商品编号：</dt>
            <dd><?php echo $this->_var['goods']['goods_sn']; ?></dd>
          </dl>
          <dl>
            <dt>产品品牌：</dt>
            <dd><a href="<?php echo $this->_var['goods']['goods_brand_url']; ?>"><?php echo $this->_var['goods']['goods_brand']; ?></a></dd>
          </dl>
          <?php $_from = $this->_var['properties']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'property_group');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['property_group']):
?> 
          <?php $_from = $this->_var['property_group']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'property');$this->_foreach['sxnum'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['sxnum']['total'] > 0):
    foreach ($_from AS $this->_var['property']):
        $this->_foreach['sxnum']['iteration']++;
?> 
          <?php if ($this->_foreach['sxnum']['iteration'] < 5): ?>
          <dl>
            <dt><?php echo htmlspecialchars($this->_var['property']['name']); ?>：</dt>
            <dd><?php echo $this->_var['property']['value']; ?></dd>
          </dl>
          <?php endif; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?> 
        </div>
        <ul>
          <li class="clearfix">
            <dd> <?php echo $this->_var['lang']['shop_price']; ?><font class="shop" id="ECS_SHOPPRICE"><?php echo $this->_var['goods']['shop_price_formated']; ?></font> </dd>
            <dd class="ddR"> <?php echo $this->_var['lang']['market_price']; ?><font class="market"><?php echo $this->_var['goods']['market_price']; ?></font> </dd>
          </li>
          
          <?php if ($this->_var['volume_price_list']): ?>
          <li class="clearfix"> <font class="f1"><?php echo $this->_var['lang']['volume_price']; ?>：</font><br />
            <table width="100%" border="0" cellpadding="3" cellspacing="1" bgcolor="#aad6ff">
              <tr>
                <td align="center" bgcolor="#FFFFFF"><strong><?php echo $this->_var['lang']['number_to']; ?></strong></td>
                <td align="center" bgcolor="#FFFFFF"><strong><?php echo $this->_var['lang']['preferences_price']; ?></strong></td>
              </tr>
              <?php $_from = $this->_var['volume_price_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('price_key', 'price_list');if (count($_from)):
    foreach ($_from AS $this->_var['price_key'] => $this->_var['price_list']):
?>
              <tr>
                <td align="center" bgcolor="#FFFFFF" class="shop"><?php echo $this->_var['price_list']['number']; ?></td>
                <td align="center" bgcolor="#FFFFFF" class="shop"><?php echo $this->_var['price_list']['format_price']; ?></td>
              </tr>
              <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
            </table>
          </li>
          <?php endif; ?>
          
          <li class="clearfix">
            <dd> <?php if ($_SESSION['user_rank'] > 0): ?>
       <?php $_from = $this->_var['rank_prices']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'rank_price');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['rank_price']):
?>
       <strong><?php echo $this->_var['rank_price']['rank_name']; ?>：</strong><font class="shop" id="ECS_RANKPRICE_<?php echo $this->_var['key']; ?>"><?php echo $this->_var['rank_price']['price']; ?></font><br />
       <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
	   <?php else: ?>
	   <img src="http://lvbao-file.b0.upaiyun.com/ico/kefu.gif" border="0" />
	   <?php endif; ?></dd>
            <dd class="ddR"> <strong>可节省：</strong><?php echo $this->_var['goods']['sheng_price']; ?>（<?php echo $this->_var['goods']['cuxiao_zhekou_price']; ?>折）</dd>
          </li>
        </ul>
        <div class="product_bj" onmouseover="this.className='product_bj1'" onmouseout="this.className='product_bj'">
          <div style="border: medium none; padding-top: 10px; background: none repeat scroll 0% 0% transparent;"> 
            
           
            
            <?php if ($this->_var['goods']['is_promote'] && $this->_var['goods']['gmt_end_time']): ?>
            <div class="clear"></div>
            <?php echo $this->smarty_insert_scripts(array('files'=>'lefttime.js')); ?>
            <div style="line-height:25px;" class="clearfix"><?php echo $this->_var['lang']['promote_price']; ?><font class="shop"><?php echo $this->_var['goods']['promote_price']; ?></font><br />
              <?php echo $this->_var['lang']['residual_time']; ?> <font class="f4" id="leftTime"><?php echo $this->_var['lang']['please_waiting']; ?></font></div>
            <?php endif; ?>
            <div class="clear"></div>
            <div style="height:25px; line-height:25px;">
              <div class="f_l">我要买：</div>
              <a href="javascript:void(0);" onclick="goods_cut();changePrice()" class="imgl"></a>
              <input name="number" type="text" id="number" class="inum" value="1" size="4" onblur="changePrice();get_shipping_list(forms['ECS_FORMBUY'],<?php echo $this->_var['goods']['goods_id']; ?>);"/>
              <a href="javascript:void(0);"  onclick="goods_add();changePrice()" class="imgr"></a> &nbsp;&nbsp;商品总价：<font id="ECS_GOODS_AMOUNT" class="shop"></font></div>
            <div class="buy clearfix">
              <div class="f_l gobuy">
              <?php if ($this->_var['goods']['goods_number'] == 0): ?>
              <img src="themes/wbw2012/images/dcan.gif" />
              <?php else: ?>
              <a href="javascript:addToCart1(<?php echo $this->_var['goods']['goods_id']; ?>)"><img src="themes/wbw2012/images/bnt_cat.gif" /></a>
              <?php endif; ?>
              </div>
              <div class="f_l"><a href="javascript:addToCart(<?php echo $this->_var['goods']['goods_id']; ?>)"><img src="themes/wbw2012/images/cart1.gif" /></a></div>
            </div>
            <script language="javascript" type="text/javascript">
			function goods_cut(){
				var num_val=document.getElementById('number');
				var new_num=num_val.value;
				 if(isNaN(new_num)){alert('请输入数字');return false}
				var Num = parseInt(new_num);
				if(Num>1)Num=Num-1;
				num_val.value=Num;
			}
			function goods_add(){
				var num_val=document.getElementById('number');
				var new_num=num_val.value;
				 if(isNaN(new_num)){alert('请输入数字');return false}
				var Num = parseInt(new_num);
				Num=Num+1;
				num_val.value=Num;
			}
	    </script> 
          </div>
        </div>
        <div class="blank"></div>
        <div class="blank"></div>
        <?php echo $this->fetch('library/add_cat.lbi'); ?>
        <div class="sale_info"> 该商品已被浏览<span><?php echo $this->_var['goods']['click_count']; ?></span>次&nbsp;|&nbsp;已被评论<a rel="nofollow" href="<?php echo $this->_var['back_act']; ?>#ECS_COMMENT"><span><?php 
$k = array (
  'name' => 'pl_sum',
  'goods_id' => $this->_var['goods']['goods_id'],
);
echo $this->_echash . $k['name'] . '|' . serialize($k) . $this->_echash;
?></span></a>次 </div>
        <div class="add_fav"> 
          
          <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare"> <span class="bds_more">分享到：</span> <a class="bds_qzone"></a> <a class="bds_tsina"></a> <a class="bds_tqq"></a> <a class="bds_renren"></a> <a class="shareCount"></a> </div>
          <script type="text/javascript" id="bdshare_js" data="type=tools" ></script> 
          <script type="text/javascript" id="bdshell_js"></script> 
          <script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script> 
           
        </div>
        <div class="activity">
          <div class="t">商城推荐：</div>
          <div class="c">
            <ul>
              <li><span>●</span>&nbsp;零售商优惠活动：凡“购满”2000元以上的，立即减200元</li>
              <li><span>●</span>&nbsp;零售商优惠活动：凡“购满”3000元以上的，立即减300元</li>
              <li><span>●</span>&nbsp;零售商优惠活动：凡“购满”4000元以上的，立即减400元</li>
            </ul>
          </div>
        </div>
        <div class="reg"> </a><a href="user.php?act=register" rel="nofollow">马上注册成为会员</a> </div>
      </form>
    </div>
    <div class="blank"></div>
  </div>
    <?php if ($this->_var['goods']['goodsdesc']): ?>
  <div class="brand_story">
          <div class="t">
            <div class="g__brand_story"></div>
          </div>
                    <div class="c">
                    
                    <?php echo $this->_var['goods']['goodsdesc']; ?>
     
</div>
                    
        </div>
  <?php endif; ?>
  <div class="blank5 clearfix"></div>
  
  
  <div class="AreaL">
  <div id="hot_sale">
      <div class="l__hot_sale"></div>
      <ul>
        <?php $_from = $this->_var['hotgoods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'hotgoods_0_90304000_1388938796');if (count($_from)):
    foreach ($_from AS $this->_var['hotgoods_0_90304000_1388938796']):
?>
        <li> <a class="img" target="_blank" href="<?php echo $this->_var['hotgoods_0_90304000_1388938796']['url']; ?>"><img src="<?php echo $this->_var['hotgoods_0_90304000_1388938796']['goods_thumb']; ?>" alt="<?php echo htmlspecialchars($this->_var['hotgoods_0_90304000_1388938796']['goods_name']); ?>" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="<?php echo $this->_var['hotgoods_0_90304000_1388938796']['url']; ?>"><?php echo $this->_var['hotgoods_0_90304000_1388938796']['short_name']; ?></a> <span class="price"><?php echo $this->_var['hotgoods_0_90304000_1388938796']['shop_price']; ?></span> </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
  
    <?php echo $this->fetch('library/goods_article.lbi'); ?>
    <?php echo $this->fetch('library/goods_attrlinked.lbi'); ?>
    
    
    <div class="blank5"></div> 
         
        <div id="news_list">
        	<div class="tab">
            	<ul>
				  <li class="cur">最新资讯</li> 	
                </ul>
            </div>
			                        
                          <div class="page cur">
                          <ul>
                           <?php $this->assign('articles',get_article_new(array(32),'art_cat',10,0));?>
                          <?php $_from = $this->_var['articles']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'article');$this->_foreach['curart'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curart']['total'] > 0):
    foreach ($_from AS $this->_var['article']):
        $this->_foreach['curart']['iteration']++;
?>
                              <li><a href="<?php echo $this->_var['article']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['article']['title']); ?>" rel="nofollow"><?php echo sub_str($this->_var['article']['title'],13); ?></a></li>
                          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
                          </ul>
                          </div>
						  </div>
                          
                          
                                      
        </div>
  
  <div class="AreaR">
  
  <div class="box">
      <div id="desc">
      <div class="tab"> <a class="m1 cur" title="商品详情" href="javascript:void(0);"></a> <a class="m2" title="货到付款" href="javascript:void(0);"></a> <a class="m3" title="支付配送" href="javascript:void(0);"></a> <a class="m4" title="购物流程" href="javascript:void(0);"></a></div>
    <div class="clearfix">
      <div id="com_v" class="mt10"></div>
      <div id="com_h">
        <div class="page cur">
          <div class="t">
            <div class="g__product_detail"></div>
          </div>
          <img src="themes/wbw2012/images/fwcn.jpg" width="788" />
          <div class="blank"></div>
          <div style="margin:0 30px 0 58px;">
          <table><tr><td>
            <?php echo $this->_var['goods']['goods_desc']; ?>
            </td></tr></table>
           
          </div>
          <div class="blank5"></div>
          <center>
            <div class="clear"></div>
            <?php $_from = $this->_var['pictures']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'picture');if (count($_from)):
    foreach ($_from AS $this->_var['picture']):
?>
            <li><img src="<?php if ($this->_var['picture']['img_url']): ?><?php echo $this->_var['picture']['img_url']; ?><?php else: ?><?php echo $this->_var['picture']['img_url']; ?><?php endif; ?>" alt="<?php echo $this->_var['goods']['goods_name']; ?>" class="B_blue" /></li>
            <li>
              <h4><?php echo $this->_var['picture']['img_desc']; ?></h4>
            </li>
            <br />
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
          </center>
          <div class="blank"></div>
           <?php echo $this->fetch('library/comments.lbi'); ?>
        </div>
       <div class="page">
          <div class="block">
            <div class="t">
              <div class="g__about_us2"><img src="/ad/hd.gif" /></div>
            </div>
            <div class="c">
            <p><img src="/ad/hd_01.jpg" />
            <img src="/ad/hd_02.jpg" />
            <img src="/ad/hd_03.jpg" />
            </p>

            </div>
          </div>
        </div>
     <div class="page">
          <div class="block">
            <div class="t">
              <div class="g__payment"></div>
            </div>
            <div class="c">
             <img src="/ad/zf.jpg" />
            </div>
          </div>
        </div>
      <div class="page">
          <div class="block">
            <div class="t">
              <div class="g__service_commitment"></div>
            </div>
            <div class="c">
            
            <div class="help_content">
                     <p><strong><span style="color: #339966">一.</span></strong><span style="color: #000000">注册成为维美达皮具新会员，点击</span><strong><span style="color: #ff0000"> <a href="/user.php?act=register" rel="nofollow"><span style="color: #ff0000">注册</span></a></span></strong>&nbsp;&nbsp;&nbsp;&nbsp; 如果您不打算注册<span style="color: #000000">“不打算登陆直接购买&nbsp;”</span><strong><span style="color: #ff0000">参考第5条细则</span></strong></p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="548" src="/images/upload/Image/网站购物流程_01.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>二.</strong></span><span style="color: #000000">进入我司网站浏览商品，如果有需要购买的款式直接点击</span><span style="color: #ff0000"><strong>“小图片”</strong></span><span style="color: #000000">进入到商品内页，往后操作流程看下图。</span></p>
<p><br>
<img align="middle" width="790" height="457" src="/images/upload/Image/网站购物流程_02.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>三.</strong></span><span style="color: #000000">点击</span><span style="color: #ff0000"><strong>“立即购买”</strong><span style="color: #000000">按钮，直接进入结算中心。也可以点击</span><strong>“加入购物车”</strong><span style="color: #000000">，如果要挑选其他商品则在选择</span><strong>“继续挑选宝贝”。</strong></span></p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="270" src="/images/upload/Image/网站购物流程_03.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>四.</strong></span><span style="color: #000000">订单核对后点击</span><span style="color: #ff0000"><strong>“去结算”</strong><span style="color: #000000">，</span><span style="color: #000000">如果同个款式商品数量需要增加的，则点击购买数量下的</span><strong>“ +&nbsp; ”</strong></span><span style="color: #000000">按键。</span></p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="312" src="/images/upload/Image/网站购物流程_07.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>五.</strong></span><span style="color: #000000">为方便您实时查看跟进订单情况，请先</span><span style="color: #ff0000"><strong>“注册用户”</strong><span style="color: #000000">，</span><span style="color: #000000">如果不想注册用户的，可以直接选择</span><strong>“不打算登陆，直接购买”</strong>。</span></p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="187" src="/images/upload/Image/网站购物流程_04.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>六.</strong></span><span style="color: #000000">注册成功的用户首次下单需要填写收货信息，往后下单</span><span style="color: #ff0000"><strong>系统自动保存地址</strong><span style="color: #000000">，如果收货信息有变更，可以另外</span><strong>增加收货信息。</strong></span></p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="440" src="/images/upload/Image/网站购物流程_05.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>七.</strong></span>确认您的 <span style="color: #ff0000"><strong>收货人、地址、电话、信息</strong></span><strong> </strong>无误后，在选择配送方式。</p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="543" src="/images/upload/Image/网站购物流程_06.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>八.</strong></span><span style="color: #000000">选择好您的支付方式，如果您订购的商品有其他要求，请在</span><strong><span style="color: #ff0000">“订单附言”</span></strong><span style="color: #000000">里面做简短描述。最后确认无误点击</span><strong><span style="color: #ff0000">“提交订单”</span></strong><span style="color: #000000">，</span><span style="color: #000000">把</span><span style="color: #000000">订单号发给我司客服人员进行核对结算。</span></p>
<p>&nbsp;</p>                   </div>
            </div>
          </div>
        </div>
        
      
      </div>
    </div>
  </div>
  <script type="text/javascript">
    <!--
    reg("com");
    //-->
    </script>
  <div class="blank"></div>
  
  <div id="xingqu">
    <div class="t">
      <div class="g__xingqu"></div>
    </div>
    <div class="tab"> <a href="javascript:void(0);" class="cur" id="one1" onmousemove="setTab('one',1,4)"><?php echo $this->_var['lang']['releate_goods']; ?></a> <a class="" href="javascript:void(0);" id="one2" onmousemove="setTab('one',2,4)"><?php echo $this->_var['lang']['article_releate']; ?></a> <a class="" href="javascript:void(0);" id="one3" onmousemove="setTab('one',3,4)"><?php echo $this->_var['lang']['accessories_releate']; ?></a> <a class="" href="javascript:void(0);" id="one4" onmousemove="setTab('one',4,4)"><?php echo $this->_var['lang']['shopping_and_other']; ?></a> </div>
    <div class="page cur" id="con_one_1">
      <ul>
        <?php $_from = $this->_var['related_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'releated_goods_data');if (count($_from)):
    foreach ($_from AS $this->_var['releated_goods_data']):
?>
        <li> <a href="<?php echo $this->_var['releated_goods_data']['url']; ?>" title="<?php echo $this->_var['releated_goods_data']['goods_name']; ?>"> <img style="display: inline;" src="<?php echo $this->_var['releated_goods_data']['goods_thumb']; ?>" alt="<?php echo $this->_var['releated_goods_data']['goods_name']; ?>"><span><?php echo $this->_var['releated_goods_data']['short_name']; ?></span></a><span><?php if ($this->_var['releated_goods_data']['promote_price'] != 0): ?> 
          <?php echo $this->_var['releated_goods_data']['formated_promote_price']; ?> 
          <?php else: ?> 
          <?php echo $this->_var['releated_goods_data']['shop_price']; ?> 
          <?php endif; ?></span> </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
    <div class="page" id="con_one_2">
      <ul class="articles">
      
      </ul>
    </div>
    <div class="page" id="con_one_3">
      <ul>
        <?php $_from = $this->_var['fittings']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'goods_0_90370600_1388938796');if (count($_from)):
    foreach ($_from AS $this->_var['goods_0_90370600_1388938796']):
?>
        <li> <a href="<?php echo $this->_var['goods_0_90370600_1388938796']['url']; ?>" title="<?php echo $this->_var['goods_0_90370600_1388938796']['goods_name']; ?>"> <img style="display: inline;" src="<?php echo $this->_var['goods_0_90370600_1388938796']['goods_thumb']; ?>" alt="<?php echo $this->_var['goods_0_90370600_1388938796']['goods_name']; ?>"><span><?php echo $this->_var['goods_0_90370600_1388938796']['short_name']; ?></span></a><span><?php echo $this->_var['goods_0_90370600_1388938796']['fittings_price']; ?></span> </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
    <div class="page" id="con_one_4">
      <ul>
        <?php $_from = $this->_var['bought_goods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'bought_goods_data');if (count($_from)):
    foreach ($_from AS $this->_var['bought_goods_data']):
?>
        <li> <a href="<?php echo $this->_var['bought_goods_dataurl']; ?>" title="<?php echo $this->_var['bought_goods_data']['goods_name']; ?>"> <img style="display: inline;" src="<?php echo $this->_var['bought_goods_data']['goods_thumb']; ?>" alt="<?php echo $this->_var['bought_goods_data']['goods_name']; ?>"><span><?php echo $this->_var['bought_goods_data']['short_name']; ?></span></a><span><?php if ($this->_var['bought_goods_data']['promote_price'] != 0): ?> 
          <?php echo $this->_var['bought_goods_data']['formated_promote_price']; ?> 
          <?php else: ?> 
          <?php echo $this->_var['bought_goods_data']['shop_price']; ?> 
          <?php endif; ?></span> </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
  </div>
  </div>
  <div class="blank5 clearfix"></div>
  </div>
</div>
<?php echo $this->fetch('library/help.lbi'); ?> <?php echo $this->fetch('library/page_footer.lbi'); ?>
</body>



<script type="text/javascript">



var goods_id = <?php echo $this->_var['goods_id']; ?>;
var goodsattr_style = <?php echo empty($this->_var['cfg']['goodsattr_style']) ? '1' : $this->_var['cfg']['goodsattr_style']; ?>;
var gmt_end_time = <?php echo empty($this->_var['promote_end_time']) ? '0' : $this->_var['promote_end_time']; ?>;
<?php $_from = $this->_var['lang']['goods_js']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('key', 'item');if (count($_from)):
    foreach ($_from AS $this->_var['key'] => $this->_var['item']):
?>
var <?php echo $this->_var['key']; ?> = "<?php echo $this->_var['item']; ?>";
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
var goodsId = <?php echo $this->_var['goods_id']; ?>;
var now_time = <?php echo $this->_var['now_time']; ?>;


onload = function(){

  changePrice();
  fixpng();
  try {onload_leftTime();}
  catch (e) {}
}

/**
 * 点选可选属性或改变数量时修改商品价格的函数
 */
function changePrice()
{
  var attr = getSelectedAttributes(document.forms['ECS_FORMBUY']);
  var qty = document.forms['ECS_FORMBUY'].elements['number'].value;

  Ajax.call('goods.php', 'act=price&id=' + goodsId + '&attr=' + attr + '&number=' + qty, changePriceResponse, 'GET', 'JSON');
}

/**
 * 接收返回的信息
 */
function changePriceResponse(res)
{
  if (res.err_msg.length > 0)
  {
    alert(res.err_msg);
  }
  else
  {
    document.forms['ECS_FORMBUY'].elements['number'].value = res.qty;

    if (document.getElementById('ECS_GOODS_AMOUNT'))
      document.getElementById('ECS_GOODS_AMOUNT').innerHTML = res.result;
  }
}

/*
*选择信息处理
*/
function changeP(b, c) {
	var frm=document.forms['ECS_FORMBUY'];
	var cur_id="";
    document.getElementById('spec_value_' + c).checked=true;
	document.getElementById('url_' + c).className="selected";
	for (var i = 0; i < frm.elements[b].length; i++) {
		cur_id=frm.elements[b][i].id.substr(11);
        document.getElementById('url_' + cur_id).className="";
		if (frm.elements[b][i].checked)
		{
		   document.getElementById('url_' + c).className="selected";
		}
    }
	changePrice();
}

</script>
</html>
