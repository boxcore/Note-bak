<?php 
   require_once("themes/".$GLOBALS['_CFG']['template']."/diyfile.php");
   $this->assign('TemplatePath','themes/'.$GLOBALS['_CFG']['template']);
?>
<link href="/themes/wbw2012/page_header.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/themes/wbw2012/js/chrome.js"></script>
<script type="text/javascript">
var process_request = "<?php echo $this->_var['lang']['process_request']; ?>";
</script>
<script type="text/javascript">
var navmenu="1"
    try
    {
        document.getElementById("atitle" + navmenu).className = "acur";
    } catch (ex) {}
    $(".main_menu li").bind("mouseover", function ()
    {
        $(this).find("a").eq(0).attr("class", "aon");
        $(this).find("#dz"+ navmenu).show();
    });
    $(".main_menu li").bind("mouseleave", function ()
    {
        $(this).find("#dz"+ navmenu).hide();
        $(this).find("a").attr("class", "");
        $("#atitle" + navmenu).attr("class", "acur");
    });
</script>
<div id="header">
  <div class="top" style="z-index:19; height:27px;">
    <?php echo $this->smarty_insert_scripts(array('files'=>'utils.js')); ?>
    <?php 
$k = array (
  'name' => 'member_info',
);
echo $this->_echash . $k['name'] . '|' . serialize($k) . $this->_echash;
?>
    <?php $_from = $this->_var['navigator_list']['top']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'nav');$this->_foreach['nav_top_list'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['nav_top_list']['total'] > 0):
    foreach ($_from AS $this->_var['nav']):
        $this->_foreach['nav_top_list']['iteration']++;
?>
    <span><a href="<?php echo $this->_var['nav']['url']; ?>" rel="nofollow" <?php if ($this->_var['nav']['opennew'] == 1): ?> target="_blank"<?php endif; ?>><?php echo $this->_var['nav']['name']; ?></a></span>
    <?php if (! ($this->_foreach['nav_top_list']['iteration'] == $this->_foreach['nav_top_list']['total'])): ?>
    <span>&nbsp;|&nbsp;</span>
    <?php endif; ?>
    <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    
     <a style="height:28px; position:relative;z-index: 19;" class="weixin" id="weixin" onmouseover="mouseOver()" onmouseout="mouseOut()">   
                               
                   <img src="/images/weixinlogo.jpg" width="67" height="26"></a>
                      <a style="display: none;" class="weixin_pic" id="weixin_pic"> 
                  <img alt="维美达皮具网" src="/images/weixinerweima.jpg"></a>
    
    <span class="s__cart" id="ECS_CARTINFO"><?php 
$k = array (
  'name' => 'cart_info',
);
echo $this->_echash . $k['name'] . '|' . serialize($k) . $this->_echash;
?><span class="s__arrow_red_down"></span></span></div>
  <h1><a href="index.php" title="LV官网_路易威登_LV女包_lv包价格_lv包批发_LV男包_LV皮带"><img src="themes/wbw2012/images/logo.gif" alt="LV官网_路易威登_LV女包_lv包价格_lv包批发_LV男包_LV皮带" ></a></h1>
  <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()">
    <input type="text" name="keywords" id="w" onMouseOver="this.focus()" onblur="if(this.value =='') this.value='请输入商品名称或编号'" onFocus="this.select()" onClick="if(this.value=='请输入商品名称或编号') this.value=''" value="请输入商品名称或编号" class="txt" />
    <input type="submit" value=" " class="s__search" style="cursor:pointer;" />
  </form>
  <span id="hotline"><img src="/themes/wbw2012/images/4006.jpg"></span>
</div>
<div class="menu">
<div id="chromemenu" class="chromestyle clearfix">
<ul>
<li id="dropmenu_home"><a href="./">网站首页</a></li>
<li id="dropmenu_women"><a rel="dropmenu1" href="/ding/">名牌包包</a></li>
<li id="dropmenu_man"><a rel="dropmenu2" href="/xiezi/">名牌鞋子</a></li>
<li id="dropmenu_watch"><a rel="dropmenu3" href="/pidai/">名牌皮带</a></li>
<li id="dropmenu_shoushi"><a rel="dropmenu4" href="/shoushi/">名牌首饰</a></li>
<li id="dropmenu_belt"><a rel="dropmenu5" href="/mojing/">名牌眼睛</a></li>
<li id="dropmenu_wallet"><a rel="dropmenu6" href="/mao/">名牌帽子</a></li>
<li id="dropmenu_shijing"><a rel="dropmenu7" href="/sijin/">丝巾</a></li>
<li id="dropmenu_acc"><a  href="/pinpai.html">品牌纵览</a></li>
<li id="dropmenu_glass"><a href="/new.html">新品上架</a></li>
<li id="dropmenu_shoe"><a href="/article-202.html">加盟代理</a></li>
</ul>
</div>
<style>
.dropmenudiv ul {
    background: none repeat scroll 0 0 #FFFFFF;

    float: left;
    width: 600px;
}
.dropmenudiv ul li {
  
    clear: both;
    color: #999999;
    font-size: 12px;
    line-height: 30px;
}

.dropmenudiv h3 {
    color: #8A5D1A;
    float: left;
    font-weight: bold;
    line-height: 30px;
    margin: 0;
    padding: 0;
    text-indent: 8px;
    width: 96px;
}
.dropmenudiv h3 a {
    color: #8A5D1A;
}
.dropmenudiv h3 a:hover {
    background-color: #8A5D1A;
    color: #FFFFFF;
}
</style>                                                   
<div style="_width:750px;" class="dropmenudiv" id="dropmenu1">
   <ul>
<?php $_from = get_categories_tree(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'cat');$this->_foreach['catnum'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catnum']['total'] > 0):
    foreach ($_from AS $this->_var['cat']):
        $this->_foreach['catnum']['iteration']++;
?>
       <?php if ($this->_var['cat']['id'] == "10"): ?>
          <li>

    <h3><a title="<?php echo htmlspecialchars($this->_var['cat']['name']); ?>" href="<?php echo $this->_var['cat']['url']; ?>"><?php echo htmlspecialchars($this->_var['cat']['name']); ?>:</a></h3>

 
    <?php $_from = $this->_var['cat']['cat_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'child');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['child']):
        $this->_foreach['curn']['iteration']++;
?>
  
    <a href="<?php echo $this->_var['child']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['child']['name']); ?>"><b><?php echo htmlspecialchars($this->_var['child']['name']); ?></b></a><i>|</i>
   
    <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
 </li>
<?php endif; ?>
         <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </ul>
</div>
                                              
<div style="_width:650px;" class="dropmenudiv" id="dropmenu2">
  <ul>
<?php $_from = get_categories_tree(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'cat');$this->_foreach['catnum'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catnum']['total'] > 0):
    foreach ($_from AS $this->_var['cat']):
        $this->_foreach['catnum']['iteration']++;
?>
       <?php if ($this->_var['cat']['id'] == "24"): ?>
          <li>

    <h3><a title="<?php echo htmlspecialchars($this->_var['cat']['name']); ?>" href="<?php echo $this->_var['cat']['url']; ?>"><?php echo htmlspecialchars($this->_var['cat']['name']); ?>:</a></h3>

 
    <?php $_from = $this->_var['cat']['cat_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'child');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['child']):
        $this->_foreach['curn']['iteration']++;
?>
  
    <a href="<?php echo $this->_var['child']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['child']['name']); ?>"><b><?php echo htmlspecialchars($this->_var['child']['name']); ?></b></a><i>|</i>
   
    <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
 </li>
<?php endif; ?>
         <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </ul>
</div>
                                                   
<div style="_width:650px;" class="dropmenudiv" id="dropmenu3">
  <ul>
<?php $_from = get_categories_tree(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'cat');$this->_foreach['catnum'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catnum']['total'] > 0):
    foreach ($_from AS $this->_var['cat']):
        $this->_foreach['catnum']['iteration']++;
?>
       <?php if ($this->_var['cat']['id'] == "21"): ?>
          <li>

    <h3><a title="<?php echo htmlspecialchars($this->_var['cat']['name']); ?>" href="<?php echo $this->_var['cat']['url']; ?>"><?php echo htmlspecialchars($this->_var['cat']['name']); ?>:</a></h3>

 
    <?php $_from = $this->_var['cat']['cat_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'child');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['child']):
        $this->_foreach['curn']['iteration']++;
?>
  
    <a href="<?php echo $this->_var['child']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['child']['name']); ?>"><b><?php echo htmlspecialchars($this->_var['child']['name']); ?></b></a><i>|</i>
   
    <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
 </li>
<?php endif; ?>
         <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </ul>
</div>

<div style="_width:670px;" class="dropmenudiv" id="dropmenu4">
  <ul>
<?php $_from = get_categories_tree(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'cat');$this->_foreach['catnum'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catnum']['total'] > 0):
    foreach ($_from AS $this->_var['cat']):
        $this->_foreach['catnum']['iteration']++;
?>
       <?php if ($this->_var['cat']['id'] == "604"): ?>
          <li>

    <h3><a title="<?php echo htmlspecialchars($this->_var['cat']['name']); ?>" href="<?php echo $this->_var['cat']['url']; ?>"><?php echo htmlspecialchars($this->_var['cat']['name']); ?>:</a></h3>

 
    <?php $_from = $this->_var['cat']['cat_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'child');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['child']):
        $this->_foreach['curn']['iteration']++;
?>
  
    <a href="<?php echo $this->_var['child']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['child']['name']); ?>"><b><?php echo htmlspecialchars($this->_var['child']['name']); ?></b></a><i>|</i>
   
    <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
 </li>
<?php endif; ?>
         <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </ul>
</div>
                                                   
<div style="_width:630px;" class="dropmenudiv" id="dropmenu5">
  <ul>
<?php $_from = get_categories_tree(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'cat');$this->_foreach['catnum'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catnum']['total'] > 0):
    foreach ($_from AS $this->_var['cat']):
        $this->_foreach['catnum']['iteration']++;
?>
       <?php if ($this->_var['cat']['id'] == "25"): ?>
          <li>

    <h3><a title="<?php echo htmlspecialchars($this->_var['cat']['name']); ?>" href="<?php echo $this->_var['cat']['url']; ?>"><?php echo htmlspecialchars($this->_var['cat']['name']); ?>:</a></h3>

 
    <?php $_from = $this->_var['cat']['cat_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'child');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['child']):
        $this->_foreach['curn']['iteration']++;
?>
  
    <a href="<?php echo $this->_var['child']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['child']['name']); ?>"><b><?php echo htmlspecialchars($this->_var['child']['name']); ?></b></a><i>|</i>
   
    <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
 </li>
<?php endif; ?>
         <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </ul>
</div>

<div style="_width:530px;" class="dropmenudiv" id="dropmenu6">
  <ul>
<?php $_from = get_categories_tree(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'cat');$this->_foreach['catnum'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catnum']['total'] > 0):
    foreach ($_from AS $this->_var['cat']):
        $this->_foreach['catnum']['iteration']++;
?>
       <?php if ($this->_var['cat']['id'] == "23"): ?>
          <li>

    <h3><a title="<?php echo htmlspecialchars($this->_var['cat']['name']); ?>" href="<?php echo $this->_var['cat']['url']; ?>"><?php echo htmlspecialchars($this->_var['cat']['name']); ?>:</a></h3>

 
    <?php $_from = $this->_var['cat']['cat_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'child');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['child']):
        $this->_foreach['curn']['iteration']++;
?>
  
    <a href="<?php echo $this->_var['child']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['child']['name']); ?>"><b><?php echo htmlspecialchars($this->_var['child']['name']); ?></b></a><i>|</i>
   
    <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
 </li>
<?php endif; ?>
         <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </ul>
</div>                                                   

<div style="_width:530px;" class="dropmenudiv" id="dropmenu7">
  <ul>
<?php $_from = get_categories_tree(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'cat');$this->_foreach['catnum'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['catnum']['total'] > 0):
    foreach ($_from AS $this->_var['cat']):
        $this->_foreach['catnum']['iteration']++;
?>
       <?php if ($this->_var['cat']['id'] == "626"): ?>
          <li>

    <h3><a title="<?php echo htmlspecialchars($this->_var['cat']['name']); ?>" href="<?php echo $this->_var['cat']['url']; ?>"><?php echo htmlspecialchars($this->_var['cat']['name']); ?>:</a></h3>

 
    <?php $_from = $this->_var['cat']['cat_id']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'child');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['child']):
        $this->_foreach['curn']['iteration']++;
?>
  
    <a href="<?php echo $this->_var['child']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['child']['name']); ?>"><b><?php echo htmlspecialchars($this->_var['child']['name']); ?></b></a><i>|</i>
   
    <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
 </li>
<?php endif; ?>
         <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </ul>
</div>  

<script type="text/javascript">cssdropdown.startchrome("chromemenu")</script>
</div>
