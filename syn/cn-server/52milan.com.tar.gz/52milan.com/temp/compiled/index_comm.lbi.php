<?php $this->assign('my_comments',index_comments(6));?>
 <ul>
 <?php $_from = $this->_var['my_comments']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'comments');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['comments']):
        $this->_foreach['curn']['iteration']++;
?>
   <?php if ($this->_foreach['curn']['iteration'] < 4): ?>
      <li><span><a href="<?php echo $this->_var['comments']['url']; ?>" target="_blank"><?php echo sub_str($this->_var['comments']['content'],30); ?></a></span><i><?php echo $this->_var['comments']['add_time']; ?></i></li>  
     <?php endif; ?>             						
   <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>           						         			            			            			            			
 </ul>
       
  <ul>
   <?php $_from = $this->_var['my_comments']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'comments');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['comments']):
        $this->_foreach['curn']['iteration']++;
?>
   <?php if ($this->_foreach['curn']['iteration'] > 3): ?>
      <li><span><a href="<?php echo $this->_var['comments']['url']; ?>" target="_blank"><?php echo sub_str($this->_var['comments']['content'],30); ?></a></span><i><?php echo $this->_var['comments']['add_time']; ?></i></li>  
     <?php endif; ?>             						
   <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>                     
   </ul>