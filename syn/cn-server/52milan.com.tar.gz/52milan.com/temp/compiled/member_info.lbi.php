<?php if ($this->_var['user_info']): ?>
<span>
 您好，<font class="f1"><?php echo $this->_var['user_info']['username']; ?></font>，
 <a href="user.php"><?php echo $this->_var['lang']['user_center']; ?></a>
 <a href="user.php?act=logout">退出</a>
 </span>
<?php else: ?>
	<span><a href="/article-32/" title="名包资讯" >名包资讯</a></span> <span>&nbsp;|&nbsp;</span><span><a href="/user.php" title="登录" rel="nofollow">登录</a></span><span>&nbsp;|&nbsp;</span><span><a href="/user.php?act=register" title="注册" rel="nofollow">注册</a></span><span>&nbsp;|&nbsp;</span>
<?php endif; ?>