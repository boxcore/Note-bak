<?php if ($this->_var['helps']): ?>      
<div id="footerh">
	<div class="help">
        <?php $_from = $this->_var['helps']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'help_cat');$this->_foreach['curn'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curn']['total'] > 0):
    foreach ($_from AS $this->_var['help_cat']):
        $this->_foreach['curn']['iteration']++;
?>
            	<dl class="help_menu_item_<?php echo $this->_foreach['curn']['iteration']; ?>">
                	<dt><?php echo $this->_var['help_cat']['cat_name']; ?></dt>
                    <?php $_from = $this->_var['help_cat']['article']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'item_0_86444500_1388938809');if (count($_from)):
    foreach ($_from AS $this->_var['item_0_86444500_1388938809']):
?>
                  <dd><a href="/<?php echo $this->_var['item_0_86444500_1388938809']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['item_0_86444500_1388938809']['title']); ?>" target="_blank"  rel="nofollow"><?php echo $this->_var['item_0_86444500_1388938809']['short_title']; ?></a></dd>
                  <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
                </dl>
         <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </div>
</div> 
<?php endif; ?>