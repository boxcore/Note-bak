<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<base href="http://www.52milan.com/" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="<?php echo $this->_var['keywords']; ?>" />
<meta name="description" content="<?php echo $this->_var['description']; ?>" />

<title>
<?php if ($this->_var['filter_attr_list']): ?>
<?php $_from = $this->_var['filter_attr_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'filter_attr_0_50435700_1388938668');if (count($_from)):
    foreach ($_from AS $this->_var['filter_attr_0_50435700_1388938668']):
?>
<?php $_from = $this->_var['filter_attr_0_50435700_1388938668']['attr_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'attr');if (count($_from)):
    foreach ($_from AS $this->_var['attr']):
?>
<?php if ($this->_var['attr']['selected']): ?>
<?php echo $this->_var['attr']['attr_value']; ?>
<?php else: ?>
<?php endif; ?>
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
<?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
<?php echo $this->_var['cat_title']; ?>
<?php else: ?>
<?php echo $this->_var['cat_title']; ?>
<?php endif; ?>
</title>



<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="<?php echo $this->_var['ecs_css_path']; ?>" rel="stylesheet" type="text/css" />
<?php if ($this->_var['cat_style']): ?>
<link href="<?php echo $this->_var['cat_style']; ?>" rel="stylesheet" type="text/css" />
<?php endif; ?>

<?php echo $this->smarty_insert_scripts(array('files'=>'common.js,jquery-1.4.4.min.js')); ?>
</head><body>
<?php echo $this->fetch('library/page_header.lbi'); ?>
<script type="text/javascript" src="<?php echo $this->_var['TemplatePath']; ?>/js/compare_ec.js"></script>
<div class="blank"></div>
<div class="block clearfix">
  <div id="ur_here">
    <div class="f_l"><?php echo $this->fetch('library/ur_here.lbi'); ?></div>
    <div class="f_r">
      
      <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare"> <span class="bds_more">分享到：</span> <a class="bds_qzone"></a> <a class="bds_tsina"></a> <a class="bds_tqq"></a> <a class="bds_renren"></a> <a class="shareCount"></a> </div>
      <script type="text/javascript" id="bdshare_js" data="type=tools" ></script>
      <script type="text/javascript" id="bdshell_js"></script>
      <script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
      
    </div>
  </div>
  <div class="block box"> <a href="/new.html"> <img src="/data/afficheimg/1356659573508413815.jpg" alt="包包" width="1000" height="125"></a> </div>
  <div class="blank"></div>
  
  <div class="AreaL">
    
     <?php $this->assign('ads_id','1'); ?><?php $this->assign('ads_num','0'); ?><?php echo $this->fetch('library/ad_position.lbi'); ?> 
    
     <div class="blank"></div>
    <div id="news_listview">
      <div class="tab">
        <ul>
          <li class="cur">相关描叙</li>
        </ul>
      </div>
      <div class="page cur">
        <p>
     
       <?php if ($this->_var['new_articles']['content']): ?>
        <?php echo sub_str($this->_var['new_articles']['content'],360); ?>
       <?php else: ?>
      <?php echo sub_str($this->_var['new_articles']['goodsdesc'],360); ?>
      <?php endif; ?>        
        </p>
      </div>
    </div>
    <div class="blank"></div>
    <div id="hot_sale">
      <div class="l__hot_sale"></div>
      <ul>
        <?php $_from = $this->_var['hotgoods']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'hotgoods_0_50483300_1388938668');if (count($_from)):
    foreach ($_from AS $this->_var['hotgoods_0_50483300_1388938668']):
?>
        <li> <a class="img" target="_blank" href="/<?php echo $this->_var['hotgoods_0_50483300_1388938668']['url']; ?>"><img src="<?php echo $this->_var['hotgoods_0_50483300_1388938668']['goods_thumb']; ?>"  alt="<?php echo htmlspecialchars($this->_var['hotgoods_0_50483300_1388938668']['goods_name']); ?>" >
       
          </a> <a class="txt" target="_blank" href="/<?php echo $this->_var['hotgoods_0_50483300_1388938668']['url']; ?>"><?php echo $this->_var['hotgoods_0_50483300_1388938668']['short_name']; ?></a> <span class="price"><?php echo $this->_var['hotgoods_0_50483300_1388938668']['shop_price']; ?></span> </li>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </ul>
    </div>
    <div class="blank5"></div>
    <?php echo $this->fetch('library/top10.lbi'); ?>
    <div id="brand_recommended">
      <div class="l__brand_recommeded"></div>
      <div class="c">
        <ul class="logos">
          <?php $_from = $this->_var['brand_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'brand');$this->_foreach['brand_foreach'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['brand_foreach']['total'] > 0):
    foreach ($_from AS $this->_var['brand']):
        $this->_foreach['brand_foreach']['iteration']++;
?>
          <li><a href="<?php echo $this->_var['brand']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['brand']['brand_name']); ?>"><span><img src="data/brandlogo/<?php echo $this->_var['brand']['brand_logo']; ?>" alt="<?php echo htmlspecialchars($this->_var['brand']['brand_name']); ?> (<?php echo $this->_var['brand']['goods_num']; ?>)" /></span><b><?php echo htmlspecialchars($this->_var['brand']['brand_name']); ?> </b></a></li>
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
        </ul>
      </div>
    </div>
    <div class="blank5"></div>
    <div id="news_list">
      <div class="tab">
        <ul>
          <li class="cur">相关文章</li>
          <li class="">包包资讯</li>
          <li class="">网站承诺</li>
        </ul>
      </div>
      <div class="page cur">
        <ul>
          <?php $this->assign('articles',get_article_new(array(28),'art_cat',10,0));?>
          <?php $_from = $this->_var['articles']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'article');$this->_foreach['curart'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curart']['total'] > 0):
    foreach ($_from AS $this->_var['article']):
        $this->_foreach['curart']['iteration']++;
?>
          <li><a href="<?php echo $this->_var['article']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['article']['title']); ?>"><?php echo sub_str($this->_var['article']['title'],13); ?></a></li>
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
        </ul>
      </div>
      <div class="page">
        <ul>
          <?php $this->assign('articles',get_article_new(array(32),'art_cat',10,0));?>
          <?php $_from = $this->_var['articles']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'article');$this->_foreach['curart'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['curart']['total'] > 0):
    foreach ($_from AS $this->_var['article']):
        $this->_foreach['curart']['iteration']++;
?>
          <li><a href="<?php echo $this->_var['article']['url']; ?>" title="<?php echo htmlspecialchars($this->_var['article']['title']); ?>"><?php echo sub_str($this->_var['article']['title'],13); ?></a></li>
          <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
        </ul>
      </div>
      <div class="page">
        <p><?php echo $this->_var['description']; ?></p>
      </div>
    </div>
    <div class="blank"></div>
  </div>
  
  
  <div class="AreaR">
    <?php $this->assign('cate',get_adv('cate',$this->_var['topcat_id']));?>
    <?php if ($this->_var['cate']): ?>
    <?php echo $this->_var['cate']; ?>
    <div class="blank5"></div>
    <?php endif; ?>
    
    <?php if ($this->_var['brands']['1'] || $this->_var['price_grade']['1'] || $this->_var['filter_attr_list']): ?>
    <div class="box_pro">
      <div class="screetit"><span><?php echo $this->_var['lang']['goods_filter']; ?></span></div>
      <?php if ($this->_var['brands']['1']): ?>
      	<div class="next_selected clearfix">
        <div class="next_selected_first"><?php echo $this->_var['lang']['brand']; ?>：</div>
        <div id="classification" class="next_selected_second next_selected_second_fold">
           
           
               
                <?php $_from = $this->_var['brands']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'brand');if (count($_from)):
    foreach ($_from AS $this->_var['brand']):
?>
        <?php if ($this->_var['brand']['selected']): ?>
        <?php if ($this->_var['brand']['brand_name'] == '全部'): ?>
      <?php echo $this->_var['brand']['brand_name']; ?>
       <?php else: ?>
       <span class="zk"><?php echo $this->_var['brand']['brand_name']; ?></span>
       <?php endif; ?>
        <?php else: ?>
        <a href="<?php echo $this->_var['brand']['url']; ?>" title="<?php echo $this->_var['brand']['brand_name']; ?>"><?php echo $this->_var['brand']['brand_name']; ?></a>&nbsp;
        <?php endif; ?>
               
            <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
            
                                                </ul>
        </div>
        <div class="next_selected_folddiv">
            <div class="next_selected_folddiv_word">展开</div>
            <div class="next_selected_folddiv_arrow"></div>
        </div>
    </div>
      <?php endif; ?>
      <?php if ($this->_var['price_grade']['1']): ?>
      <div class="screeBox clearfix"> <strong><?php echo $this->_var['lang']['price']; ?>：</strong>
        <?php $_from = $this->_var['price_grade']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'grade');if (count($_from)):
    foreach ($_from AS $this->_var['grade']):
?>
        <?php if ($this->_var['grade']['selected']): ?>
        <span><?php echo $this->_var['grade']['price_range']; ?></span>
        <?php else: ?>
        <a href="<?php echo $this->_var['grade']['url']; ?>" title="<?php echo $this->_var['grade']['price_range']; ?>"><?php echo $this->_var['grade']['price_range']; ?></a>&nbsp;
        <?php endif; ?>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </div>
      <?php endif; ?>
      <?php $_from = $this->_var['filter_attr_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'filter_attr_0_50583300_1388938668');if (count($_from)):
    foreach ($_from AS $this->_var['filter_attr_0_50583300_1388938668']):
?>
      <div class="screeBox clearfix"> <strong> <?php echo htmlspecialchars($this->_var['filter_attr_0_50583300_1388938668']['filter_attr_name']); ?>： </strong>
        <?php $_from = $this->_var['filter_attr_0_50583300_1388938668']['attr_list']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }; $this->push_vars('', 'attr');if (count($_from)):
    foreach ($_from AS $this->_var['attr']):
?>
        <?php if ($this->_var['attr']['selected']): ?>
        <span><?php echo $this->_var['attr']['attr_value']; ?></span>
        <?php else: ?>
        <a href="<?php echo $this->_var['attr']['url']; ?>" title="<?php echo $this->_var['attr']['attr_value']; ?>"><?php echo $this->_var['attr']['attr_value']; ?></a>&nbsp;
        <?php endif; ?>
        <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
      </div>
      <?php endforeach; endif; unset($_from); ?><?php $this->pop_vars();; ?>
    </div>
    <div class="blank5"></div>
    <?php endif; ?>
    
    <div class="seacher" id=""> <span class="orange bold">你是不是想找：</span> <a href="/search.php?keywords=lv女包">lv女包</a><span class="line">| <a href="/search.php?keywords=女包">女包</a><span class="line">| <a href="/search.php?keywords=男包">男包</a><span class="line">| <a href="/search.php?keywords=单肩包">单肩包</a><span class="line">| <a href="/search.php?keywords=女大包">女大包</a><span class="line">| </span></span></span></span></span></div>
    <?php echo $this->fetch('library/goods_list.lbi'); ?> <?php echo $this->fetch('library/pages.lbi'); ?> </div>
  
</div>
<?php echo $this->fetch('library/help.lbi'); ?> <?php echo $this->fetch('library/page_footer.lbi'); ?>
<script type="text/javascript">
var news_list;
$(function(){
	news_list = $("#news_list");

	//左侧新闻选项卡
	news_list.find("div.tab>ul>li").each(function(idx){
		var this_ = $(this);
		this_.bind("mouseover", function(){
			if(this_.hasClass('cur')==false){
				this_.siblings(".cur").removeClass("cur");	
				news_list.find(".cur").removeClass("cur");
				this_.addClass("cur");
				news_list.find(".page").eq(idx).addClass("cur");
			}
		});
	});
	
});

</script>
<script type="text/javascript">
    
    var current_category_id = "1";
    
    $(document).ready(function(){
       
      
        
        //fliter
        $(".next_selected_second").each(function(){
		    									 
            if($(this).height()>60 && $("#classification > .zk").height()==null){
                $(this).addClass("next_selected_second_big");
                $(this).siblings(".next_selected_folddiv").show();
                $(".next_selected_folddiv").toggle(function(){
                    $(this).siblings(".next_selected_second").removeClass("next_selected_second_big");
                    $(this).children(".next_selected_folddiv_word").text("收起");
                    $(this).siblings(".next_selected_second").addClass("next_selected_second_fold");
                    $(this).children(".next_selected_folddiv_arrow").addClass("next_selected_folddiv_arrow_away");
                },function(){
                    $(this).siblings(".next_selected_second").addClass("next_selected_second_big");
                    $(this).children(".next_selected_folddiv_word").text("展开");
                    $(this).siblings(".next_selected_second").removeClass("next_selected_second_fold");
                    $(this).children(".next_selected_folddiv_arrow").removeClass("next_selected_folddiv_arrow_away");
                })
            }
			else if($(this).height()>60 && $("#classification > .zk").height()>0){
			    $(this).addClass("next_selected_second_fold");
                $(this).siblings(".next_selected_folddiv").show();
				$(this).removeClass("next_selected_second_big");
				$(".next_selected_folddiv > .next_selected_folddiv_word").text("收起");
				$(".next_selected_folddiv > .next_selected_folddiv_arrow").addClass("next_selected_folddiv_arrow_away");
                $(".next_selected_folddiv").toggle(function(){
                  
					
					$(this).siblings(".next_selected_second").addClass("next_selected_second_big");
                    $(this).children(".next_selected_folddiv_word").text("展开");
                    $(this).siblings(".next_selected_second").removeClass("next_selected_second_fold");
                    $(this).children(".next_selected_folddiv_arrow").removeClass("next_selected_folddiv_arrow_away");
					
                },function(){
                    
					  $(this).siblings(".next_selected_second").removeClass("next_selected_second_big");
                    $(this).children(".next_selected_folddiv_word").text("收起");
                    $(this).siblings(".next_selected_second").addClass("next_selected_second_fold");
                    $(this).children(".next_selected_folddiv_arrow").addClass("next_selected_folddiv_arrow_away");
                })
			}
            else if($(this).height()>30 && $(this).height()<60){
                   $(this).siblings(".next_selected_folddiv").hide();
                   $(this).addClass("next_selected_second_small");
            }else if($(this).height()>30 && $(this).height()<60 && $("#classification > .zk").height()>0){
				 $(this).siblings(".next_selected_folddiv").hide();
                 $(this).addClass("next_selected_second_small");
				
				}
            else{
             
				
				$(this).addClass("next_selected_second_big");
                $(this).siblings(".next_selected_folddiv").hide();
            }
        });
    });
    
    
</script>
</body>
</html>
