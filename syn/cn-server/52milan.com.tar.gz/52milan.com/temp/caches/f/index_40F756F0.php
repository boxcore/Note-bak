<?php exit;?>a:3:{s:8:"template";a:6:{i:0;s:69:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/index.dwt";i:1;s:84:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/index_header.lbi";i:2;s:84:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/cat_articles.lbi";i:3;s:82:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/index_comm.lbi";i:4;s:76:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/help.lbi";i:5;s:83:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/page_footer.lbi";}s:7:"expires";i:1388942243;s:8:"maketime";i:1388938643;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<base href="http://www.52milan.com/" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="包包,鞋子,帽子,眼镜,皮带" />
<meta name="Description" content="中国最大的奢侈品商城，每周不定期更新，行业中新品推出最快，商品最全的奢侈品网站。主营：世界名牌包包、名牌鞋子、名牌帽子、名牌眼镜、名牌皮带等。购买奢侈品的顾客，首选米兰精品商城！" />
<title>【米兰精品商城】鞋子、包包、帽子、眼镜、皮带批发|名牌皮具的领航者!</title>
<link rel="shortcut icon" href="favicon.ico" />
<link href="themes/wbw2012/style.css" rel="stylesheet" type="text/css" />
<link href="/themes/wbw2012/home.css" rel="stylesheet" type="text/css" />
<link href="/themes/wbw2012/baobao.css" rel="stylesheet" type="text/css" />
<link rel="alternate" type="application/rss+xml" title="RSS|【米兰精品商城】鞋子、包包、帽子、眼镜、皮带批发|名牌皮具的领航者!" href="feed.xml" />
<link rel="stylesheet" type="text/css" href="/themes/wbw2012/index.css" media="all" />
<script type="text/javascript" src="js/common.js"></script><script type="text/javascript" src="/js/jquery-1.4.4.min.js" ></script>
<script type="text/javascript" src="/themes/wbw2012/js/all.js"></script>
<script type="text/javascript" src="/themes/wbw2012/js/index.js"></script>
<script type="text/javascript" src="/themes/wbw2012/js/beand.js"></script>
<script type="text/javascript" src="/themes/wbw2012/js/globals.js"></script>
<script type="text/javascript">
cats_in_index = true;
is_ie67 = false;
</script>
<style type="text/css">
/* maxwidth limit for content images */
#content img, .content img, .archive img, .post img {
	margin-top:3px;
	max-width:600px;
_width:expression(this.width>600?600:auto);
}
/* style for slideshow images */
.slideshow_imgs {
	cursor:url(/zoomin.cur), pointer;
}
.slideshow_imgs:hover {
	opacity:0.5;
	filter:alpha(opacity=50);
}
</style>
<style type="text/css">
.lh_lazyimg {
	opacity:0.2;
	filter:alpha(opacity=20);
	background:url(/placeholder.png) no-repeat center center;
}
</style>
<noscript>
<style type="text/css">
.lh_lazyimg {
	display:none;
}
</style>
</noscript>
<script type="text/javascript">
jQuery(document).ready(function($) {
	function lazyload(){
		$("img.lh_lazyimg").each(function(){
			_self = $(this);
			if (_self.attr("lazyloadpass")===undefined
					&& _self.attr("file")
					&& (!_self.attr("src")
							|| (_self.attr("src") && _self.attr("file")!=_self.attr("src"))
						)
				) {
				if((_self.offset().top) < $(window).height()+$(document).scrollTop()
						&& (_self.offset().left) < $(window).width()+$(document).scrollLeft()
					) {
					_self.attr("src",_self.attr("file"));
					_self.attr("lazyloadpass", "1");
					_self.animate({opacity:1}, 500);
				}
			}
		});
	}
	lazyload();
	var itv;
	$(window).scroll(function(){clearTimeout(itv);itv=setTimeout(lazyload,200);});
	$(window).resize(function(){clearTimeout(itv);itv=setTimeout(lazyload,200);});
});
</script>
<!--<script type="text/javascript"> 
$(document).ready(function() {  
       $(".dt_small a img").each(function(i) {  
         $(this).width("100%");  
       });  
   });
$(document).ready(function() {  
       $(".dt_big a img").each(function(i) {  
         $(this).width("100%");  
       });  
   }); 
</script>-->
</head><body onload="datasrc();">
<link href="/themes/wbw2012/page_header.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="/themes/wbw2012/js/chrome.js"></script>
<script type="text/javascript">
var process_request = "正在处理您的请求...";
</script>
<script type="text/javascript">
var navmenu="1"
    try
    {
        document.getElementById("atitle" + navmenu).className = "acur";
    } catch (ex) {}
    $(".main_menu li").bind("mouseover", function ()
    {
        $(this).find("a").eq(0).attr("class", "aon");
        $(this).find("#dz"+ navmenu).show();
    });
    $(".main_menu li").bind("mouseleave", function ()
    {
        $(this).find("#dz"+ navmenu).hide();
        $(this).find("a").attr("class", "");
        $("#atitle" + navmenu).attr("class", "acur");
    });
</script>
<div id="header">
  <div class="top" style="z-index:19; height:27px;">
    <script type="text/javascript" src="js/utils.js"></script>    554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca        <span><a href="http://www.lvbaopifa.com/article-97.html" rel="nofollow" >帮助中心</a></span>
            
     <a style="height:28px; position:relative;z-index: 19;" class="weixin" id="weixin" onmouseover="mouseOver()" onmouseout="mouseOut()">   
                               
                   <img src="/images/weixinlogo.jpg" width="67" height="26"></a>
                      <a style="display: none;" class="weixin_pic" id="weixin_pic"> 
                  <img alt="维美达皮具网" src="/images/weixinerweima.jpg"></a>
    
    <span class="s__cart" id="ECS_CARTINFO">554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca<span class="s__arrow_red_down"></span></span></div>
  <h1><a href="index.php" title="LV官网_路易威登_LV女包_lv包价格_lv包批发_LV男包_LV皮带"><img src="themes/wbw2012/images/logo.gif" alt="LV官网_路易威登_LV女包_lv包价格_lv包批发_LV男包_LV皮带" ></a></h1>
  <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()">
    <input type="text" name="keywords" id="w" onMouseOver="this.focus()" onblur="if(this.value =='') this.value='请输入商品名称或编号'" onFocus="this.select()" onClick="if(this.value=='请输入商品名称或编号') this.value=''" value="请输入商品名称或编号" class="txt" />
    <input type="submit" value=" " class="s__search" style="cursor:pointer;" />
  </form>
  <span id="hotline"><img src="/themes/wbw2012/images/4006.jpg"></span>
</div>
<div class="menu">
<div id="chromemenu" class="chromestyle clearfix">
<ul>
<li id="dropmenu_home"><a href="./">网站首页</a></li>
<li id="dropmenu_women"><a rel="dropmenu1" href="/ding/">名牌包包</a></li>
<li id="dropmenu_man"><a rel="dropmenu2" href="/xiezi/">名牌鞋子</a></li>
<li id="dropmenu_watch"><a rel="dropmenu3" href="/pidai/">名牌皮带</a></li>
<li id="dropmenu_shoushi"><a rel="dropmenu4" href="/shoushi/">名牌首饰</a></li>
<li id="dropmenu_belt"><a rel="dropmenu5" href="/mojing/">名牌眼睛</a></li>
<li id="dropmenu_wallet"><a rel="dropmenu6" href="/mao/">名牌帽子</a></li>
<li id="dropmenu_shijing"><a rel="dropmenu7" href="/sijin/">丝巾</a></li>
<li id="dropmenu_acc"><a  href="/pinpai.html">品牌纵览</a></li>
<li id="dropmenu_glass"><a href="/new.html">新品上架</a></li>
<li id="dropmenu_shoe"><a href="/article-202.html">加盟代理</a></li>
</ul>
</div>
<style>
.dropmenudiv ul {
    background: none repeat scroll 0 0 #FFFFFF;
    float: left;
    width: 600px;
}
.dropmenudiv ul li {
  
    clear: both;
    color: #999999;
    font-size: 12px;
    line-height: 30px;
}
.dropmenudiv h3 {
    color: #8A5D1A;
    float: left;
    font-weight: bold;
    line-height: 30px;
    margin: 0;
    padding: 0;
    text-indent: 8px;
    width: 96px;
}
.dropmenudiv h3 a {
    color: #8A5D1A;
}
.dropmenudiv h3 a:hover {
    background-color: #8A5D1A;
    color: #FFFFFF;
}
</style>                                                   
<div style="_width:750px;" class="dropmenudiv" id="dropmenu1">
   <ul>
                 <li>
    <h3><a title="包包" href="http://www.52milan.com/ding/">包包:</a></h3>
 
      
    <a href="http://www.52milan.com/hermes/" title="爱马仕"><b>爱马仕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bv/" title="宝缇嘉"><b>宝缇嘉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/prada/" title="普拉达"><b>普拉达</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvlgari/" title="宝格丽"><b>宝格丽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lv/" title="LV"><b>LV</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chloe/" title="克洛伊"><b>克洛伊</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/gucci/" title="古奇"><b>古奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/givenchy/" title="纪梵希"><b>纪梵希</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanel/" title="香奈儿"><b>香奈儿</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/miumiu/" title="缪缪"><b>缪缪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberry/" title="巴宝莉"><b>巴宝莉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/celine/" title="赛琳"><b>赛琳</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendi/" title="芬迪"><b>芬迪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/DMJ/" title="D&amp;G"><b>D&amp;G</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/dior/" title="迪奥"><b>迪奥</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/mulberry/" title="玛百莉"><b>玛百莉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/versace/" title="范思哲"><b>范思哲</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/furla/" title="芙拉"><b>芙拉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/marcjacobs/" title="马杰克"><b>马杰克</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cartier/" title="卡地亚"><b>卡地亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/marni/" title="玛尼"><b>玛尼</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/coach/" title="蔻驰"><b>蔻驰</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ylsdw/" title="亚历山大·王"><b>亚历山大·王</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ysl/" title="圣罗兰"><b>圣罗兰</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/balenciaga/" title="巴黎世家"><b>巴黎世家</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/montblanc/" title="万宝龙"><b>万宝龙</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/armani/" title="阿玛尼"><b>阿玛尼</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/boss/" title="BOSS"><b>BOSS</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bally/" title="巴利"><b>巴利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamo/" title="菲拉格慕"><b>菲拉格慕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/plessl/" title="普罗恩萨·施罗"><b>普罗恩萨·施罗</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/victoriacross/" title="维多利亚"><b>维多利亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/stephen/" title="斯蒂芬"><b>斯蒂芬</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lbtkwl/" title="罗伯特·卡沃利"><b>罗伯特·卡沃利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/loewe/" title="罗意威"><b>罗意威</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/tods/" title="托德斯"><b>托德斯</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/etro/" title="艾特罗"><b>艾特罗</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/RogerVivierbao/" title="罗杰·维威耶"><b>罗杰·维威耶</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Valentinobao/" title="华伦天奴"><b>华伦天奴</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/BMWHandbags/" title="宝马"><b>宝马</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Aquascutumbao/" title="雅格狮丹"><b>雅格狮丹</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ToryBurchbao/" title="托里伯奇"><b>托里伯奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/yusan/" title="名牌雨伞"><b>名牌雨伞</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/mcmbao/" title="MCM"><b>MCM</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/thomaswylde/" title="托马斯·沃德"><b>托马斯·沃德</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Zegna/" title="杰尼亚"><b>杰尼亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MichaelKors/" title="MK"><b>MK</b></a><i>|</i>
   
     </li>
                                                                                                                             </ul>
</div>
                                              
<div style="_width:650px;" class="dropmenudiv" id="dropmenu2">
  <ul>
                                 <li>
    <h3><a title="鞋子" href="http://www.52milan.com/xiezi/">鞋子:</a></h3>
 
      
    <a href="http://www.52milan.com/diorxie/" title="迪奥鞋"><b>迪奥鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendixie/" title="芬迪鞋"><b>芬迪鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lvxiezi/" title="LV鞋"><b>LV鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccixie/" title="gucci鞋"><b>gucci鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermesxie/" title="爱马仕鞋"><b>爱马仕鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/pradaxie/" title="普拉达鞋"><b>普拉达鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/dmgxiezi/" title="D&amp;G鞋"><b>D&amp;G鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ballyxie/" title="BALLY鞋"><b>BALLY鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvxiezi/" title="BV鞋"><b>BV鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamoxie/" title="菲拉格慕鞋子"><b>菲拉格慕鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/JimmyChooShoes/" title="周仰杰鞋"><b>周仰杰鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ManoloShoes/" title="马诺洛鞋"><b>马诺洛鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ArmaniShoes/" title="阿玛尼鞋"><b>阿玛尼鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/rvxie/" title="RV鞋"><b>RV鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/CelineShoes/" title="赛琳鞋子"><b>赛琳鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/YSLShoes/" title="圣罗兰鞋"><b>圣罗兰鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ToryBurchShoes/" title="托里伯奇鞋"><b>托里伯奇鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ChanelShoes/" title="香奈儿鞋"><b>香奈儿鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/AlexanderWangShoes/" title="亚历山大鞋"><b>亚历山大鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Balmainxie/" title="巴尔曼鞋"><b>巴尔曼鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/philippplein/" title="菲利普鞋"><b>菲利普鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/TodsShoes/" title="托德斯鞋"><b>托德斯鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/StephenShoes/" title="斯蒂芬鞋"><b>斯蒂芬鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/GZShoes/" title="GZ鞋子"><b>GZ鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/CharlotteOlympiaShoes/" title="夏洛特鞋"><b>夏洛特鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hellokittyShoes/" title="Hello Kitty鞋"><b>Hello Kitty鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ValentinoShoes/" title="华伦天奴鞋"><b>华伦天奴鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MiumiuShoes/" title="缪缪鞋子"><b>缪缪鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/BurberryShoes/" title="巴宝莉鞋"><b>巴宝莉鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/versaceshoes/" title="范思哲鞋"><b>范思哲鞋</b></a><i>|</i>
   
     </li>
                                                                                                             </ul>
</div>
                                                   
<div style="_width:650px;" class="dropmenudiv" id="dropmenu3">
  <ul>
                                                                 <li>
    <h3><a title="皮带" href="http://www.52milan.com/pidai/">皮带:</a></h3>
 
      
    <a href="http://www.52milan.com/lvpidai/" title="LV皮带"><b>LV皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrypidai/" title="巴宝莉皮带"><b>巴宝莉皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermespidai/" title="爱马仕皮带"><b>爱马仕皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccipidai/" title="古奇皮带"><b>古奇皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/stephenpidai/" title="斯蒂芬皮带"><b>斯蒂芬皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/zegnapidai/" title="杰尼亚皮带"><b>杰尼亚皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvpidai/" title="BV皮带"><b>BV皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cartierpidai/" title="卡地亚皮带"><b>卡地亚皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/loewepidai/" title="罗意威皮带"><b>罗意威皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/wblpidai/" title="万宝龙皮带"><b>万宝龙皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanelpidai/" title="香奈儿皮带"><b>香奈儿皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamopidai/" title="菲拉格慕皮带"><b>菲拉格慕皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/jaguar/" title="捷豹皮带"><b>捷豹皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/givenchypidai/" title="纪梵希皮带"><b>纪梵希皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/BallyBelt/" title="巴利皮带"><b>巴利皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/PradaBelt/" title="普拉达皮带"><b>普拉达皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/rv/" title="RV皮带"><b>RV皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/DMG/" title="D&amp;G皮带"><b>D&amp;G皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/AlexanderWangBelt/" title="亚历山大·王皮带"><b>亚历山大·王皮带</b></a><i>|</i>
   
     </li>
                                                                             </ul>
</div>
<div style="_width:670px;" class="dropmenudiv" id="dropmenu4">
  <ul>
                                                                                 <li>
    <h3><a title="名牌首饰" href="http://www.52milan.com/shoushi/">名牌首饰:</a></h3>
 
      
    <a href="http://www.52milan.com/chanelshoushi/" title="香奈儿"><b>香奈儿</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvlgarishoushi/" title="宝格丽"><b>宝格丽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermesshoushi/" title="爱马仕"><b>爱马仕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cartiershoushi/" title="卡地亚"><b>卡地亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/yslshoushi/" title="圣罗兰"><b>圣罗兰</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lvshoushi/" title="LV"><b>LV</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccishoushi/" title="古奇"><b>古奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendishoushi/" title="芬迪"><b>芬迪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/vcashoushi/" title="梵克雅宝"><b>梵克雅宝</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/toryburchshoushi/" title="托里伯奇"><b>托里伯奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/tiffany/" title="Tiffany"><b>Tiffany</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Valentinoshoushi/" title="华伦天奴"><b>华伦天奴</b></a><i>|</i>
   
     </li>
                                                             </ul>
</div>
                                                   
<div style="_width:630px;" class="dropmenudiv" id="dropmenu5">
  <ul>
                                                 <li>
    <h3><a title="眼镜" href="http://www.52milan.com/mojing/">眼镜:</a></h3>
 
      
    <a href="http://www.52milan.com/ferrari/" title="法拉利"><b>法拉利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/porsche/" title="保时捷"><b>保时捷</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lvmojing/" title="LV"><b>LV</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/pradamojing/" title="普拉达"><b>普拉达</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccimojing/" title="古奇"><b>古奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/kdytyj/" title="卡地亚"><b>卡地亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/amntyj/" title="阿玛尼"><b>阿玛尼</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lodk/" title="克罗心"><b>克罗心</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/diortyj/" title="迪奥"><b>迪奥</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/montblanctyj/" title="万宝龙"><b>万宝龙</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/todsmojing/" title="托德斯"><b>托德斯</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/swarovski/" title="施华洛世奇"><b>施华洛世奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrytyj/" title="巴宝莉"><b>巴宝莉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendityj/" title="芬迪"><b>芬迪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamotyj/" title="菲拉格慕"><b>菲拉格慕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/vivian/" title="薇薇安"><b>薇薇安</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Chaneltyj/" title="香奈儿"><b>香奈儿</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermestyj/" title="爱马仕"><b>爱马仕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/dunhill/" title="登喜路"><b>登喜路</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvlgarityj/" title="宝格丽"><b>宝格丽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cazal/" title="卡加尔"><b>卡加尔</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/celinetyj/" title="赛琳"><b>赛琳</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/RobertoCavallityj/" title="罗伯特·卡沃利"><b>罗伯特·卡沃利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MarcJacobstyj/" title="马杰克"><b>马杰克</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Polaroidtyj/" title="宝丽来"><b>宝丽来</b></a><i>|</i>
   
     </li>
                                                                                             </ul>
</div>
<div style="_width:530px;" class="dropmenudiv" id="dropmenu6">
  <ul>
                                                                                                                 <li>
    <h3><a title="帽子" href="http://www.52milan.com/mao/">帽子:</a></h3>
 
      
    <a href="http://www.52milan.com/lvmaozi/" title="LV帽子"><b>LV帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccimaozi/" title="GUCCI帽子"><b>GUCCI帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendimaozi/" title="Fendi帽子"><b>Fendi帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrymaozi/" title="Burberry帽"><b>Burberry帽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermesmaozi/" title="Hermes帽"><b>Hermes帽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanelmao/" title="Chanel帽子"><b>Chanel帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MCMHat/" title="MCM帽子"><b>MCM帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/PradaHat/" title="Prada帽子"><b>Prada帽子</b></a><i>|</i>
   
     </li>
                             </ul>
</div>                                                   
<div style="_width:530px;" class="dropmenudiv" id="dropmenu7">
  <ul>
                                                                                                 <li>
    <h3><a title="丝巾" href="http://www.52milan.com/sijin/">丝巾:</a></h3>
 
      
    <a href="http://www.52milan.com/lvsijin/" title="LV丝巾"><b>LV丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermessijin/" title="爱马仕丝巾"><b>爱马仕丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanelsijin/" title="香奈儿丝巾"><b>香奈儿丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccisijin/" title="gucci丝巾"><b>gucci丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Pradasijin/" title="普拉达丝巾"><b>普拉达丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvsijin/" title="BV丝巾"><b>BV丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/celinesijin/" title="赛琳丝巾"><b>赛琳丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/givenchysijin/" title="纪梵希丝巾"><b>纪梵希丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendisijin/" title="芬迪丝巾"><b>芬迪丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrysijin/" title="巴宝莉丝巾"><b>巴宝莉丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/valentinosijin/" title="华伦天奴丝巾"><b>华伦天奴丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ToryBurchsijin/" title="托里伯奇丝巾"><b>托里伯奇丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/AlexanderWangsijin/" title="亚历山大·麦昆丝巾"><b>亚历山大·麦昆丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/marcjacobssijin/" title="马克·雅可布丝巾"><b>马克·雅可布丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/etrosijin/" title="艾特罗丝巾"><b>艾特罗丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/kenzosijin/" title="Kenzo丝巾"><b>Kenzo丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Diorsijin/" title="迪奥丝巾"><b>迪奥丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamosijin/" title="菲拉格慕丝巾"><b>菲拉格慕丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Loewesijin/" title="罗意威丝巾"><b>罗意威丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Armanisijin/" title="阿玛尼丝巾"><b>阿玛尼丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/DGsijin/" title="D&amp;G丝巾"><b>D&amp;G丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/YSLsijin/" title="圣罗兰丝巾"><b>圣罗兰丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Zegnasijin/" title="杰尼亚丝巾"><b>杰尼亚丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/swarovskisijin/" title="施华洛世奇丝巾"><b>施华洛世奇丝巾</b></a><i>|</i>
   
     </li>
                                             </ul>
</div>  
<script type="text/javascript">cssdropdown.startchrome("chromemenu")</script>
</div><div id="main">
  <div class="fcSlider" id="focus_ad">
    <ul>
      <li class="cur" rel="0" style="display: list-item;"><a target="_blank" title="LV" href="/lv/"><img alt="LV" src1="/images/tm.png" src="/data/afficheimg/20121229glxhpo.jpg"></a></li>
      <li rel="1" class="" style="display: none;"><a target="_blank" title="香奈儿" href="/chanel/"><img alt="香奈儿" src="/images/tm.png" data-src="/data/afficheimg/20121229etfqnh.jpg"></a></li>
      <li rel="2" class="" style="display: none;"><a target="_blank" title="爱马仕" href="/hermes/"><img alt="爱马仕" src="/images/tm.png" data-src="/data/afficheimg/20121229qzvcsf.jpg"></a></li>
    </ul>
    <div> <span> <a class="cur" title="LV" href="javascript:void(0);" rel="0">1</a> <a title="香奈儿" href="javascript:void(0);" rel="1" class="">2</a> <a title="爱马仕" href="javascript:void(0);" rel="2" class="">3</a> </span> </div>
  </div>
  <div class="ad_left"> <a target="_blank" href="/bvpidai/"> <img width="287" height="118" border="0" src="/ad/ad2.jpg"></a> <a target="_blank" href="/chanel/"><img width="287" height="118" border="0" src="/ad/ad3.jpg"></a>
    <div>
      <ul>
              </ul>
    </div>
  </div>
</div>
<div class="floor floor-2 lazybox">
  <div class="f-title clearfix">
    <h3 class="name"><a target="_blank" href="javascript:;"></a></h3>
    <div class="brand">
      
      <span class="txt">热门品牌推荐：</span>
      <ul class="item">
        <li><a target="_blank" href="/ding-b100/" title="LV路易威登">LV路易威登</a></li>
        <li><a target="_blank" href="/ding-b101/" title="Hermes爱马仕">Hermes爱马仕</a></li>
        <li><a target="_blank" href="/ding-b102/" title="prada普拉达">prada普拉达</a></li>
        <li><a target="_blank" href="/ding-b103/" title="gucci古奇">gucci古奇</a></li>
        <li><a target="_blank" href="/ding-b104/" title="chanel香奈儿">chanel香奈儿</a></li>
        <li><a target="_blank" href="/ding-b105/" title="miumiu缪缪">miumiu缪缪</a></li>
        <li><a target="_blank" href="/ding-b106/" title="burberry巴宝莉">burberry巴宝莉</a></li>
      </ul>
      
    </div>
  </div>
  <div class="f-main clearfix">
    <div class="left-part clearfix">
      <dl class="f-cate">
        <dt>人群</dt>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/nanshibao/" title="男士包包"><font color="red">男士包包</font> </a></dd>
        <dd class=""><span class="f-point"></span><a class="c-item" target="_blank" href="/nvshibao/" title="女士包包">女士包包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr2421-0-0-0-0-0-0-0-0-0-0/" title="中性包包">中性包包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr1874-0-0-0-0-0-0-0-0-0-0/" title="男士钱包">男士钱包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr2090-0-0-0-0-0-0-0-0-0-0/" title="女士钱包"><font color="red">女士钱包</font> </a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr1846-0-0-0-0-0-0-0-0-0-0/" title="中性钱包">中性钱包</a></dd>
      </dl>
      <dl class="f-cate ">
        <dt>基本款式</dt>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-2355-0-0-0-0-0-0-0-0/" title="单肩包">单肩包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-1887-0-0-0-0-0-0-0-0/" title="斜挎包">斜挎包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-1847-0-0-0-0-0-0-0-0/" title="手提包">手提包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-6809-0-0-0-0-0-0-0-0/" title="多用包">多用包</a></dd>
      </dl>
      <dl class="f-cate  last">
        <dt>用途</dt>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-5619-0-0-0-0-0-0-0-0/" title="公文包">公文包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-6429-0-0-0-0-0-0-0-0/" title="旅行包">旅行包</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-7628-0-0-0-0-0-0-0-0/" title="购物袋">购物袋</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-7588-0-0-0-0-0-0-0-0/" title="钥匙扣">钥匙扣</a></dd>
        <dd class=""><span class="f-point"></span><a  class="c-item" target="_blank" href="/ding-attr0-0-1844-0-0-0-0-0-0-0-0/" title="双用包">双用包</a></dd>
      </dl>
    </div>
    
    <div class="center-part">
      <div class="slidebox-01">
        <ul class="slidepic-01">
          <li><a href="/lv"><img width="576" height="300" alt="包包" src="/ad/ad6.jpg" /></a></li>
          <li><a href="/hermes/"><img width="576" height="300" alt="包包" src="/images/tm.png" data-src="/ad/ad7.jpg" /></a></li>
          <li><a href="/bv/"><img width="576" height="300" alt="包包" src="/images/tm.png" data-src="/ad/ad8.jpg" /></a></li>
        </ul>
        <div class="slidebtn-01">
          <ul>
            <li class="current">1</li>
            <li>2</li>
            <li>3</li>
          </ul>
        </div>
      </div>
    </div>
    
    
    <div class="right-part"> <a target="_blank" href="/ding/"><img width="230" height="300" title="" alt="" src="/ad/ad5.jpg"></a> </div>
    
  </div>
  
  <div class="pro_wrap" id="news1">
    <div class="tab">
      <ul>
        <li class="cur  t1"></li>
        <li class="t2"></li>
        <li class="t3"></li>
      </ul>
    </div>
    <div class="cur page">
      <ul class="pro_list clearfix">
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/Valentinoshoushi-g43001.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/ValentinoJewelery2013/1/NB001-01.jpg" alt="NB001 01 华伦天奴时尚百搭休闲首饰_2013新上市热卖女士手环_Valentino饰品" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/ValentinoJewelery2013/1/NB001-01.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="NB001 01 华伦天奴时尚百搭休闲首饰_2013新上市热卖女士手环_Valentino饰品" class="name" target="_blank" href="http://www.52milan.com/Valentinoshoushi-g43001.html">NB001 01 华伦天奴时尚百搭休闲首饰_2013...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥290</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/lvshoushi-g43000.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/LVJewelery2013/1/VD010-03.jpg" alt="VD010 L W 路易威登简约项链_时尚休闲女士百搭项链_LV饰品" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/LVJewelery2013/1/VD010-03.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="VD010 L W 路易威登简约项链_时尚休闲女士百搭项链_LV饰品" class="name" target="_blank" href="http://www.52milan.com/lvshoushi-g43000.html">VD010 L W 路易威登简约项链_时尚休闲女士百...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥600</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/dior-g44425.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/DiorHandbags2013/1/3364-18.jpg" alt="3364 梅红配橙色羊皮 Dior时尚百搭潮女经典包包_迪奥官网经典款式_流行包包" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/DiorHandbags2013/1/3364-18.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="3364 梅红配橙色羊皮 Dior时尚百搭潮女经典包包_迪奥官网经典款式_流行包包" class="name" target="_blank" href="http://www.52milan.com/dior-g44425.html">3364 梅红配橙色羊皮 Dior时尚百搭潮女经典包...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥840</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/lv-g44653.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/LVHandbags2013/1/M91606-60.jpg" alt="M91606亮橙 LV热款新品女士包包_LV2013新款热销时尚贝壳包_LV包包" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/LVHandbags2013/1/M91606-60.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="M91606亮橙 LV热款新品女士包包_LV2013新款热销时尚贝壳包_LV包包" class="name" target="_blank" href="http://www.52milan.com/lv-g44653.html">M91606亮橙 LV热款新品女士包包_LV2013...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥500</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/chanel-g43276.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/ChanelHandbags2013/1/67086-89.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/ChanelHandbags2013/1/67086-89.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="name" target="_blank" href="http://www.52milan.com/chanel-g43276.html">67086黑色鹿皮  Chanel新款百搭韩版经典包...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥2600</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/chanel-g43279.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/ChanelHandbags2013/1/67086-92.jpg" alt="67086绿色鹿皮  Chanel简约高端菱格包_香奈儿官网热销新款包_流行包包" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/ChanelHandbags2013/1/67086-92.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="67086绿色鹿皮  Chanel简约高端菱格包_香奈儿官网热销新款包_流行包包" class="name" target="_blank" href="http://www.52milan.com/chanel-g43279.html">67086绿色鹿皮  Chanel简约高端菱格包_香...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥2600</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/chanel-g43280.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/ChanelHandbags2013/1/67086-93.jpg" alt="67086玫红鹿皮  Chanel时尚欧美范包_香奈儿高品质包包_2013热销包" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/ChanelHandbags2013/1/67086-93.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="67086玫红鹿皮  Chanel时尚欧美范包_香奈儿高品质包包_2013热销包" class="name" target="_blank" href="http://www.52milan.com/chanel-g43280.html">67086玫红鹿皮  Chanel时尚欧美范包_香奈...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥2600</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/AlexanderWangsijin-g43561.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/AlexanderWangscarves2013/1/MQ48.jpg" alt="MQ48 Alexander Wang秋季新品丝巾_亚历山大麦昆2013秋季热销新品丝巾_麦昆丝巾" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/AlexanderWangscarves2013/1/MQ48.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="MQ48 Alexander Wang秋季新品丝巾_亚历山大麦昆2013秋季热销新品丝巾_麦昆丝巾" class="name" target="_blank" href="http://www.52milan.com/AlexanderWangsijin-g43561.html">MQ48 Alexander Wang秋季新品丝巾_...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥380</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
              </ul>
    </div>
    <div class="page">
      <ul class="pro_list clearfix">
              </ul>
    </div>
    <div class="page">
      <ul class="pro_list clearfix">
              </ul>
    </div>
  </div>
  
</div>
<div class="w floorMap f3">
  <div class="floorHeader">
    <div  class="floorName" id="JS_hide_floor_menu_3">
      <div class="floorMenu">
        <ul class="catList">
          <li>• <a title="男士鞋子" target="_blank" href="/xiezi-attr15593-0-0-0-0-0-0-0-0-0-0/">男士鞋子</a></li>
          <li>• <a title="女士鞋子" target="_blank" href="/xiezi-attr21659-0-0-0-0-0-0-0-0-0-0/">女士鞋子</a></li>
          <li>• <a title="牛皮" target="_blank" href="/xiezi-attr0-0-0-4333-0-0-0-0-0-0-0/">牛皮</a></li>
          <li>• <a title="布配皮" target="_blank" href="/xiezi-attr0-0-0-4243-0-0-0-0-0-0-0/">布配皮</a></li>
        </ul>
        <h4>推荐品牌</h4>
        <ul class="brand">
          <li>
            <div class="inbox">
              <div class="img"><a title="LV路易威登 " target="_blank" href="/lvxiezi/"><img width="80" height="50" alt="LV路易威登 " data-src="/data/brandlogo/1357077708628288301.jpg" src="/images/tm.png" ></a></div>
              <p><a title="LV路易威登 " target="_blank" href="/lvxiezi/">LV路易威登 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="Hermes爱马仕" target="_blank" href="/hermesxie/"><img width="80" height="50" alt="Hermes爱马仕" data-src="/data/brandlogo/1357077911087601515.jpg" src="/images/tm.png"></a></div>
              <p><a title="Hermes爱马仕" target="_blank" href="/hermesxie/">Hermes爱马仕</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="prada普拉达 " target="_blank" href="/pradaxie/"><img width="80" height="50" alt="prada普拉达 " data-src="/data/brandlogo/1357077806274511679.jpg" src="/images/tm.png"></a></div>
              <p><a title="prada普拉达 " target="_blank" href="/pradaxie/">prada普拉达</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="burberry巴宝莉 " target="_blank" href="/burberrytyj/"><img width="80" height="50" alt="burberry巴宝莉" data-src="/data/brandlogo/1357078351404307774.jpg" src="/images/tm.png"></a></div>
              <p><a title="burberry巴宝莉 " target="_blank" href="/burberrytyj/">burberry巴宝莉</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="gucci古奇 " target="_blank" href="/guccixie/"><img width="80" height="50" alt="gucci古奇" data-src="/data/brandlogo/1357077959227874651.jpg" ssrc="/images/tm.png"></a></div>
              <p><a title="gucci古奇 " target="_blank" href="/guccixie/">gucci古奇</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="BV宝缇嘉 " target="_blank" href="/bvxiezi/"><img width="80" height="50" alt="BV宝缇嘉" data-src="/data/brandlogo/1357078740679832302.jpg" src="/images/tm.png"></a></div>
              <p><a title="BV宝缇嘉 " target="_blank" href="/bvxiezi/">BV宝缇嘉</a></p>
            </div>
          </li>
        </ul>
      </div>
      <a href="javascript:;" class="showName"></a> </div>
    <div class="floorLink">
      <div class="kw Left">热门推荐：<a title="时尚百搭" target="_blank" href="/xiezi-attr0-7208-0-0-0-0-0-0-0-0-0/">时尚百搭</a> <span class="line">|</span> <a title="潮流风格" target="_blank" href="/xiezi-attr0-7363-0-0-0-0-0-0-0-0-0/">潮流风格</a> <span class="line">|</span> <a title="甜美淑女" target="_blank" href="/xiezi-attr0-7246-0-0-0-0-0-0-0-0-0/">甜美淑女</a> <span class="line">|</span> <a title="经典商务" target="_blank" href="/xiezi-attr0-7203-0-0-0-0-0-0-0-0-0/">经典商务</a> 
      
      <span class="line">|</span> <a title="Hermes爱马仕鞋子" target="_blank" href="/xiezi-b100/">Hermes爱马仕鞋子</a>
      
      <span class="line">|</span> <a title="LV路易威登鞋子" target="_blank" href="/xiezi-b101/">LV路易威登鞋子</a>
      
      <span class="line">|</span> <a title="prada普拉达鞋子" target="_blank" href="/xiezi-b102/">prada普拉达鞋子</a>
      
      </div>
      <a title="查看更多" target="_blank" href="/xiezi/" class="more">查看更多</a> </div>
  </div>
  <div class="floorBody clearfix">
    <div class="mainMap">
      <div class="groupTop">
        <div class="focus Left">
          <div class="slidebox-02">
            <ul class="slidepic-02">
              <li><a href="/fendixie/" title="鞋子"><img width="540" height="340" alt="鞋子" src="/ad/xiezi1.jpg" /></a></li>
              <li><a href="/guccixie/"><img width="540" height="340" alt="鞋子" src="/images/tm.png" data-src="/ad/xiezi2.jpg" /></a></li>
              <li><a href="/lvxiezi/"><img width="540" height="340" alt="鞋子" src="/images/tm.png" data-src="/ad/xiezi3.jpg" /></a></li>
            </ul>
            <div class="slidebtn-02">
              <ul>
                <li class="current">1</li>
                <li>2</li>
                <li>3</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="sideSwitch Right">
          <div class="header"><strong class="txt">点击排行</strong></div>
          <ul class="clickMap" id="JS_switch_stage_0">
                        <li class="list open">
              <p class="showItem"><a class="link"  target="_blank" title="BV003黑色 缇嘉时尚编织男士休闲鞋子_2013新上市热卖品牌男鞋_BV男鞋" href="http://www.52milan.com/bvxiezi-g44729.html">BV003黑色 缇嘉时尚编织男士休闲鞋子_2013新...</a></p>
              <div class="hideItem">
                <div class="img"><a title="BV003黑色 缇嘉时尚编织男士休闲鞋子_2013新上市热卖品牌男鞋_BV男鞋" href="http://www.52milan.com/bvxiezi-g44729.html" target="_blank" ><img width="170" height="170" alt="BV003黑色 缇嘉时尚编织男士休闲鞋子_2013新上市热卖品牌男鞋_BV男鞋" src="/images/tm.png" data-src="http://bbpp.u.qiniudn.com/BottegaVenetaShoes2013/1/BV003-01.jpg"></a></div>
                <a class="name" title="BV003黑色 缇嘉时尚编织男士休闲鞋子_2013新上市热卖品牌男鞋_BV男鞋" href="http://www.52milan.com/bvxiezi-g44729.html" target="_blank" >BV003黑色 缇嘉时尚编织男士休闲鞋子_2013新...</a>
                <div class="count">
                  <div class="Left"><span class="icon">7</span><span>人喜欢</span></div>
                  <div class="Right"><span class="orange">7</span><span>人浏览过</span></div>
                </div>
              </div>
            </li>
                      </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
//滑动门效果
function setSlide(m,n){
	var $ = function(id){return document.getElementById(id);}
	var mli=$("slideTit"+m).getElementsByTagName("span");
	//alert(mli);
	var sul=$("slide"+m).getElementsByTagName("div");
	for(i=0;i<mli.length;i++){
		mli[i].className=i==n?"current":"";
		sul[i].style.display=i==n?"block":"none";
	}
}
</script>
<div class="w mt20">
  <div class="pro_wrap2" id="news2">
    <div class="tab">
     
    </div>
    <div class="cur page">
      <ul class="pro_list clearfix">
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/diorxie-g44435.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/PradaShoes2013/1/625-01.jpg" alt="625-6 浅灰 Prada日系甜美潮流女士平底鞋_普拉达2013新品上市_官网款式" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/PradaShoes2013/1/625-01.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="625-6 浅灰 Prada日系甜美潮流女士平底鞋_普拉达2013新品上市_官网款式" class="name" target="_blank" href="http://www.52milan.com/diorxie-g44435.html">625-6 浅灰 Prada日系甜美潮流女士平底鞋_...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥0</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/diorxie-g44436.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/PradaShoes2013/1/625-02.jpg" alt="625-6 黑色 Prada春秋季节高端女士鞋子_普拉达时尚大方船鞋_厂家直销" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/PradaShoes2013/1/625-02.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="625-6 黑色 Prada春秋季节高端女士鞋子_普拉达时尚大方船鞋_厂家直销" class="name" target="_blank" href="http://www.52milan.com/diorxie-g44436.html">625-6 黑色 Prada春秋季节高端女士鞋子_普...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥0</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/diorxie-g44437.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/PradaShoes2013/1/625-03.jpg" alt="625-6 天蓝 Prada时尚百搭圆头平底鞋_普拉达高端高品质鞋子_官网款式" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/PradaShoes2013/1/625-03.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="625-6 天蓝 Prada时尚百搭圆头平底鞋_普拉达高端高品质鞋子_官网款式" class="name" target="_blank" href="http://www.52milan.com/diorxie-g44437.html">625-6 天蓝 Prada时尚百搭圆头平底鞋_普拉...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥0</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/diorxie-g44438.html"> <img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/PradaShoes2013/1/625-04.jpg" alt="625-6 玫红 Prada日系甜美潮流女士平底鞋_普拉达2013新品上市_官网款式" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/PradaShoes2013/1/625-04.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="625-6 玫红 Prada日系甜美潮流女士平底鞋_普拉达2013新品上市_官网款式" class="name" target="_blank" href="http://www.52milan.com/diorxie-g44438.html">625-6 玫红 Prada日系甜美潮流女士平底鞋_...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥0</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
              </ul>
    </div>
  </div>
</div>
<div class="w floorMap f6">
  <div class="floorHeader">
    <div  class="floorName" id="JS_hide_floor_menu_3">
      <div class="floorMenu">
        <ul class="catList">
          <li>• <a title="男士皮带" target="_blank" href="/pidai-attr12869-0-0-0-0-0-0-0-0-0-0/">男士皮带</a></li>
          <li>• <a title="女士皮带" target="_blank" href="/pidai-attr14478-0-0-0-0-0-0-0-0-0-0/">女士皮带</a></li>
          <li>• <a title="300～600皮带" target="_blank" href="/pidai-attr0-0-0-0-10504-0-0-0-0-0-0/">300～600</a></li>
          <li>• <a title="300～600皮带" target="_blank" href="/pidai-attr0-0-0-0-11970-0-0-0-0-0-0/">600～1200</a></li>
        </ul>
        <h4>推荐品牌</h4>
        <ul class="brand">
          <li>
            <div class="inbox">
              <div class="img"><a title="LV路易威登 " target="_blank" href="/lvpidai/"><img width="80" height="50" alt="LV路易威登 " data-src="/data/brandlogo/1357077708628288301.jpg" src="/images/tm.png" ></a></div>
              <p><a title="LV路易威登  " target="_blank" href="/lvpidai/"> LV路易威登  </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="Hermes爱马仕" target="_blank" href="/hermespidai/"><img width="80" height="50" alt="Hermes爱马仕" data-src="/data/brandlogo/1357077911087601515.jpg" src="/images/tm.png"></a></div>
              <p><a title="Hermes爱马仕" target="_blank" href="/hermespidai/">Hermes爱马仕</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="chanel香奈儿" target="_blank" href="/chanelpidai/"><img width="80" height="50" alt="chanel香奈儿" data-src="/data/brandlogo/1357078202840981454.jpg" src="/images/tm.png"></a></div>
              <p><a title="chanel香奈儿" target="_blank" href="/chanelpidai/">chanel香奈儿</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="burberry巴宝莉 " target="_blank" href="/burberrypidai/"><img width="80" height="50" alt="burberry巴宝莉" data-src="/data/brandlogo/1357078351404307774.jpg" src="/images/tm.png"></a></div>
              <p><a title="burberry巴宝莉 " target="_blank" href="/burberrypidai/">burberry巴宝莉</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="gucci古奇 " target="_blank" href="/guccipidai/"><img width="80" height="50" alt="gucci古奇" data-src="/data/brandlogo/1357077959227874651.jpg" src="/images/tm.png"></a></div>
              <p><a title="gucci古奇 " target="_blank" href="/guccipidai/">gucci古奇</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="BV宝缇嘉 " target="_blank" href="/bvpidai/"><img width="80" height="50" alt="BV宝缇嘉" data-src="/data/brandlogo/1357078740679832302.jpg" src="/images/tm.png"></a></div>
              <p><a title="BV宝缇嘉 " target="_blank" href="/bvpidai/">BV宝缇嘉</a></p>
            </div>
          </li>
        </ul>
      </div>
      <a href="javascript:;" class="showName"><span class="icon"><em class="hLine"></em><em class="vLine"></em></span></a> </div>
    <div class="floorLink">
      <div class="kw Left">热门推荐：<a title="LV路易威登皮带" target="_blank" href="/pidai-b100/">LV皮带</a> <span class="line">|</span> 
      
      <a title="Hermes爱马仕皮带" target="_blank" href="/pidai-b101/">Hermes爱马仕皮带</a> <span class="line">|</span> 
      <a title="prada普拉达皮带" target="_blank" href="/pidai-b102/">prada普拉达皮带</a> <span class="line">|</span> 
      <a title="gucci古奇皮带" target="_blank" href="/pidai-b103/">gucci古奇皮带</a> <span class="line">|</span> 
      <a title="chanel香奈儿皮带" target="_blank" href="/pidai-b104/">chanel香奈儿皮带</a> <span class="line">|</span> 
      <a title="burberry巴宝莉皮带" target="_blank" href="/pidai-b105/">burberry巴宝莉皮带</a> <span class="line">|</span> 
      </div>
      <a title="查看更多" target="_blank" href="/pidai/" class="more">查看更多</a> </div>
  </div>
  <div class="floorBody clearfix">
    <div class="mainMap">
      <div class="groupTop">
        <div class="focus Left">
          <div class="slidebox-03">
            <ul class="slidepic-03">
              <li><a href="/pidai/"><img width="540" height="340" alt="皮带" src="/ad/pidai-01.jpg" /></a></li>
              <li><a href="/guccipidai/"><img width="540" height="340" alt="皮带" src="/images/tm.png" data-src="/ad/pidai02.jpg" /></a></li>
              <li><a href="/lvpidai/"><img width="540" height="340" alt="皮带" src="/images/tm.png" data-src="/ad/pidai03.jpg" /></a></li>
            </ul>
            <div class="slidebtn-03">
              <ul>
                <li class="current">1</li>
                <li>2</li>
                <li>3</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="sideSwitch Right">
          <div class="header"><strong class="txt">点击排行</strong></div>
          <ul class="clickMap" id="JS_switch_stage_0">
                        <li class="list open">
              <p class="showItem"><a class="link"  target="_blank" title="H00545 hermes独家休闲百搭男士皮带_爱马仕潮流经典款式" href="http://www.52milan.com/hermespidai-g43826.html">H00545 hermes独家休闲百搭男士皮带_爱马...</a></p>
              <div class="hideItem">
                <div class="img"><a title="H00545 hermes独家休闲百搭男士皮带_爱马仕潮流经典款式" href="http://www.52milan.com/hermespidai-g43826.html" target="_blank" ><img width="170" height="170" alt="H00545 hermes独家休闲百搭男士皮带_爱马仕潮流经典款式" src="/images/tm.png" data-src="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00545-01.jpg"></a></div>
                <a class="name" title="H00545 hermes独家休闲百搭男士皮带_爱马仕潮流经典款式" href="http://www.52milan.com/hermespidai-g43826.html" target="_blank" >H00545 hermes独家休闲百搭男士皮带_爱马...</a>
                <div class="count">
                  <div class="Left"><span class="icon">9</span><span>人喜欢</span></div>
                  <div class="Right"><span class="orange">9</span><span>人浏览过</span></div>
                </div>
              </div>
            </li>
                      </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="w mt20">
  <div class="pro_wrap3" id="news3">
    <div class="tab">
   
    </div>
    <div class="cur page">
      <ul class="pro_list clearfix">
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/hermespidai-g43826.html"><img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00545-01.jpg" alt="H00545 hermes独家休闲百搭男士皮带_爱马仕潮流经典款式" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00545-01.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="H00545 hermes独家休闲百搭男士皮带_爱马仕潮流经典款式" class="name" target="_blank" href="http://www.52milan.com/hermespidai-g43826.html">H00545 hermes独家休闲百搭男士皮带_爱马...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥0</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/hermespidai-g43827.html"><img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00546-01.jpg" alt="H00546 hermes英伦潮男休闲大方皮带_爱马仕官网皮带" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00546-01.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="H00546 hermes英伦潮男休闲大方皮带_爱马仕官网皮带" class="name" target="_blank" href="http://www.52milan.com/hermespidai-g43827.html">H00546 hermes英伦潮男休闲大方皮带_爱马...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥0</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/hermespidai-g43828.html"><img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00547-01.jpg" alt="H00547 hermes百搭韩版个性全皮皮带_爱马仕厂家直销皮皮带" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00547-01.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="H00547 hermes百搭韩版个性全皮皮带_爱马仕厂家直销皮皮带" class="name" target="_blank" href="http://www.52milan.com/hermespidai-g43828.html">H00547 hermes百搭韩版个性全皮皮带_爱马...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥0</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
                <li> <a target="_blank" class="pic" href="http://www.52milan.com/hermespidai-g43829.html"><img  src="/placeholder.png" file="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00548-01.jpg" alt="H00548 hermes韩版裤腰带_爱马仕男士多用皮带" class="home-thumb lh_lazyimg"  width="200" height="200" style="display: inline; "/>
          <noscript>
          <img class="home-thumb" src="/http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00548-01.jpg" alt=""/>
          </noscript>
          </a>
          <div class="pro_info"> <a title="H00548 hermes韩版裤腰带_爱马仕男士多用皮带" class="name" target="_blank" href="http://www.52milan.com/hermespidai-g43829.html">H00548 hermes韩版裤腰带_爱马仕男士多用...</a>
            <div class="price">
                            <span class="gray">本店售价：</span><strong class="red">￥0</strong>
                            <p class="red">
                                <img src="/ad/price.jpg" alt="批发请联系客服">
                              </P>
            </div>
          </div>
        </li>
              </ul>
    </div>
  </div>
</div>
<div class="w floorMap f8">
  <div class="floorHeader">
    <div  class="floorName" id="JS_hide_floor_menu_3">
      <div class="floorMenu">
        <ul class="catList">
          <li>• <a title="男士眼镜" target="_blank" href="/mojing-attr26803-0-0-0-0-0-0-0-0-0-0/">男士眼镜</a></li>
          <li>• <a title="女士眼镜" target="_blank" href="/mojing-attr26808-0-0-0-0-0-0-0-0-0-0/">女士眼镜</a></li>
          <li>• <a title="板材" target="_blank" href="/mojing-attr0-0-0-26802-0-0-0-0-0-0-0/">板材</a></li>
          <li>• <a title="金属" target="_blank" href="/mojing-attr0-0-0-26812-0-0-0-0-0-0-0/">金属</a></li>
        </ul>
        <h4>推荐品牌</h4>
        <ul class="brand">
          <li>
            <div class="inbox">
              <div class="img"><a title="chanel香奈儿" target="_blank" href="/Chaneltyj/"><img width="80" height="50" alt="chanel香奈儿" data-src="/data/brandlogo/1357078202840981454.jpg" src="/images/tm.png" ></a></div>
              <p><a title="chanel香奈儿" target="_blank" href="/Chaneltyj/">chanel香奈儿</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="bvlgari宝格丽" target="_blank" href="/bvlgarityj/"><img width="80" height="50" alt="bvlgari宝格丽" data-src="/data/brandlogo/1357078785729779801.jpg" src="/images/tm.png"></a></div>
              <p><a title="bvlgari宝格丽" target="_blank" href="/bvlgarityj/">bvlgari宝格丽 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="LV路易威登 " target="_blank" href="/lvmojing/"><img width="80" height="50" alt="LV路易威登 " data-src="/data/brandlogo/1357077708628288301.jpg" src="/images/tm.png"></a></div>
              <p><a title="LV路易威登 " target="_blank" href="/lvmojing/">LV路易威登 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="Hermes爱马仕 " target="_blank" href="/hermestyj/"><img width="80" height="50" alt="Hermes爱马仕 " data-src="/data/brandlogo/1357077806274511679.jpg" src="/images/tm.png"></a></div>
              <p><a title="Hermes爱马仕" target="_blank" href="/hermestyj/">Hermes爱马仕 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="burberry巴宝莉" target="_blank" href="/burberrytyj/"><img width="80" height="50" alt="burberry巴宝莉" data-src="/data/brandlogo/1357078351404307774.jpg" src="/images/tm.png"></a></div>
              <p><a title="burberry巴宝莉 " target="_blank" href="/burberrytyj/">burberry巴宝莉</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="Armani阿玛尼 " target="_blank" href="/amntyj/"><img width="80" height="50" alt="Armani阿玛尼" data-src="/data/brandlogo/1357080405114386887.jpg" src="/images/tm.png"></a></div>
              <p><a title="Armani阿玛尼" target="_blank" href="/amntyj/">Armani阿玛尼</a></p>
            </div>
          </li>
        </ul>
      </div>
      <a href="javascript:;" class="showName"><span class="icon"><em class="hLine"></em><em class="vLine"></em></span></a> </div>
    <div class="floorLink">
      <div class="kw Left">热门推荐：<a title="眼镜" target="_blank" href="/ferrari/">眼镜</a> <span class="line">|</span>
      
      <a title="LV路易威登" target="_blank" href="/mojing-b100/">LV路易威登</a> <span class="line">|</span>
      <a title="Hermes爱马仕眼镜" target="_blank" href="/mojing-b101/">Hermes爱马仕眼镜</a> <span class="line">|</span>
      <a title="prada普拉达眼镜" target="_blank" href="/mojing-b102/">prada普拉达眼镜</a> <span class="line">|</span>
      <a title="gucci古奇眼镜" target="_blank" href="/mojing-b103/">gucci古奇眼镜</a> <span class="line">|</span>
      <a title="chanel香奈儿眼镜" target="_blank" href="/mojing-b104/">chanel香奈儿眼镜</a> <span class="line">|</span>
      </div>
      <a title="查看更多" target="_blank" href="/ferrari/" class="more">查看更多</a> </div>
  </div>
  <div class="floorBody clearfix">
    <div class="mainMap">
      <div class="groupTop">
        <div class="focus Left">
          <div class="slidebox-05">
            <ul class="slidepic-05">
              <li><a href="/ferrari/"><img width="540" height="340" alt="眼镜" src="/images/tm.png" data-src="/ad/yanjing1.jpg" /></a></li>
              <li><a href="/porsche/"><img width="540" height="340" alt="眼镜" src="/images/tm.png" data-src="/ad/yanjing2.jpg" /></a></li>
              <li><a href="/mojing/"><img width="540" height="340" alt="眼镜" src="/images/tm.png" data-src="/ad/yanjing3.jpg" /></a></li>
            </ul>
            <div class="slidebtn-05">
              <ul>
                <li class="current">1</li>
                <li>2</li>
                <li>3</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="sideSwitch Right">
          <div class="header"><strong class="txt">点击排行</strong></div>
          <ul class="clickMap" id="JS_switch_stage_0">
                      </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="w mt20">
  <div class="pro_wrap5" id="news5">
    <div class="tab">
      
    </div>
    <div class="cur page">
      <ul class="pro_list clearfix">
              </ul>
    </div>
  </div>
</div>
<div class="w floorMap f9">
  <div class="floorHeader">
    <div  class="floorName" id="JS_hide_floor_menu_3">
      <div class="floorMenu">
        <ul class="catList">
          <li>• <a title="男士帽子" target="_blank" href="/mao-attr20444-0-0-0-0-0-0-0-0-0-0/">男士帽子</a></li>
          <li>• <a title="女士帽子" target="_blank" href="/mao-attr20459-0-0-0-0-0-0-0-0-0-0/">女士帽子</a></li>
          <li>• <a title="300元以下" target="_blank" href="/mao-attr0-0-0-0-7040-0-0-0-0-0-0/">300元以下</a></li>
          <li>• <a title="300～600" target="_blank" href="/mao-attr0-0-0-0-10674-0-0-0-0-0-0/">300～600</a></li>
        </ul>
        <h4>推荐品牌</h4>
        <ul class="brand">
          <li>
            <div class="inbox">
              <div class="img"><a title="Hermes爱马仕 " target="_blank" href="/hermesmaozi/"><img width="80" height="50" alt="Hermes爱马仕" data-src="/data/brandlogo/1357077806274511679.jpg" src="/images/tm.png" ></a></div>
              <p><a title="Hermes爱马仕 " target="_blank" href="/hermesmaozi/">Hermes爱马仕 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="LV路易威登" target="_blank" href="/lvmaozi/"><img width="80" height="50" alt="LV路易威登  " data-src="/data/brandlogo/1357077708628288301.jpg" src="/images/tm.png"></a></div>
              <p><a title="LV路易威登  " target="_blank" href="/lvmaozi/">LV路易威登 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="gucci古奇" target="_blank" href="/guccimaozi/"><img width="80" height="50" alt="gucci古奇" data-src="/data/brandlogo/1357077959227874651.jpg" src="/images/tm.png"></a></div>
              <p><a title="gucci古奇" target="_blank" href="/guccimaozi/">gucci古奇 </a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="chanel香奈儿" target="_blank" href="/chanelmao/"><img width="80" height="50" alt="chanel香奈儿" data-src="/data/brandlogo/1357078202840981454.jpg" src="/images/tm.png"></a></div>
              <p><a title="chanel香奈儿" target="_blank" href="/chanelmao/">chanel香奈儿</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="burberry巴宝莉" target="_blank" href="/burberrymaozi/"><img width="80" height="50" alt="burberry巴宝莉" data-src="/data/brandlogo/1357078351404307774.jpg" src="/images/tm.png"></a></div>
              <p><a title="burberry巴宝莉" target="_blank" href="/burberrymaozi/">burberry巴宝莉</a></p>
            </div>
          </li>
          <li>
            <div class="inbox">
              <div class="img"><a title="fendi芬迪" target="_blank" href="/fendimaozi/"><img width="80" height="50" alt="fendi芬迪" data-src="/data/brandlogo/1357078504621390300.jpg" src="/images/tm.png"></a></div>
              <p><a title="fendi芬迪" target="_blank" href="/fendimaozi/">fendi芬迪</a></p>
            </div>
          </li>
        </ul>
      </div>
      <a href="javascript:;" class="showName"><span class="icon"><em class="hLine"></em><em class="vLine"></em></span></a> </div>
    <div class="floorLink">
      <div class="kw Left">热门推荐：<a title="时尚百搭" target="_blank" href="/mao-attr0-7038-0-0-0-0-0-0-0-0-0/">时尚百搭</a> <span class="line">|</span>
      
      <a title="LV路易威登帽子" target="_blank" href="/mao-b100/">LV路易威登帽子</a> <span class="line">|</span>
      
      <a title="Hermes爱马仕帽子" target="_blank" href="/mao-b101/">Hermes爱马仕帽子</a> <span class="line">|</span>
      <a title="gucci古奇帽子" target="_blank" href="/mao-b102/">gucci古奇帽子</a> <span class="line">|</span>
      <a title="chanel香奈儿帽子" target="_blank" href="/mao-b103/">chanel香奈儿帽子</a> <span class="line">|</span>
      
      </div>
      <a title="查看更多" target="_blank" href="/mao/" class="more">查看更多</a> </div>
  </div>
  <div class="floorBody clearfix">
    <div class="mainMap">
      <div class="groupTop">
        <div class="focus Left">
          <div class="slidebox-06">
            <ul class="slidepic-06">
              <li><a href="/mao/"><img width="540" height="340" alt="帽子" src="/images/tm.png" data-src="/ad/maozi01.jpg" /></a></li>
              <li><a href="/guccimaozi/"><img width="540" height="340" alt="帽子" src="/images/tm.png" data-src="/ad/maozi02.jpg" /></a></li>
              <li><a href="/chanelmao/"><img width="540" height="340" alt="帽子" src="/images/tm.png" data-src="/ad/ad8.jpg" /></a></li>
            </ul>
            <div class="slidebtn-06">
              <ul>
                <li class="current">1</li>
                <li>2</li>
                <li>3</li>
              </ul>
            </div>
          </div>
        </div>
        <div class="sideSwitch Right">
          <div class="header"><strong class="txt">点击排行</strong></div>
          <ul class="clickMap" id="JS_switch_stage_0">
                      </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="w mt20">
  <div class="pro_wrap6" id="news6">
    <div class="tab">
    </div>
    <div class="cur page">
      <ul class="pro_list clearfix">
              </ul>
    </div>
  </div>
</div>
<div id="main">
  <div id="news">
    <div class="tab">
     <ul>
        <li class="t1"></li>
        <li class="t2"></li>
        <li class="t3"></li>
        <li class="cur t4"></li>
        <li class="t5"></li>
      </ul>
    </div>
    <div class="page">
      <div class="left">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=100&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661629255997055.jpg' width='520' height='340'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
      </div>
      <div class="right">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=105&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661098046511054.jpg' width='432' height='114'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
         <ul>
</ul>
<ul>
</ul>
  </div>
    </div>
    <div class="page">
      <div class="left">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=101&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661698095983363.jpg' width='520' height='340'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
      </div>
      <div class="right">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=106&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661081859432492.jpg' width='432' height='114'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
         <ul>
</ul>
<ul>
</ul>
  </div>
    </div>
    <div class="page">
      <div class="left">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=102&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661684374509295.jpg' width='520' height='340'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
      </div>
      <div class="right">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=107&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661060373760405.jpg' width='432' height='114'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
         <ul>
</ul>
<ul>
</ul>
  </div>
    </div>
    <div class="cur page">
      <div class="left">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=103&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661668058149618.jpg' width='520' height='340'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
      </div>
      <div class="right">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=108&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661042046247116.jpg' width='432' height='114'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
         <ul>
</ul>
<ul>
</ul>
  </div>
    </div>
    <div class="page">
      <div class="left">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=104&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356661654594153372.jpg' width='520' height='340'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
      </div>
      <div class="right">
        <div class="ad">
          <table cellpadding="0" cellspacing="0">
            <tr>
              <td><a href='affiche.php?ad_id=109&amp;uri='
                target='_blank'><img src="/images/tm.png" data-src='data/afficheimg/1356660999994195673.jpg' width='432' height='114'
                border='0' /></a></td>
            </tr>
          </table>
        </div>
         <ul>
            						         			            			            			            			
 </ul>
       
  <ul>
                        
   </ul> </div>
    </div>
  </div>
</div>
<div class="blank"></div>
 <style>
.weixin_pic {
    background-image: none;
    position: absolute;
    z-index: 9999;
	right:367px;
	margin-top:16px;
	_margin-top:18px;
	
}
.weixin_pic img{
	z-index: 9999;
	}
</style>
<div id="footer">
  <div class="info">
    <p> 
       
      <a href="http://www.lvbaopifa.com/article-204.html"   rel="nofollow" >维美达皮具网的优势</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-203.html"   rel="nofollow" >实体批发</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-97.html"   rel="nofollow" >咨询热点</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-205.html"   rel="nofollow" >国外支付方式</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-206.html"   rel="nofollow" >包包等级说明</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-207.html"   rel="nofollow" >运费查询</a> 
       
        |
      <a  href="/sitemap.html" target="_blank">网站地图</a>
    </p>
    
        <p>  
       
      </p>
    <p class="copyright">&copy; 2005-2014 米兰精品商城 版权所有，并保留所有权利。</p>
   
  </div>
</div>
<div class="blank5"></div>
<script type="text/javascript">
function datasrc(){
var imga = document.getElementsByTagName("img");
//alert('网站打开完毕！开始加载图片！');
for(i=0;i<imga.length;i++)
{
imgsrc=imga[i].getAttribute('data-src');
if (imgsrc!=null){
imga[i].setAttribute('src',""+imgsrc+"");
       }
}
}
</script>
<LINK rel=stylesheet type=text/css href="/images/common.css">
<DIV id=floatTools class=float0831>
  <DIV class=floatL> 
  <A style="DISPLAY: none" id="newswt_mini" class="btnOpen" title="查看在线客服"  href="javascript:void(0);">展开</A> 
<A id="newswt_close" class="btnCtn" title="关闭在线客服" href="javascript:void(0);">收缩</A> </DIV>
  <DIV id=divFloatToolsView class=floatR>
    <DIV class=tp></DIV>
    <DIV class=cn>
      <UL>
        <LI class=top>
          <H3 class=titZx>QQ咨询</H3>
        </LI>
        <LI><a rel="nofollow" target="_blank" href="/kefu_1.html?arg=lvbao1688&amp;style=1"><img width="80" height="26" src="/themes/wbw2012/images/zxkf.gif"></a></LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=800009775&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服①</A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1622861430&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服② </A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1764924587&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服③</A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1984216240&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服④</A> </LI>
         <LI><A  href="http://amos.im.alisoft.com/msg.aw?v=2&uid=%E7%BB%B4%E7%BE%8E%E8%BE%BE%E7%9A%AE%E5%85%B7&site=cntaobao&s=1&charset=utf-8" target="_blank" rel="nofollow"><img src="/ad/wangwang.gif"></A> </LI>
      </UL>
      <UL>
        <LI>
          <H3 class=titDh>电话咨询</H3>
        </LI>
        <LI><SPAN class=icoTl>4006-346-588</SPAN> </LI>
        <LI>
        <SPAN class=icoTl>15811883379</SPAN>
        </LI>
        <LI class=bot>
          <H3 class=titDc><A href="/message.php" target="_blank">给我留言</A></H3>
        </LI>
      </UL>
    </DIV>
  </DIV>
</DIV>
<script type="text/javascript">
function mouseOver()
{
    document.getElementById('weixin_pic').style.display = "block";
}
function mouseOut()
{
    document.getElementById('weixin_pic').style.display = "none";
}
$(function(){
 $(".weixin").mouseenter(function () {
        $(this).children('.weixin_pic').show();
    }).mouseleave(function () {
        $(this).children('.weixin_pic').hide();
 })
})
$(function(){
	$('#floatTools').show();
	/*$('.swt_h').prev().addClass('swt_current_t');
	$('.swt_tit').each(function(){
		$(this).click(function(){
			$(this).toggleClass('swt_current_t').next().slideToggle()
		})
	});*/
	$('#newswt_close').click(function(){
		$(this).hide()							  
		$('#divFloatToolsView').animate({
			width:'-=130'
		},400,function(){
			$(this).hide()
			$('#newswt_mini').show().animate({
				width:'+=40'
			},600)
		})
	});
	$('#newswt_mini').click(function(){
	    $(this).hide()								 
		$(this).animate({
			width:'-=40'
		},100,function(){
			$('#divFloatToolsView').show().animate({
				width:'+=130'
			},400,function(){
				$('#newswt_close').show().animate({
				width:'+=0'
			},600)
		  })
		})
	})
}) 
</script>
).animate({
				width:'+=0'
			},600)
		  })
		})
	})
}) 
</script><script type="text/javascript"> 
</script>
</body>
</html>
