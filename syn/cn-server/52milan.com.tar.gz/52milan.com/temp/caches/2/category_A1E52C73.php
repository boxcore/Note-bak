<?php exit;?>a:3:{s:8:"template";a:9:{i:0;s:72:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/category.dwt";i:1;s:83:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/page_header.lbi";i:2;s:79:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/ur_here.lbi";i:3;s:83:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/ad_position.lbi";i:4;s:77:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/top10.lbi";i:5;s:82:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/goods_list.lbi";i:6;s:77:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/pages.lbi";i:7;s:76:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/help.lbi";i:8;s:83:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/page_footer.lbi";}s:7:"expires";i:1388942267;s:8:"maketime";i:1388938667;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<base href="http://www.52milan.com/" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="包,女包,男包,品牌包" />
<meta name="description" content="维美达汇集世界名牌奢侈品包，购买女包、男包、钱包或了解品牌包价格、图片请到维美达皮具网。支持货到付款，让您零风险购物！" />
<title>
包包网_女包品牌_时尚男包真皮_世界品牌包首选-维美达皮具</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="themes/wbw2012/style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="js/common.js"></script><script type="text/javascript" src="js/jquery-1.4.4.min.js"></script></head><body>
<link href="http://www.52milan.com/themes/wbw2012/page_header.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://www.52milan.com/themes/wbw2012/js/chrome.js"></script>
<script type="text/javascript">
var process_request = "正在处理您的请求...";
</script>
<div id="header" style="z-index: 20;">
	<div class="top" style="z-index:19; height:27px;">
	<script type="text/javascript" src="themes/wbw2012/js/script.js" ></script>
    <script type="text/javascript" src="themes/wbw2012/js/transport_ec.js"></script>
	<script type="text/javascript" src="themes/wbw2012/js/all.js"></script>
    <script type="text/javascript" src="themes/wbw2012/js/globals.js"></script>
	<script type="text/javascript" src="js/utils.js"></script>	554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca	                            <a href="http://www.lvbaopifa.com/article-97.html" rel="nofollow" >帮助中心</a>
                                                   
                    <a style="height:28px; position:relative;z-index: 19;" class="weixin" id="weixin" onmouseover="mouseOver()" onmouseout="mouseOut()">   
                               
                   <img src="http://www.52milan.com/images/weixinlogo.jpg" width="67" height="26"></a>
                      <a style="display: none;" class="weixin_pic" id="weixin_pic"> 
                  <img alt="米兰精品商城" src="http://www.52milan.com/images/weixinerweima.jpg"></a>
                      
	<span class="s__cart" id="ECS_CARTINFO">554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca<span class="s__arrow_red_down"></span></span></div>
    
   <div class="hlogo"> <a href="http://www.52milan.com/" title="米兰精品商城"><img src="themes/wbw2012/images/logo.gif"  alt="米兰精品商城"></a></div>
    <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()">
	  <input type="text" name="keywords" id="w" onMouseOver="this.focus()" onblur="if(this.value =='') this.value='请输入商品名称或编号'" onFocus="this.select()" onClick="if(this.value=='请输入商品名称或编号') this.value=''" value="请输入商品名称或编号" class="txt" /><input type="submit" value=" " class="s__search" style="cursor:pointer;" />
      
    </form>
    <span id="hotline"><img src="http://www.52milan.com/themes/wbw2012/images/4006.jpg"></span>
</div>
<div class="menu">
<div id="chromemenu" class="chromestyle clearfix">
<ul>
<li id="dropmenu_home"><a href="http://www.52milan.com/">网站首页</a></li>
<li id="dropmenu_women"><a rel="dropmenu1" href="http://www.52milan.com/ding/">名牌包包</a></li>
<li id="dropmenu_man"><a rel="dropmenu2" href="http://www.52milan.com/xiezi/">名牌鞋子</a></li>
<li id="dropmenu_watch"><a rel="dropmenu3" href="http://www.52milan.com/pidai/">名牌皮带</a></li>
<li id="dropmenu_shoushi"><a rel="dropmenu4" href="http://www.52milan.com/shoushi/">名牌首饰</a></li>
<li id="dropmenu_belt"><a rel="dropmenu5" href="http://www.52milan.com/mojing/">名牌眼睛</a></li>
<li id="dropmenu_wallet"><a rel="dropmenu6" href="http://www.52milan.com/mao/">名牌帽子</a></li>
<li id="dropmenu_shijing"><a rel="dropmenu7" href="http://www.52milan.com/sijin/">丝巾</a></li>
<li id="dropmenu_acc"><a  href="http://www.52milan.com/pinpai.html">品牌纵览</a></li>
<li id="dropmenu_glass"><a href="http://www.52milan.com/new.html">新品上架</a></li>
<li id="dropmenu_shoe"><a href="http://www.52milan.com/article-202.html">加盟代理</a></li>
</ul>
</div>
<style>
.dropmenudiv ul {
    background: none repeat scroll 0 0 #FFFFFF;
    float: left;
    width: 600px;
}
.dropmenudiv ul li {
  
    clear: both;
    color: #999999;
    font-size: 12px;
    line-height: 30px;
}
.dropmenudiv h3 {
    color: #8A5D1A;
    float: left;
    font-weight: bold;
    line-height: 30px;
    margin: 0;
    padding: 0;
    text-indent: 8px;
    width: 96px;
}
.dropmenudiv h3 a {
    color: #8A5D1A;
}
.dropmenudiv h3 a:hover {
    background-color: #8A5D1A;
    color: #FFFFFF;
}
</style>                                                   
<div style="_width:750px;" class="dropmenudiv" id="dropmenu1">
   <ul>
                 <li>
    <h3><a title="包包" href="http://www.52milan.com/ding/">包包:</a></h3>
 
      
    <a href="http://www.52milan.com/hermes/" title="爱马仕"><b>爱马仕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bv/" title="宝缇嘉"><b>宝缇嘉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/prada/" title="普拉达"><b>普拉达</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvlgari/" title="宝格丽"><b>宝格丽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lv/" title="LV"><b>LV</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chloe/" title="克洛伊"><b>克洛伊</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/gucci/" title="古奇"><b>古奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/givenchy/" title="纪梵希"><b>纪梵希</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanel/" title="香奈儿"><b>香奈儿</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/miumiu/" title="缪缪"><b>缪缪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberry/" title="巴宝莉"><b>巴宝莉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/celine/" title="赛琳"><b>赛琳</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendi/" title="芬迪"><b>芬迪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/DMJ/" title="D&amp;G"><b>D&amp;G</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/dior/" title="迪奥"><b>迪奥</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/mulberry/" title="玛百莉"><b>玛百莉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/versace/" title="范思哲"><b>范思哲</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/furla/" title="芙拉"><b>芙拉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/marcjacobs/" title="马杰克"><b>马杰克</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cartier/" title="卡地亚"><b>卡地亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/marni/" title="玛尼"><b>玛尼</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/coach/" title="蔻驰"><b>蔻驰</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ylsdw/" title="亚历山大·王"><b>亚历山大·王</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ysl/" title="圣罗兰"><b>圣罗兰</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/balenciaga/" title="巴黎世家"><b>巴黎世家</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/montblanc/" title="万宝龙"><b>万宝龙</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/armani/" title="阿玛尼"><b>阿玛尼</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/boss/" title="BOSS"><b>BOSS</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bally/" title="巴利"><b>巴利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamo/" title="菲拉格慕"><b>菲拉格慕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/plessl/" title="普罗恩萨·施罗"><b>普罗恩萨·施罗</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/victoriacross/" title="维多利亚"><b>维多利亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/stephen/" title="斯蒂芬"><b>斯蒂芬</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lbtkwl/" title="罗伯特·卡沃利"><b>罗伯特·卡沃利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/loewe/" title="罗意威"><b>罗意威</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/tods/" title="托德斯"><b>托德斯</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/etro/" title="艾特罗"><b>艾特罗</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/RogerVivierbao/" title="罗杰·维威耶"><b>罗杰·维威耶</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Valentinobao/" title="华伦天奴"><b>华伦天奴</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/BMWHandbags/" title="宝马"><b>宝马</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Aquascutumbao/" title="雅格狮丹"><b>雅格狮丹</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ToryBurchbao/" title="托里伯奇"><b>托里伯奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/yusan/" title="名牌雨伞"><b>名牌雨伞</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/mcmbao/" title="MCM"><b>MCM</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/thomaswylde/" title="托马斯·沃德"><b>托马斯·沃德</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Zegna/" title="杰尼亚"><b>杰尼亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MichaelKors/" title="MK"><b>MK</b></a><i>|</i>
   
     </li>
                                                                                                                             </ul>
</div>
                                              
<div style="_width:650px;" class="dropmenudiv" id="dropmenu2">
  <ul>
                                 <li>
    <h3><a title="鞋子" href="http://www.52milan.com/xiezi/">鞋子:</a></h3>
 
      
    <a href="http://www.52milan.com/diorxie/" title="迪奥鞋"><b>迪奥鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendixie/" title="芬迪鞋"><b>芬迪鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lvxiezi/" title="LV鞋"><b>LV鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccixie/" title="gucci鞋"><b>gucci鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermesxie/" title="爱马仕鞋"><b>爱马仕鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/pradaxie/" title="普拉达鞋"><b>普拉达鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/dmgxiezi/" title="D&amp;G鞋"><b>D&amp;G鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ballyxie/" title="BALLY鞋"><b>BALLY鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvxiezi/" title="BV鞋"><b>BV鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamoxie/" title="菲拉格慕鞋子"><b>菲拉格慕鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/JimmyChooShoes/" title="周仰杰鞋"><b>周仰杰鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ManoloShoes/" title="马诺洛鞋"><b>马诺洛鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ArmaniShoes/" title="阿玛尼鞋"><b>阿玛尼鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/rvxie/" title="RV鞋"><b>RV鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/CelineShoes/" title="赛琳鞋子"><b>赛琳鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/YSLShoes/" title="圣罗兰鞋"><b>圣罗兰鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ToryBurchShoes/" title="托里伯奇鞋"><b>托里伯奇鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ChanelShoes/" title="香奈儿鞋"><b>香奈儿鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/AlexanderWangShoes/" title="亚历山大鞋"><b>亚历山大鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Balmainxie/" title="巴尔曼鞋"><b>巴尔曼鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/philippplein/" title="菲利普鞋"><b>菲利普鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/TodsShoes/" title="托德斯鞋"><b>托德斯鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/StephenShoes/" title="斯蒂芬鞋"><b>斯蒂芬鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/GZShoes/" title="GZ鞋子"><b>GZ鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/CharlotteOlympiaShoes/" title="夏洛特鞋"><b>夏洛特鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hellokittyShoes/" title="Hello Kitty鞋"><b>Hello Kitty鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ValentinoShoes/" title="华伦天奴鞋"><b>华伦天奴鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MiumiuShoes/" title="缪缪鞋子"><b>缪缪鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/BurberryShoes/" title="巴宝莉鞋"><b>巴宝莉鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/versaceshoes/" title="范思哲鞋"><b>范思哲鞋</b></a><i>|</i>
   
     </li>
                                                                                                             </ul>
</div>
                                                   
<div style="_width:650px;" class="dropmenudiv" id="dropmenu3">
  <ul>
                                                                 <li>
    <h3><a title="皮带" href="http://www.52milan.com/pidai/">皮带:</a></h3>
 
      
    <a href="http://www.52milan.com/lvpidai/" title="LV皮带"><b>LV皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrypidai/" title="巴宝莉皮带"><b>巴宝莉皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermespidai/" title="爱马仕皮带"><b>爱马仕皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccipidai/" title="古奇皮带"><b>古奇皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/stephenpidai/" title="斯蒂芬皮带"><b>斯蒂芬皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/zegnapidai/" title="杰尼亚皮带"><b>杰尼亚皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvpidai/" title="BV皮带"><b>BV皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cartierpidai/" title="卡地亚皮带"><b>卡地亚皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/loewepidai/" title="罗意威皮带"><b>罗意威皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/wblpidai/" title="万宝龙皮带"><b>万宝龙皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanelpidai/" title="香奈儿皮带"><b>香奈儿皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamopidai/" title="菲拉格慕皮带"><b>菲拉格慕皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/jaguar/" title="捷豹皮带"><b>捷豹皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/givenchypidai/" title="纪梵希皮带"><b>纪梵希皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/BallyBelt/" title="巴利皮带"><b>巴利皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/PradaBelt/" title="普拉达皮带"><b>普拉达皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/rv/" title="RV皮带"><b>RV皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/DMG/" title="D&amp;G皮带"><b>D&amp;G皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/AlexanderWangBelt/" title="亚历山大·王皮带"><b>亚历山大·王皮带</b></a><i>|</i>
   
     </li>
                                                                             </ul>
</div>
                                                   
<div style="_width:670px;" class="dropmenudiv" id="dropmenu4">
  <ul>
                                                                                 <li>
    <h3><a title="名牌首饰" href="http://www.52milan.com/shoushi/">名牌首饰:</a></h3>
 
      
    <a href="http://www.52milan.com/chanelshoushi/" title="香奈儿"><b>香奈儿</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvlgarishoushi/" title="宝格丽"><b>宝格丽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermesshoushi/" title="爱马仕"><b>爱马仕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cartiershoushi/" title="卡地亚"><b>卡地亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/yslshoushi/" title="圣罗兰"><b>圣罗兰</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lvshoushi/" title="LV"><b>LV</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccishoushi/" title="古奇"><b>古奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendishoushi/" title="芬迪"><b>芬迪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/vcashoushi/" title="梵克雅宝"><b>梵克雅宝</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/toryburchshoushi/" title="托里伯奇"><b>托里伯奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/tiffany/" title="Tiffany"><b>Tiffany</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Valentinoshoushi/" title="华伦天奴"><b>华伦天奴</b></a><i>|</i>
   
     </li>
                                                             </ul>
</div>
<div style="_width:670px;" class="dropmenudiv" id="dropmenu5">
  <ul>
                                                 <li>
    <h3><a title="眼镜" href="http://www.52milan.com/mojing/">眼镜:</a></h3>
 
      
    <a href="http://www.52milan.com/ferrari/" title="法拉利"><b>法拉利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/porsche/" title="保时捷"><b>保时捷</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lvmojing/" title="LV"><b>LV</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/pradamojing/" title="普拉达"><b>普拉达</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccimojing/" title="古奇"><b>古奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/kdytyj/" title="卡地亚"><b>卡地亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/amntyj/" title="阿玛尼"><b>阿玛尼</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lodk/" title="克罗心"><b>克罗心</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/diortyj/" title="迪奥"><b>迪奥</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/montblanctyj/" title="万宝龙"><b>万宝龙</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/todsmojing/" title="托德斯"><b>托德斯</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/swarovski/" title="施华洛世奇"><b>施华洛世奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrytyj/" title="巴宝莉"><b>巴宝莉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendityj/" title="芬迪"><b>芬迪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamotyj/" title="菲拉格慕"><b>菲拉格慕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/vivian/" title="薇薇安"><b>薇薇安</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Chaneltyj/" title="香奈儿"><b>香奈儿</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermestyj/" title="爱马仕"><b>爱马仕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/dunhill/" title="登喜路"><b>登喜路</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvlgarityj/" title="宝格丽"><b>宝格丽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cazal/" title="卡加尔"><b>卡加尔</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/celinetyj/" title="赛琳"><b>赛琳</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/RobertoCavallityj/" title="罗伯特·卡沃利"><b>罗伯特·卡沃利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MarcJacobstyj/" title="马杰克"><b>马杰克</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Polaroidtyj/" title="宝丽来"><b>宝丽来</b></a><i>|</i>
   
     </li>
                                                                                             </ul>
</div>
<div style="_width:530px;" class="dropmenudiv" id="dropmenu6">
  <ul>
                                                                                                                 <li>
    <h3><a title="帽子" href="http://www.52milan.com/mao/">帽子:</a></h3>
 
      
    <a href="http://www.52milan.com/lvmaozi/" title="LV帽子"><b>LV帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccimaozi/" title="GUCCI帽子"><b>GUCCI帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendimaozi/" title="Fendi帽子"><b>Fendi帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrymaozi/" title="Burberry帽"><b>Burberry帽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermesmaozi/" title="Hermes帽"><b>Hermes帽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanelmao/" title="Chanel帽子"><b>Chanel帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MCMHat/" title="MCM帽子"><b>MCM帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/PradaHat/" title="Prada帽子"><b>Prada帽子</b></a><i>|</i>
   
     </li>
                             </ul>
</div>                                                   
<div style="_width:530px;" class="dropmenudiv" id="dropmenu7">
  <ul>
                                                                                                 <li>
    <h3><a title="丝巾" href="http://www.52milan.com/sijin/">丝巾:</a></h3>
 
      
    <a href="http://www.52milan.com/lvsijin/" title="LV丝巾"><b>LV丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermessijin/" title="爱马仕丝巾"><b>爱马仕丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanelsijin/" title="香奈儿丝巾"><b>香奈儿丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccisijin/" title="gucci丝巾"><b>gucci丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Pradasijin/" title="普拉达丝巾"><b>普拉达丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvsijin/" title="BV丝巾"><b>BV丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/celinesijin/" title="赛琳丝巾"><b>赛琳丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/givenchysijin/" title="纪梵希丝巾"><b>纪梵希丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendisijin/" title="芬迪丝巾"><b>芬迪丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrysijin/" title="巴宝莉丝巾"><b>巴宝莉丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/valentinosijin/" title="华伦天奴丝巾"><b>华伦天奴丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ToryBurchsijin/" title="托里伯奇丝巾"><b>托里伯奇丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/AlexanderWangsijin/" title="亚历山大·麦昆丝巾"><b>亚历山大·麦昆丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/marcjacobssijin/" title="马克·雅可布丝巾"><b>马克·雅可布丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/etrosijin/" title="艾特罗丝巾"><b>艾特罗丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/kenzosijin/" title="Kenzo丝巾"><b>Kenzo丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Diorsijin/" title="迪奥丝巾"><b>迪奥丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamosijin/" title="菲拉格慕丝巾"><b>菲拉格慕丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Loewesijin/" title="罗意威丝巾"><b>罗意威丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Armanisijin/" title="阿玛尼丝巾"><b>阿玛尼丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/DGsijin/" title="D&amp;G丝巾"><b>D&amp;G丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/YSLsijin/" title="圣罗兰丝巾"><b>圣罗兰丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Zegnasijin/" title="杰尼亚丝巾"><b>杰尼亚丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/swarovskisijin/" title="施华洛世奇丝巾"><b>施华洛世奇丝巾</b></a><i>|</i>
   
     </li>
                                             </ul>
</div>  
<script type="text/javascript">cssdropdown.startchrome("chromemenu")</script>
</div><script type="text/javascript" src="themes/wbw2012/js/compare_ec.js"></script>
<div class="blank"></div>
<div class="block clearfix">
  <div id="ur_here">
    <div class="f_l">当前位置: <a href=".">首页</a> <code>&gt;</code> <a href="http://www.52milan.com/ding/">包包</a></div>
    <div class="f_r">
      
      <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare"> <span class="bds_more">分享到：</span> <a class="bds_qzone"></a> <a class="bds_tsina"></a> <a class="bds_tqq"></a> <a class="bds_renren"></a> <a class="shareCount"></a> </div>
      <script type="text/javascript" id="bdshare_js" data="type=tools" ></script>
      <script type="text/javascript" id="bdshell_js"></script>
      <script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
      
    </div>
  </div>
  <div class="block box"> <a href="/new.html"> <img src="/data/afficheimg/1356659573508413815.jpg" alt="包包" width="1000" height="125"></a> </div>
  <div class="blank"></div>
  
  <div class="AreaL">
    
     554fcae493e564ee0dc75bdf2ebf94caads|a:3:{s:4:"name";s:3:"ads";s:2:"id";s:1:"1";s:3:"num";s:1:"0";}554fcae493e564ee0dc75bdf2ebf94ca 
    
     <div class="blank"></div>
    <div id="news_listview">
      <div class="tab">
        <ul>
          <li class="cur">相关描叙</li>
        </ul>
      </div>
      <div class="page cur">
        <p>
     
             什么品牌的包包最时尚 
	&nbsp;
	　　对于时尚男女们来说，包包是他们每天出门都要带的配件，并不只是因为他们要装的东西十分多才需要用到包包，还因为一个时尚的包包能让他们看起来更加有气质，当然前提是他们使用的是一款适合自己的女包或者男包，普通的包包只会让一个人看起来更加普通。 
	&nbsp;
	　　我们走在大街上，随处都可以看到品牌包，不管是男人还是女人几乎都是人手一包。每个人的风格不同，所以使用的包包也不一样，很多人在包包选购方面没有太多的经验，个人的眼光也不是十分好，所以购买到的包包款式都不是十分的好看。如果大家想要购买到一款个性的男包或者女包，可以根据包包的品牌来购买。那么，什么品牌的包包最时尚呢？下面就为大家介绍一下，让大家在购买包包的时候心里有底。 
...              
        </p>
      </div>
    </div>
    <div class="blank"></div>
    <div id="hot_sale">
      <div class="l__hot_sale"></div>
      <ul>
                <li> <a class="img" target="_blank" href="/hermes-g43104.html"><img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/9396-02.jpg"  alt="9396-5黑色 爱马仕男士单肩手提包_2013新上市休闲公文包_hermes男包" >
       
          </a> <a class="txt" target="_blank" href="/hermes-g43104.html">9396-5黑色 爱马仕男士单肩手提包_2013新上...</a> <span class="price">￥800</span> </li>
                <li> <a class="img" target="_blank" href="/chanel-g43145.html"><img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/1/67232-05.jpg"  alt="67232大红布纹古银 Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" >
       
          </a> <a class="txt" target="_blank" href="/chanel-g43145.html">67232大红布纹古银 Chanel新款百搭韩版经典...</a> <span class="price">￥1800</span> </li>
                <li> <a class="img" target="_blank" href="/chanelsijin-g44906.html"><img src="http://bbpp.u.qiniudn.com/Chanelscarves2013/1/CH1118-2.jpg"  alt="CH1118-2 香奈儿奢华大牌丝巾_香奈儿2013热销奢华高端大气真丝丝巾_Chanel丝巾" >
       
          </a> <a class="txt" target="_blank" href="/chanelsijin-g44906.html">CH1118-2 香奈儿奢华大牌丝巾_香奈儿2013...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="/hermespidai-g43826.html"><img src="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00545-01.jpg"  alt="H00545 hermes独家休闲百搭男士皮带_爱马仕潮流经典款式" >
       
          </a> <a class="txt" target="_blank" href="/hermespidai-g43826.html">H00545 hermes独家休闲百搭男士皮带_爱马...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="/hermespidai-g43827.html"><img src="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00546-01.jpg"  alt="H00546 hermes英伦潮男休闲大方皮带_爱马仕官网皮带" >
       
          </a> <a class="txt" target="_blank" href="/hermespidai-g43827.html">H00546 hermes英伦潮男休闲大方皮带_爱马...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="/hermespidai-g43828.html"><img src="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00547-01.jpg"  alt="H00547 hermes百搭韩版个性全皮皮带_爱马仕厂家直销皮皮带" >
       
          </a> <a class="txt" target="_blank" href="/hermespidai-g43828.html">H00547 hermes百搭韩版个性全皮皮带_爱马...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="/hermespidai-g43829.html"><img src="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00548-01.jpg"  alt="H00548 hermes韩版裤腰带_爱马仕男士多用皮带" >
       
          </a> <a class="txt" target="_blank" href="/hermespidai-g43829.html">H00548 hermes韩版裤腰带_爱马仕男士多用...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="/hermespidai-g43830.html"><img src="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00549-01.jpg"  alt="H00549 hermes韩版休闲百搭男士裤带_爱马仕独家大牌产品" >
       
          </a> <a class="txt" target="_blank" href="/hermespidai-g43830.html">H00549 hermes韩版休闲百搭男士裤带_爱马...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="/hermespidai-g43831.html"><img src="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00550-01.jpg"  alt="H00550 hermes潮男商务百搭正装腰带_爱马仕大牌经典款" >
       
          </a> <a class="txt" target="_blank" href="/hermespidai-g43831.html">H00550 hermes潮男商务百搭正装腰带_爱马...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="/hermespidai-g43832.html"><img src="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00551-01.jpg"  alt="H00551 hermes韩版大品仿简约男士皮带_爱马仕经典热销款式" >
       
          </a> <a class="txt" target="_blank" href="/hermespidai-g43832.html">H00551 hermes韩版大品仿简约男士皮带_爱...</a> <span class="price">￥0</span> </li>
              </ul>
    </div>
    <div class="blank5"></div>
        <div id="brand_recommended">
      <div class="l__brand_recommeded"></div>
      <div class="c">
        <ul class="logos">
                    <li><a href="http://www.52milan.com/ding-b100/" title="LV路易威登"><span><img src="data/brandlogo/1357077708628288301.jpg" alt="LV路易威登 (36)" /></span><b>LV路易威登 </b></a></li>
                    <li><a href="http://www.52milan.com/ding-b101/" title="Hermes爱马仕"><span><img src="data/brandlogo/1357077806274511679.jpg" alt="Hermes爱马仕 (100)" /></span><b>Hermes爱马仕 </b></a></li>
                    <li><a href="http://www.52milan.com/ding-b104/" title="chanel香奈儿"><span><img src="data/brandlogo/1357078202840981454.jpg" alt="chanel香奈儿 (195)" /></span><b>chanel香奈儿 </b></a></li>
                  </ul>
      </div>
    </div>
    <div class="blank5"></div>
    <div id="news_list">
      <div class="tab">
        <ul>
          <li class="cur">相关文章</li>
          <li class="">包包资讯</li>
          <li class="">网站承诺</li>
        </ul>
      </div>
      <div class="page cur">
        <ul>
                            </ul>
      </div>
      <div class="page">
        <ul>
                            </ul>
      </div>
      <div class="page">
        <p>维美达汇集世界名牌奢侈品包，购买女包、男包、钱包或了解品牌包价格、图片请到维美达皮具网。支持货到付款，让您零风险购物！</p>
      </div>
    </div>
    <div class="blank"></div>
  </div>
  
  
  <div class="AreaR">
            
        <div class="box_pro">
      <div class="screetit"><span>商品筛选</span></div>
            	<div class="next_selected clearfix">
        <div class="next_selected_first">品牌：</div>
        <div id="classification" class="next_selected_second next_selected_second_fold">
           
           
               
                                      全部                              
                            <a href="http://www.52milan.com/ding-b100/" title="LV路易威登">LV路易威登</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b101/" title="Hermes爱马仕">Hermes爱马仕</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b104/" title="chanel香奈儿">chanel香奈儿</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b106/" title="burberry巴宝莉">burberry巴宝莉</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b110/" title="dior迪奥">dior迪奥</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b111/" title="BV宝缇嘉">BV宝缇嘉</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b113/" title="chloe克洛伊">chloe克洛伊</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b115/" title="cartier卡地亚">cartier卡地亚</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b116/" title="ysl圣罗兰">ysl圣罗兰</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b117/" title="loewe罗意威">loewe罗意威</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b118/" title="tods托德斯">tods托德斯</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b129/" title="Armani阿玛尼">Armani阿玛尼</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b128/" title="montblanc万宝龙">montblanc万宝龙</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b131/" title="bally巴利">bally巴利</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b133/" title="ferragamo菲拉格慕">ferragamo菲拉格慕</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b125/" title="Alexander Wang亚历山大·王">Alexander Wang亚历山大·王</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b140/" title="Stephen斯蒂芬">Stephen斯蒂芬</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b141/" title="Zegna杰尼亚">Zegna杰尼亚</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b161/" title="Valentino 华伦天奴">Valentino 华伦天奴</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b173/" title="MCM慕尼黑">MCM慕尼黑</a>&nbsp;
                       
                            <a href="http://www.52milan.com/ding-b175/" title="Thomas Wylde 托马斯·沃德">Thomas Wylde 托马斯·沃德</a>&nbsp;
                       
                        
                                                </ul>
        </div>
        <div class="next_selected_folddiv">
            <div class="next_selected_folddiv_word">展开</div>
            <div class="next_selected_folddiv_arrow"></div>
        </div>
    </div>
                      </div>
    <div class="blank5"></div>
        
    <div class="seacher" id=""> <span class="orange bold">你是不是想找：</span> <a href="/search.php?keywords=lv女包">lv女包</a><span class="line">| <a href="/search.php?keywords=女包">女包</a><span class="line">| <a href="/search.php?keywords=男包">男包</a><span class="line">| <a href="/search.php?keywords=单肩包">单肩包</a><span class="line">| <a href="/search.php?keywords=女大包">女大包</a><span class="line">| </span></span></span></span></span></div>
    <div class="box">
 <div class="probox">
  <div class="protit">
  <span>共613款商品</span><a name='goods_list'></a>
  <form method="GET" class="sort" name="listform">
  显示方式：
  <a href="javascript:;" onClick="javascript:display_mode('list')"><img src="themes/wbw2012/images/display_mode_list.gif" alt=""></a>
  <a href="javascript:;" onClick="javascript:display_mode('grid')"><img src="themes/wbw2012/images/display_mode_grid_act.gif" alt=""></a>
  <a href="javascript:;" onClick="javascript:display_mode('text')"><img src="themes/wbw2012/images/display_mode_text.gif" alt=""></a>&nbsp;&nbsp;
  
  <a href="/category.php?category=10&display=grid&brand=0&price_min=0&price_max=0&filter_attr=0&page=1&sort=goods_id&order=ASC#goods_list"><img src="themes/wbw2012/images/goods_id_DESC.GIF" alt="按上架时间排序"></a>
  <a href="/category.php?category=10&display=grid&brand=0&price_min=0&price_max=0&filter_attr=0&page=1&sort=shop_price&order=ASC#goods_list"><img src="themes/wbw2012/images/shop_price_default.GIF" alt="按价格排序"></a>
  <a href="/category.php?category=10&display=grid&brand=0&price_min=0&price_max=0&filter_attr=0&page=1&sort=last_update&order=DESC#goods_list"><img src="themes/wbw2012/images/last_update_default.GIF" alt="按更新时间排序"></a>&nbsp;
  <input type="hidden" name="category" value="10" />
  <input type="hidden" name="display" value="grid" id="display" />
  <input type="hidden" name="brand" value="0" />
  <input type="hidden" name="price_min" value="0" />
  <input type="hidden" name="price_max" value="0" />
  <input type="hidden" name="filter_attr" value="0" />
  <input type="hidden" name="page" value="1" />
  <input type="hidden" name="sort" value="goods_id" />
  <input type="hidden" name="order" value="DESC" />
  </form>
  </div>
 </div>
      <form name="compareForm" action="compare.php" method="post" onSubmit="return compareGoods(this);">
            <div class="centerPadd">
    <div class="goodsBox clearfix">
             <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44684.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1703D-01.jpg" alt="1703D黑色 爱马仕新款潮流包包_Hermes20..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44684.html" title="1703D黑色 爱马仕新款潮流包包_Hermes2013热销新品百搭时尚包包_爱马仕包包" target="_blank">1703D黑色 爱马仕新款潮流包包_Hermes20...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44683.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1703-02.jpg" alt="1703-黑色 Hermes热销新款时尚包包_爱马仕..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44683.html" title="1703-黑色 Hermes热销新款时尚包包_爱马仕2013热销新品百搭时尚包包_爱马仕新款" target="_blank">1703-黑色 Hermes热销新款时尚包包_爱马仕...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44682.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1698D-01.jpg" alt="1698D黑色 爱马仕新款潮流包包_爱马仕2013热..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44682.html" title="1698D黑色 爱马仕新款潮流包包_爱马仕2013热销新品奢华大牌包包_爱马仕包包" target="_blank">1698D黑色 爱马仕新款潮流包包_爱马仕2013热...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44681.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1697D-01.jpg" alt="1697D黑色 Hermes新品潮流大牌包包_Her..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44681.html" title="1697D黑色 Hermes新品潮流大牌包包_Hermes2013热销新品百搭时尚包包_Hermes包包" target="_blank">1697D黑色 Hermes新品潮流大牌包包_Her...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44680.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1696D-01.jpg" alt="1696D黑色 爱马仕新品百搭大牌包包_爱马仕201..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44680.html" title="1696D黑色 爱马仕新品百搭大牌包包_爱马仕2013热销新品奢华大牌包包_爱马仕厂家直销" target="_blank">1696D黑色 爱马仕新品百搭大牌包包_爱马仕201...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44679.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1696-02.jpg" alt="1696-黑 爱马仕新款潮流包包_Hermes201..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44679.html" title="1696-黑 爱马仕新款潮流包包_Hermes2013热销新品百搭时尚包包_爱马仕新款" target="_blank">1696-黑 爱马仕新款潮流包包_Hermes201...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44678.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1688D-01.jpg" alt="1688D黑色 Hermes新品百搭大牌包包_爱马仕..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44678.html" title="1688D黑色 Hermes新品百搭大牌包包_爱马仕2013热销新品奢华大牌包包_爱马仕包包" target="_blank">1688D黑色 Hermes新品百搭大牌包包_爱马仕...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44677.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1686-01.jpg" alt="1686黑色 爱马仕新款潮流包包_Hermes201..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44677.html" title="1686黑色 爱马仕新款潮流包包_Hermes2013热销新品百搭时尚包包_爱马仕新款" target="_blank">1686黑色 爱马仕新款潮流包包_Hermes201...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44676.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1685-01.jpg" alt="1685黑色 Hermes热销新款时尚包包_爱马仕2..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44676.html" title="1685黑色 Hermes热销新款时尚包包_爱马仕2013新品热销时尚大气包包_Hermes包包" target="_blank">1685黑色 Hermes热销新款时尚包包_爱马仕2...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44675.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1684D-02.jpg" alt="1684D黑色 爱马仕新品百搭大牌包包_爱马仕201..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44675.html" title="1684D黑色 爱马仕新品百搭大牌包包_爱马仕2013热销新品奢华大牌包包_爱马仕包包" target="_blank">1684D黑色 爱马仕新品百搭大牌包包_爱马仕201...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44674.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1684D-01.jpg" alt="1684D橙色 爱马仕新款潮流包包_Hermes20..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44674.html" title="1684D橙色 爱马仕新款潮流包包_Hermes2013热销新品百搭时尚包包_爱马仕新款" target="_blank">1684D橙色 爱马仕新款潮流包包_Hermes20...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44673.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1678M-01.jpg" alt="1678M蓝色 Hermes新品百搭大牌包包_爱马仕..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44673.html" title="1678M蓝色 Hermes新品百搭大牌包包_爱马仕2013新品热销时尚大气包包_Hermes包包" target="_blank">1678M蓝色 Hermes新品百搭大牌包包_爱马仕...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44672.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1677-01.jpg" alt="1677黑色 爱马仕新品百搭大牌包包_爱马仕2013..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44672.html" title="1677黑色 爱马仕新品百搭大牌包包_爱马仕2013热销新品奢华大牌包包_爱马仕厂家直销" target="_blank">1677黑色 爱马仕新品百搭大牌包包_爱马仕2013...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44671.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1670-01.jpg" alt="1670黑色 爱马仕新款潮流包包_Hermes201..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44671.html" title="1670黑色 爱马仕新款潮流包包_Hermes2013热销新品百搭时尚包包_爱马仕新款" target="_blank">1670黑色 爱马仕新款潮流包包_Hermes201...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44670.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1667-01.jpg" alt="1667橙色 Hermes热销新款时尚包包_爱马仕2..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44670.html" title="1667橙色 Hermes热销新款时尚包包_爱马仕2013新品热销时尚大气包包_Hermes包包" target="_blank">1667橙色 Hermes热销新款时尚包包_爱马仕2...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44669.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1663D-01.jpg" alt="1663D黑色 爱马仕新品百搭大牌包包_爱马仕201..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44669.html" title="1663D黑色 爱马仕新品百搭大牌包包_爱马仕2013热销新品奢华大牌包包_爱马仕包包" target="_blank">1663D黑色 爱马仕新品百搭大牌包包_爱马仕201...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44668.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1659-01.jpg" alt="1659黑色 爱马仕新款潮流包包_Hermes201..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44668.html" title="1659黑色 爱马仕新款潮流包包_Hermes2013热销新品百搭时尚包包_爱马仕新款" target="_blank">1659黑色 爱马仕新款潮流包包_Hermes201...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44667.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1656-02.jpg" alt="1656蓝色 爱马仕新品百搭大牌包包_爱马仕2013..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44667.html" title="1656蓝色 爱马仕新品百搭大牌包包_爱马仕2013新品热销时尚大气包包_爱马仕包包" target="_blank">1656蓝色 爱马仕新品百搭大牌包包_爱马仕2013...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44666.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1656-01.jpg" alt="1656黑色 Hermes新品百搭大牌包包_爱马仕2..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44666.html" title="1656黑色 Hermes新品百搭大牌包包_爱马仕2013热销新品奢华大牌包包_爱马仕厂家直销" target="_blank">1656黑色 Hermes新品百搭大牌包包_爱马仕2...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44665.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1647B-01.jpg" alt="1647B黑色 爱马仕新款潮流包包_Hermes20..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44665.html" title="1647B黑色 爱马仕新款潮流包包_Hermes2013热销新品百搭时尚包包_爱马仕新款" target="_blank">1647B黑色 爱马仕新款潮流包包_Hermes20...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44664.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1644D-02.jpg" alt="1644D蓝 Hermes热销新款时尚包包_爱马仕2..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44664.html" title="1644D蓝 Hermes热销新款时尚包包_爱马仕2013热销新品奢华大牌包包_Hermes包包" target="_blank">1644D蓝 Hermes热销新款时尚包包_爱马仕2...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44663.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1644D-01.jpg" alt="1644D橙色 爱马仕新款潮流包包_爱马仕2013新..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44663.html" title="1644D橙色 爱马仕新款潮流包包_爱马仕2013新品热销时尚大气包包_爱马仕包包" target="_blank">1644D橙色 爱马仕新款潮流包包_爱马仕2013新...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44662.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1376A-01.jpg" alt="1376A黑色 Hermes热销新款时尚包包_Her..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44662.html" title="1376A黑色 Hermes热销新款时尚包包_Hermes2013热销新品百搭时尚包包_爱马仕新款" target="_blank">1376A黑色 Hermes热销新款时尚包包_Her...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44661.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1035-01.jpg" alt="1035进口牛津布橙色 Hermes新品百搭大牌包包..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44661.html" title="1035进口牛津布橙色 Hermes新品百搭大牌包包_爱马仕2013热销新品奢华大牌包包" target="_blank">1035进口牛津布橙色 Hermes新品百搭大牌包包...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44660.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/858M-02.jpg" alt="858M黑色 Hermes热销新款时尚包包_爱马仕2..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44660.html" title="858M黑色 Hermes热销新款时尚包包_爱马仕2013热销新品奢华大牌包包_Hermes包包" target="_blank">858M黑色 Hermes热销新款时尚包包_爱马仕2...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/hermes-g44659.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/845M-01.jpg" alt="845M蓝色 爱马仕新款潮流包包_Hermes201..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/hermes-g44659.html" title="845M蓝色 爱马仕新款潮流包包_Hermes2013热销新品百搭时尚包包_爱马仕新款" target="_blank">845M蓝色 爱马仕新款潮流包包_Hermes201...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/lv-g44658.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/LVHandbags2013/1/M93595-39.jpg" alt="M93595亮橙 LV热款经典女士包包_LV2013..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/lv-g44658.html" title="M93595亮橙 LV热款经典女士包包_LV2013新款热销潮流大牌贝壳包_LV贝壳包" target="_blank">M93595亮橙 LV热款经典女士包包_LV2013...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/lv-g44657.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/LVHandbags2013/1/M93595-38.jpg" alt="M93595电光蓝 路易威登热款新品女士包包_LV2..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/lv-g44657.html" title="M93595电光蓝 路易威登热款新品女士包包_LV2013新款热卖时尚贝壳包_LV包包" target="_blank">M93595电光蓝 路易威登热款新品女士包包_LV2...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/lv-g44656.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/LVHandbags2013/1/M93595-37.jpg" alt="M93595-深蓝 LV热款新品女士包包_LV201..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/lv-g44656.html" title="M93595-深蓝 LV热款新品女士包包_LV2013新款热销时尚贝壳包_LV热销包包" target="_blank">M93595-深蓝 LV热款新品女士包包_LV201...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/lv-g44655.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/LVHandbags2013/1/M91619-17.jpg" alt="M91619樱花粉 路易威登热款新品女士包包_LV2..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/lv-g44655.html" title="M91619樱花粉 路易威登热款新品女士包包_LV2013经典款热销女士包包_LV贝壳包" target="_blank">M91619樱花粉 路易威登热款新品女士包包_LV2...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/lv-g44654.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/LVHandbags2013/1/M91606-61.jpg" alt="M91606-深蓝 LV热款经典女士包包_LV201..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/lv-g44654.html" title="M91606-深蓝 LV热款经典女士包包_LV2013新款热销奢华百搭贝壳包_LV热销" target="_blank">M91606-深蓝 LV热款经典女士包包_LV201...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥0</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
                 <div class="goodsItem">
           <div class="hoverlist"><a href="http://www.52milan.com/lv-g44653.html" target="_blank">
           <img src="http://bbpp.u.qiniudn.com/LVHandbags2013/1/M91606-60.jpg" alt="M91606亮橙 LV热款新品女士包包_LV2013..." class="goodsimg" /></a></div>
           <p class="name"><a href="http://www.52milan.com/lv-g44653.html" title="M91606亮橙 LV热款新品女士包包_LV2013新款热销时尚贝壳包_LV包包" target="_blank">M91606亮橙 LV热款新品女士包包_LV2013...</a></p> 
           <p>
                        本店售价：<font class="shop_s f7">￥500</font>
                        </p>
            <p>
             <font class="rank_s"><img src="/ad/price.jpg" alt="批发请联系客服"></font>
            </p>
          </p>     
        </div>
            </div>
    </div>
        </form>
  </div>
<div class="blank5"></div>
<script type="Text/Javascript" language="JavaScript">
<!--
function selectPage(sel)
{
  sel.form.submit();
}
//-->
</script>
<script type="text/javascript">
window.onload = function()
{
  Compare.init();
  fixpng();
}
var button_compare = '';
var exist = "您已经选择了%s";
var count_limit = "最多只能选择4个商品进行对比";
var goods_type_different = "\"%s\"和已选择商品类型不同无法进行对比";
var compare_no_goods = "您没有选定任何需要比较的商品或者比较的商品数少于 2 个。";
var btn_buy = "购买";
var is_cancel = "取消";
var select_spe = "请选择商品属性";
</script> <form name="selectPageForm" action="/category.php" method="get">
 
<div id="page_nav">
                    <input type="hidden" name="category" value="10" />
                          <input type="hidden" name="keywords" value="" />
                            <input type="hidden" name="sort" value="goods_id" />
                          <input type="hidden" name="order" value="DESC" />
                          <input type="hidden" name="cat" value="10" />
                          <input type="hidden" name="brand" value="0" />
                          <input type="hidden" name="price_min" value="0" />
                          <input type="hidden" name="price_max" value="0" />
                          <input type="hidden" name="filter_attr" value="0" />
                          <input type="hidden" name="display" value="grid" />
              <kbd style="float:right; margin:0 8px; position:relative; top:3px;"><input type="text" name="page" onkeydown="if(event.keyCode==13)selectPage(this)" size="3" class="B_blue" /></kbd>
    		
<span>一共有&nbsp;613&nbsp;条记录&nbsp;&nbsp;</span> 
  <span class="pre"><span></span>上一页</span>                 <span class="cur">1</span>
                      <a href="http://www.52milan.com/ding-p2/">2</a>
                      <a href="http://www.52milan.com/ding-p3/">3</a>
                      <a href="http://www.52milan.com/ding-p4/">4</a>
                      <a href="http://www.52milan.com/ding-p5/">5</a>
                      <a href="http://www.52milan.com/ding-p6/">6</a>
                      <a href="http://www.52milan.com/ding-p7/">7</a>
                      <a href="http://www.52milan.com/ding-p8/">8</a>
                      <a href="http://www.52milan.com/ding-p9/">9</a>
                      <a href="http://www.52milan.com/ding-p10/">10</a>
                  
  	  <a href="/ding-p2/" class="next">下一页<span></span></a>  
 </div>
 
       
</form>
<script type="Text/Javascript" language="JavaScript">
<!--
function selectPage(sel)
{
  sel.form.submit();
}
//-->
</script> </div>
  
</div>
 <style>
.weixin_pic {
    background-image: none;
    position: absolute;
    z-index: 9999;
	right:367px;
	margin-top:16px;
	_margin-top:18px;
	
}
.weixin_pic img{
	z-index: 9999;
	}
</style>
<div id="footer">
  <div class="info">
    <p> 
       
      <a href="http://www.lvbaopifa.com/article-204.html"   rel="nofollow" >维美达皮具网的优势</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-203.html"   rel="nofollow" >实体批发</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-97.html"   rel="nofollow" >咨询热点</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-205.html"   rel="nofollow" >国外支付方式</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-206.html"   rel="nofollow" >包包等级说明</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-207.html"   rel="nofollow" >运费查询</a> 
       
        |
      <a  href="/sitemap.html" target="_blank">网站地图</a>
    </p>
    
        <p>  
       
      </p>
    <p class="copyright">&copy; 2005-2014 米兰精品商城 版权所有，并保留所有权利。</p>
   
  </div>
</div>
<div class="blank5"></div>
<script type="text/javascript">
function datasrc(){
var imga = document.getElementsByTagName("img");
//alert('网站打开完毕！开始加载图片！');
for(i=0;i<imga.length;i++)
{
imgsrc=imga[i].getAttribute('data-src');
if (imgsrc!=null){
imga[i].setAttribute('src',""+imgsrc+"");
       }
}
}
</script>
<LINK rel=stylesheet type=text/css href="/images/common.css">
<DIV id=floatTools class=float0831>
  <DIV class=floatL> 
  <A style="DISPLAY: none" id="newswt_mini" class="btnOpen" title="查看在线客服"  href="javascript:void(0);">展开</A> 
<A id="newswt_close" class="btnCtn" title="关闭在线客服" href="javascript:void(0);">收缩</A> </DIV>
  <DIV id=divFloatToolsView class=floatR>
    <DIV class=tp></DIV>
    <DIV class=cn>
      <UL>
        <LI class=top>
          <H3 class=titZx>QQ咨询</H3>
        </LI>
        <LI><a rel="nofollow" target="_blank" href="/kefu_1.html?arg=lvbao1688&amp;style=1"><img width="80" height="26" src="/themes/wbw2012/images/zxkf.gif"></a></LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=800009775&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服①</A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1622861430&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服② </A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1764924587&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服③</A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1984216240&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服④</A> </LI>
         <LI><A  href="http://amos.im.alisoft.com/msg.aw?v=2&uid=%E7%BB%B4%E7%BE%8E%E8%BE%BE%E7%9A%AE%E5%85%B7&site=cntaobao&s=1&charset=utf-8" target="_blank" rel="nofollow"><img src="/ad/wangwang.gif"></A> </LI>
      </UL>
      <UL>
        <LI>
          <H3 class=titDh>电话咨询</H3>
        </LI>
        <LI><SPAN class=icoTl>4006-346-588</SPAN> </LI>
        <LI>
        <SPAN class=icoTl>15811883379</SPAN>
        </LI>
        <LI class=bot>
          <H3 class=titDc><A href="/message.php" target="_blank">给我留言</A></H3>
        </LI>
      </UL>
    </DIV>
  </DIV>
</DIV>
<script type="text/javascript">
function mouseOver()
{
    document.getElementById('weixin_pic').style.display = "block";
}
function mouseOut()
{
    document.getElementById('weixin_pic').style.display = "none";
}
$(function(){
 $(".weixin").mouseenter(function () {
        $(this).children('.weixin_pic').show();
    }).mouseleave(function () {
        $(this).children('.weixin_pic').hide();
 })
})
$(function(){
	$('#floatTools').show();
	/*$('.swt_h').prev().addClass('swt_current_t');
	$('.swt_tit').each(function(){
		$(this).click(function(){
			$(this).toggleClass('swt_current_t').next().slideToggle()
		})
	});*/
	$('#newswt_close').click(function(){
		$(this).hide()							  
		$('#divFloatToolsView').animate({
			width:'-=130'
		},400,function(){
			$(this).hide()
			$('#newswt_mini').show().animate({
				width:'+=40'
			},600)
		})
	});
	$('#newswt_mini').click(function(){
	    $(this).hide()								 
		$(this).animate({
			width:'-=40'
		},100,function(){
			$('#divFloatToolsView').show().animate({
				width:'+=130'
			},400,function(){
				$('#newswt_close').show().animate({
				width:'+=0'
			},600)
		  })
		})
	})
}) 
</script>
).animate({
				width:'+=0'
			},600)
		  })
		})
	})
}) 
</script>
<script type="text/javascript">
var news_list;
$(function(){
	news_list = $("#news_list");
	//左侧新闻选项卡
	news_list.find("div.tab>ul>li").each(function(idx){
		var this_ = $(this);
		this_.bind("mouseover", function(){
			if(this_.hasClass('cur')==false){
				this_.siblings(".cur").removeClass("cur");	
				news_list.find(".cur").removeClass("cur");
				this_.addClass("cur");
				news_list.find(".page").eq(idx).addClass("cur");
			}
		});
	});
	
});
</script>
<script type="text/javascript">
    
    var current_category_id = "1";
    
    $(document).ready(function(){
       
      
        
        //fliter
        $(".next_selected_second").each(function(){
		    									 
            if($(this).height()>60 && $("#classification > .zk").height()==null){
                $(this).addClass("next_selected_second_big");
                $(this).siblings(".next_selected_folddiv").show();
                $(".next_selected_folddiv").toggle(function(){
                    $(this).siblings(".next_selected_second").removeClass("next_selected_second_big");
                    $(this).children(".next_selected_folddiv_word").text("收起");
                    $(this).siblings(".next_selected_second").addClass("next_selected_second_fold");
                    $(this).children(".next_selected_folddiv_arrow").addClass("next_selected_folddiv_arrow_away");
                },function(){
                    $(this).siblings(".next_selected_second").addClass("next_selected_second_big");
                    $(this).children(".next_selected_folddiv_word").text("展开");
                    $(this).siblings(".next_selected_second").removeClass("next_selected_second_fold");
                    $(this).children(".next_selected_folddiv_arrow").removeClass("next_selected_folddiv_arrow_away");
                })
            }
			else if($(this).height()>60 && $("#classification > .zk").height()>0){
			    $(this).addClass("next_selected_second_fold");
                $(this).siblings(".next_selected_folddiv").show();
				$(this).removeClass("next_selected_second_big");
				$(".next_selected_folddiv > .next_selected_folddiv_word").text("收起");
				$(".next_selected_folddiv > .next_selected_folddiv_arrow").addClass("next_selected_folddiv_arrow_away");
                $(".next_selected_folddiv").toggle(function(){
                  
					
					$(this).siblings(".next_selected_second").addClass("next_selected_second_big");
                    $(this).children(".next_selected_folddiv_word").text("展开");
                    $(this).siblings(".next_selected_second").removeClass("next_selected_second_fold");
                    $(this).children(".next_selected_folddiv_arrow").removeClass("next_selected_folddiv_arrow_away");
					
                },function(){
                    
					  $(this).siblings(".next_selected_second").removeClass("next_selected_second_big");
                    $(this).children(".next_selected_folddiv_word").text("收起");
                    $(this).siblings(".next_selected_second").addClass("next_selected_second_fold");
                    $(this).children(".next_selected_folddiv_arrow").addClass("next_selected_folddiv_arrow_away");
                })
			}
            else if($(this).height()>30 && $(this).height()<60){
                   $(this).siblings(".next_selected_folddiv").hide();
                   $(this).addClass("next_selected_second_small");
            }else if($(this).height()>30 && $(this).height()<60 && $("#classification > .zk").height()>0){
				 $(this).siblings(".next_selected_folddiv").hide();
                 $(this).addClass("next_selected_second_small");
				
				}
            else{
             
				
				$(this).addClass("next_selected_second_big");
                $(this).siblings(".next_selected_folddiv").hide();
            }
        });
    });
    
    
</script>
</body>
</html>