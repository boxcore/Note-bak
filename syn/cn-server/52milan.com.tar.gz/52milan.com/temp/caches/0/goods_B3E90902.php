<?php exit;?>a:3:{s:8:"template";a:10:{i:0;s:69:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/goods.dwt";i:1;s:83:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/page_header.lbi";i:2;s:79:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/ur_here.lbi";i:3;s:85:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/goods_gallery.lbi";i:4;s:79:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/add_cat.lbi";i:5;s:85:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/goods_article.lbi";i:6;s:88:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/goods_attrlinked.lbi";i:7;s:80:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/comments.lbi";i:8;s:76:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/help.lbi";i:9;s:83:"/home/dswfcn/domains/52milan.com/public_html/themes/wbw2012/library/page_footer.lbi";}s:7:"expires";i:1388942396;s:8:"maketime";i:1388938796;}<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<base href="http://www.52milan.com/" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="Keywords" content="" />
<meta name="Description" content="" />
<title>67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包_香奈儿_包包_【米兰精品商城】鞋子、包包、帽子、眼镜、皮带批发|名牌皮具的领航者!</title>
<link rel="shortcut icon" href="favicon.ico" />
<link rel="icon" href="animated_favicon.gif" type="image/gif" />
<link href="themes/wbw2012/style.css" rel="stylesheet" type="text/css" />
<link href="themes/wbw2012/MagicZoom.css" rel="stylesheet" type="text/css"/>
<script type="text/javascript" src="themes/wbw2012/js/mzp-packed-me.js"></script>
<script type="text/javascript" src="themes/wbw2012/js/site.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript">
function $id(element) {
  return document.getElementById(element);
}
//切屏--是按钮，_v是内容平台，_h是内容库
function reg(str){
  var bt=$id(str+"_b").getElementsByTagName("div");
  for(var i=0;i<bt.length;i++){
    bt[i].subj=str;
    bt[i].pai=i;
    bt[i].style.cursor="pointer";
    bt[i].onclick=function(){
      $id(this.subj+"_v").innerHTML=$id(this.subj+"_h").getElementsByTagName("blockquote")[this.pai].innerHTML;
      for(var j=0;j<$id(this.subj+"_b").getElementsByTagName("div").length;j++){
        var _bt=$id(this.subj+"_b").getElementsByTagName("div")[j];
        var ison=j==this.pai;
        _bt.className=(ison?"":"h2bg");
      }
    }
  }
  $id(str+"_h").className="none";
  $id(str+"_v").innerHTML=$id(str+"_h").getElementsByTagName("blockquote")[0].innerHTML;
}
</script>
<script type="text/javascript" src="/js/jquery-1.4.4.min.js" ></script>
<!--<script type="text/javascript" src="/themes/wbw2012/js/jquery.lazyload.js"></script>-->
<script type="text/javascript">
/*jQuery(document).ready(
function($){
$("img").lazyload({
     placeholder : "/themes/wbw2012/js/grey.gif", //加载图片前的占位图片
     effect      : "fadeIn" //加载图片使用的效果(淡入)
});
});*/
var desc;
jQuery(document).ready(function($){
desc = $("#desc");
	//desc.find("div.cur").find("img").lazyload({placeholder:"/themes/wb2009/images2/blank.gif", effect:"fadeIn"});
		   
   desc.find(".tab>a").each(function(idx){
		$(this).bind("click", function(){		
			var this_ = $(this);
			if(this_.hasClass("cur")==false){
				desc.find(".tab>a.cur").removeClass("cur");
				desc.find("div.cur").removeClass("cur");
				this_.addClass("cur");
				var page = desc.find("div.page").eq(idx);
				if(page.html() == ""){
					switch(idx){
						case 1:
							page.html('<div class="block"></div>');
							break;
						case 2:
							page.html('<div class="block"></div>');
							break;
						case 3:
							page.html('<div class="block"></div>');
							break;
					}	
				}
				page.addClass("cur");
			}
		});
	});
});   
</script>
</head>
<body>
<link href="http://www.52milan.com/themes/wbw2012/page_header.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="http://www.52milan.com/themes/wbw2012/js/chrome.js"></script>
<script type="text/javascript">
var process_request = "正在处理您的请求...";
</script>
<div id="header" style="z-index: 20;">
	<div class="top" style="z-index:19; height:27px;">
	<script type="text/javascript" src="themes/wbw2012/js/script.js" ></script>
    <script type="text/javascript" src="themes/wbw2012/js/transport_ec.js"></script>
	<script type="text/javascript" src="themes/wbw2012/js/all.js"></script>
    <script type="text/javascript" src="themes/wbw2012/js/globals.js"></script>
	<script type="text/javascript" src="js/utils.js"></script>	554fcae493e564ee0dc75bdf2ebf94camember_info|a:1:{s:4:"name";s:11:"member_info";}554fcae493e564ee0dc75bdf2ebf94ca	                            <a href="http://www.lvbaopifa.com/article-97.html" rel="nofollow" >帮助中心</a>
                                                   
                    <a style="height:28px; position:relative;z-index: 19;" class="weixin" id="weixin" onmouseover="mouseOver()" onmouseout="mouseOut()">   
                               
                   <img src="http://www.52milan.com/images/weixinlogo.jpg" width="67" height="26"></a>
                      <a style="display: none;" class="weixin_pic" id="weixin_pic"> 
                  <img alt="米兰精品商城" src="http://www.52milan.com/images/weixinerweima.jpg"></a>
                      
	<span class="s__cart" id="ECS_CARTINFO">554fcae493e564ee0dc75bdf2ebf94cacart_info|a:1:{s:4:"name";s:9:"cart_info";}554fcae493e564ee0dc75bdf2ebf94ca<span class="s__arrow_red_down"></span></span></div>
    
   <div class="hlogo"> <a href="http://www.52milan.com/" title="米兰精品商城"><img src="themes/wbw2012/images/logo.gif"  alt="米兰精品商城"></a></div>
    <form id="searchForm" name="searchForm" method="get" action="search.php" onSubmit="return checkSearchForm()">
	  <input type="text" name="keywords" id="w" onMouseOver="this.focus()" onblur="if(this.value =='') this.value='请输入商品名称或编号'" onFocus="this.select()" onClick="if(this.value=='请输入商品名称或编号') this.value=''" value="请输入商品名称或编号" class="txt" /><input type="submit" value=" " class="s__search" style="cursor:pointer;" />
      
    </form>
    <span id="hotline"><img src="http://www.52milan.com/themes/wbw2012/images/4006.jpg"></span>
</div>
<div class="menu">
<div id="chromemenu" class="chromestyle clearfix">
<ul>
<li id="dropmenu_home"><a href="http://www.52milan.com/">网站首页</a></li>
<li id="dropmenu_women"><a rel="dropmenu1" href="http://www.52milan.com/ding/">名牌包包</a></li>
<li id="dropmenu_man"><a rel="dropmenu2" href="http://www.52milan.com/xiezi/">名牌鞋子</a></li>
<li id="dropmenu_watch"><a rel="dropmenu3" href="http://www.52milan.com/pidai/">名牌皮带</a></li>
<li id="dropmenu_shoushi"><a rel="dropmenu4" href="http://www.52milan.com/shoushi/">名牌首饰</a></li>
<li id="dropmenu_belt"><a rel="dropmenu5" href="http://www.52milan.com/mojing/">名牌眼睛</a></li>
<li id="dropmenu_wallet"><a rel="dropmenu6" href="http://www.52milan.com/mao/">名牌帽子</a></li>
<li id="dropmenu_shijing"><a rel="dropmenu7" href="http://www.52milan.com/sijin/">丝巾</a></li>
<li id="dropmenu_acc"><a  href="http://www.52milan.com/pinpai.html">品牌纵览</a></li>
<li id="dropmenu_glass"><a href="http://www.52milan.com/new.html">新品上架</a></li>
<li id="dropmenu_shoe"><a href="http://www.52milan.com/article-202.html">加盟代理</a></li>
</ul>
</div>
<style>
.dropmenudiv ul {
    background: none repeat scroll 0 0 #FFFFFF;
    float: left;
    width: 600px;
}
.dropmenudiv ul li {
  
    clear: both;
    color: #999999;
    font-size: 12px;
    line-height: 30px;
}
.dropmenudiv h3 {
    color: #8A5D1A;
    float: left;
    font-weight: bold;
    line-height: 30px;
    margin: 0;
    padding: 0;
    text-indent: 8px;
    width: 96px;
}
.dropmenudiv h3 a {
    color: #8A5D1A;
}
.dropmenudiv h3 a:hover {
    background-color: #8A5D1A;
    color: #FFFFFF;
}
</style>                                                   
<div style="_width:750px;" class="dropmenudiv" id="dropmenu1">
   <ul>
                 <li>
    <h3><a title="包包" href="http://www.52milan.com/ding/">包包:</a></h3>
 
      
    <a href="http://www.52milan.com/hermes/" title="爱马仕"><b>爱马仕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bv/" title="宝缇嘉"><b>宝缇嘉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/prada/" title="普拉达"><b>普拉达</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvlgari/" title="宝格丽"><b>宝格丽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lv/" title="LV"><b>LV</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chloe/" title="克洛伊"><b>克洛伊</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/gucci/" title="古奇"><b>古奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/givenchy/" title="纪梵希"><b>纪梵希</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanel/" title="香奈儿"><b>香奈儿</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/miumiu/" title="缪缪"><b>缪缪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberry/" title="巴宝莉"><b>巴宝莉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/celine/" title="赛琳"><b>赛琳</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendi/" title="芬迪"><b>芬迪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/DMJ/" title="D&amp;G"><b>D&amp;G</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/dior/" title="迪奥"><b>迪奥</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/mulberry/" title="玛百莉"><b>玛百莉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/versace/" title="范思哲"><b>范思哲</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/furla/" title="芙拉"><b>芙拉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/marcjacobs/" title="马杰克"><b>马杰克</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cartier/" title="卡地亚"><b>卡地亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/marni/" title="玛尼"><b>玛尼</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/coach/" title="蔻驰"><b>蔻驰</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ylsdw/" title="亚历山大·王"><b>亚历山大·王</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ysl/" title="圣罗兰"><b>圣罗兰</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/balenciaga/" title="巴黎世家"><b>巴黎世家</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/montblanc/" title="万宝龙"><b>万宝龙</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/armani/" title="阿玛尼"><b>阿玛尼</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/boss/" title="BOSS"><b>BOSS</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bally/" title="巴利"><b>巴利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamo/" title="菲拉格慕"><b>菲拉格慕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/plessl/" title="普罗恩萨·施罗"><b>普罗恩萨·施罗</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/victoriacross/" title="维多利亚"><b>维多利亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/stephen/" title="斯蒂芬"><b>斯蒂芬</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lbtkwl/" title="罗伯特·卡沃利"><b>罗伯特·卡沃利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/loewe/" title="罗意威"><b>罗意威</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/tods/" title="托德斯"><b>托德斯</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/etro/" title="艾特罗"><b>艾特罗</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/RogerVivierbao/" title="罗杰·维威耶"><b>罗杰·维威耶</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Valentinobao/" title="华伦天奴"><b>华伦天奴</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/BMWHandbags/" title="宝马"><b>宝马</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Aquascutumbao/" title="雅格狮丹"><b>雅格狮丹</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ToryBurchbao/" title="托里伯奇"><b>托里伯奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/yusan/" title="名牌雨伞"><b>名牌雨伞</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/mcmbao/" title="MCM"><b>MCM</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/thomaswylde/" title="托马斯·沃德"><b>托马斯·沃德</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Zegna/" title="杰尼亚"><b>杰尼亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MichaelKors/" title="MK"><b>MK</b></a><i>|</i>
   
     </li>
                                                                                                                             </ul>
</div>
                                              
<div style="_width:650px;" class="dropmenudiv" id="dropmenu2">
  <ul>
                                 <li>
    <h3><a title="鞋子" href="http://www.52milan.com/xiezi/">鞋子:</a></h3>
 
      
    <a href="http://www.52milan.com/diorxie/" title="迪奥鞋"><b>迪奥鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendixie/" title="芬迪鞋"><b>芬迪鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lvxiezi/" title="LV鞋"><b>LV鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccixie/" title="gucci鞋"><b>gucci鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermesxie/" title="爱马仕鞋"><b>爱马仕鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/pradaxie/" title="普拉达鞋"><b>普拉达鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/dmgxiezi/" title="D&amp;G鞋"><b>D&amp;G鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ballyxie/" title="BALLY鞋"><b>BALLY鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvxiezi/" title="BV鞋"><b>BV鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamoxie/" title="菲拉格慕鞋子"><b>菲拉格慕鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/JimmyChooShoes/" title="周仰杰鞋"><b>周仰杰鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ManoloShoes/" title="马诺洛鞋"><b>马诺洛鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ArmaniShoes/" title="阿玛尼鞋"><b>阿玛尼鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/rvxie/" title="RV鞋"><b>RV鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/CelineShoes/" title="赛琳鞋子"><b>赛琳鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/YSLShoes/" title="圣罗兰鞋"><b>圣罗兰鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ToryBurchShoes/" title="托里伯奇鞋"><b>托里伯奇鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ChanelShoes/" title="香奈儿鞋"><b>香奈儿鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/AlexanderWangShoes/" title="亚历山大鞋"><b>亚历山大鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Balmainxie/" title="巴尔曼鞋"><b>巴尔曼鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/philippplein/" title="菲利普鞋"><b>菲利普鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/TodsShoes/" title="托德斯鞋"><b>托德斯鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/StephenShoes/" title="斯蒂芬鞋"><b>斯蒂芬鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/GZShoes/" title="GZ鞋子"><b>GZ鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/CharlotteOlympiaShoes/" title="夏洛特鞋"><b>夏洛特鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hellokittyShoes/" title="Hello Kitty鞋"><b>Hello Kitty鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ValentinoShoes/" title="华伦天奴鞋"><b>华伦天奴鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MiumiuShoes/" title="缪缪鞋子"><b>缪缪鞋子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/BurberryShoes/" title="巴宝莉鞋"><b>巴宝莉鞋</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/versaceshoes/" title="范思哲鞋"><b>范思哲鞋</b></a><i>|</i>
   
     </li>
                                                                                                             </ul>
</div>
                                                   
<div style="_width:650px;" class="dropmenudiv" id="dropmenu3">
  <ul>
                                                                 <li>
    <h3><a title="皮带" href="http://www.52milan.com/pidai/">皮带:</a></h3>
 
      
    <a href="http://www.52milan.com/lvpidai/" title="LV皮带"><b>LV皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrypidai/" title="巴宝莉皮带"><b>巴宝莉皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermespidai/" title="爱马仕皮带"><b>爱马仕皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccipidai/" title="古奇皮带"><b>古奇皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/stephenpidai/" title="斯蒂芬皮带"><b>斯蒂芬皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/zegnapidai/" title="杰尼亚皮带"><b>杰尼亚皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvpidai/" title="BV皮带"><b>BV皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cartierpidai/" title="卡地亚皮带"><b>卡地亚皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/loewepidai/" title="罗意威皮带"><b>罗意威皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/wblpidai/" title="万宝龙皮带"><b>万宝龙皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanelpidai/" title="香奈儿皮带"><b>香奈儿皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamopidai/" title="菲拉格慕皮带"><b>菲拉格慕皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/jaguar/" title="捷豹皮带"><b>捷豹皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/givenchypidai/" title="纪梵希皮带"><b>纪梵希皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/BallyBelt/" title="巴利皮带"><b>巴利皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/PradaBelt/" title="普拉达皮带"><b>普拉达皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/rv/" title="RV皮带"><b>RV皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/DMG/" title="D&amp;G皮带"><b>D&amp;G皮带</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/AlexanderWangBelt/" title="亚历山大·王皮带"><b>亚历山大·王皮带</b></a><i>|</i>
   
     </li>
                                                                             </ul>
</div>
                                                   
<div style="_width:670px;" class="dropmenudiv" id="dropmenu4">
  <ul>
                                                                                 <li>
    <h3><a title="名牌首饰" href="http://www.52milan.com/shoushi/">名牌首饰:</a></h3>
 
      
    <a href="http://www.52milan.com/chanelshoushi/" title="香奈儿"><b>香奈儿</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvlgarishoushi/" title="宝格丽"><b>宝格丽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermesshoushi/" title="爱马仕"><b>爱马仕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cartiershoushi/" title="卡地亚"><b>卡地亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/yslshoushi/" title="圣罗兰"><b>圣罗兰</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lvshoushi/" title="LV"><b>LV</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccishoushi/" title="古奇"><b>古奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendishoushi/" title="芬迪"><b>芬迪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/vcashoushi/" title="梵克雅宝"><b>梵克雅宝</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/toryburchshoushi/" title="托里伯奇"><b>托里伯奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/tiffany/" title="Tiffany"><b>Tiffany</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Valentinoshoushi/" title="华伦天奴"><b>华伦天奴</b></a><i>|</i>
   
     </li>
                                                             </ul>
</div>
<div style="_width:670px;" class="dropmenudiv" id="dropmenu5">
  <ul>
                                                 <li>
    <h3><a title="眼镜" href="http://www.52milan.com/mojing/">眼镜:</a></h3>
 
      
    <a href="http://www.52milan.com/ferrari/" title="法拉利"><b>法拉利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/porsche/" title="保时捷"><b>保时捷</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lvmojing/" title="LV"><b>LV</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/pradamojing/" title="普拉达"><b>普拉达</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccimojing/" title="古奇"><b>古奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/kdytyj/" title="卡地亚"><b>卡地亚</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/amntyj/" title="阿玛尼"><b>阿玛尼</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/lodk/" title="克罗心"><b>克罗心</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/diortyj/" title="迪奥"><b>迪奥</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/montblanctyj/" title="万宝龙"><b>万宝龙</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/todsmojing/" title="托德斯"><b>托德斯</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/swarovski/" title="施华洛世奇"><b>施华洛世奇</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrytyj/" title="巴宝莉"><b>巴宝莉</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendityj/" title="芬迪"><b>芬迪</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamotyj/" title="菲拉格慕"><b>菲拉格慕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/vivian/" title="薇薇安"><b>薇薇安</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Chaneltyj/" title="香奈儿"><b>香奈儿</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermestyj/" title="爱马仕"><b>爱马仕</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/dunhill/" title="登喜路"><b>登喜路</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvlgarityj/" title="宝格丽"><b>宝格丽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/cazal/" title="卡加尔"><b>卡加尔</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/celinetyj/" title="赛琳"><b>赛琳</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/RobertoCavallityj/" title="罗伯特·卡沃利"><b>罗伯特·卡沃利</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MarcJacobstyj/" title="马杰克"><b>马杰克</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Polaroidtyj/" title="宝丽来"><b>宝丽来</b></a><i>|</i>
   
     </li>
                                                                                             </ul>
</div>
<div style="_width:530px;" class="dropmenudiv" id="dropmenu6">
  <ul>
                                                                                                                 <li>
    <h3><a title="帽子" href="http://www.52milan.com/mao/">帽子:</a></h3>
 
      
    <a href="http://www.52milan.com/lvmaozi/" title="LV帽子"><b>LV帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccimaozi/" title="GUCCI帽子"><b>GUCCI帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendimaozi/" title="Fendi帽子"><b>Fendi帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrymaozi/" title="Burberry帽"><b>Burberry帽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermesmaozi/" title="Hermes帽"><b>Hermes帽</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanelmao/" title="Chanel帽子"><b>Chanel帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/MCMHat/" title="MCM帽子"><b>MCM帽子</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/PradaHat/" title="Prada帽子"><b>Prada帽子</b></a><i>|</i>
   
     </li>
                             </ul>
</div>                                                   
<div style="_width:530px;" class="dropmenudiv" id="dropmenu7">
  <ul>
                                                                                                 <li>
    <h3><a title="丝巾" href="http://www.52milan.com/sijin/">丝巾:</a></h3>
 
      
    <a href="http://www.52milan.com/lvsijin/" title="LV丝巾"><b>LV丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/hermessijin/" title="爱马仕丝巾"><b>爱马仕丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/chanelsijin/" title="香奈儿丝巾"><b>香奈儿丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/guccisijin/" title="gucci丝巾"><b>gucci丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Pradasijin/" title="普拉达丝巾"><b>普拉达丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/bvsijin/" title="BV丝巾"><b>BV丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/celinesijin/" title="赛琳丝巾"><b>赛琳丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/givenchysijin/" title="纪梵希丝巾"><b>纪梵希丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/fendisijin/" title="芬迪丝巾"><b>芬迪丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/burberrysijin/" title="巴宝莉丝巾"><b>巴宝莉丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/valentinosijin/" title="华伦天奴丝巾"><b>华伦天奴丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ToryBurchsijin/" title="托里伯奇丝巾"><b>托里伯奇丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/AlexanderWangsijin/" title="亚历山大·麦昆丝巾"><b>亚历山大·麦昆丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/marcjacobssijin/" title="马克·雅可布丝巾"><b>马克·雅可布丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/etrosijin/" title="艾特罗丝巾"><b>艾特罗丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/kenzosijin/" title="Kenzo丝巾"><b>Kenzo丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Diorsijin/" title="迪奥丝巾"><b>迪奥丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/ferragamosijin/" title="菲拉格慕丝巾"><b>菲拉格慕丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Loewesijin/" title="罗意威丝巾"><b>罗意威丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Armanisijin/" title="阿玛尼丝巾"><b>阿玛尼丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/DGsijin/" title="D&amp;G丝巾"><b>D&amp;G丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/YSLsijin/" title="圣罗兰丝巾"><b>圣罗兰丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/Zegnasijin/" title="杰尼亚丝巾"><b>杰尼亚丝巾</b></a><i>|</i>
   
      
    <a href="http://www.52milan.com/swarovskisijin/" title="施华洛世奇丝巾"><b>施华洛世奇丝巾</b></a><i>|</i>
   
     </li>
                                             </ul>
</div>  
<script type="text/javascript">cssdropdown.startchrome("chromemenu")</script>
</div>
        <div class="blank5"></div>
<div class="block clearfix"> 
  
  <div id="ur_here" style="height:35px;">
    <div class="f_l">当前位置: <a href=".">首页</a> <code>&gt;</code> <a href="http://www.52milan.com/ding/">包包</a> <code>&gt;</code> <a href="http://www.52milan.com/chanel/">香奈儿</a> <code>&gt;</code> 67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包</div>
    <div class="f_r"><a href="http://www.52milan.com/brand-chanel/"><img src="themes/wbw2012/images/goodsb.gif" /></a></div>
  </div>
   
</div>
<div class="blank"></div>
<div class="block clearfix"> 
  
  <div id="goodsInfo" class="clearfix"> 
    
    <div class="imgInfo"> 
       
      <a href="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_01.jpg" id="Zoomer" class="MagicZoomPlus" rel="selectors-effect:false;zoom-fade:true;background-opacity:70;zoom-width:450;zoom-height:450;caption-source:img:title;thumb-change:mouseover" title=""  onclick="window.open('gallery.php?id=43276'); return false;"> 
<img id="img_url" src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_01.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="thumb" /> </a> 
            <div class="blank"></div>
       
      <div class="clearfix" id="gallbox">
<span onmouseover="moveLeft()" onmousedown="clickLeft()" onmouseup="moveLeft()" onmouseout="scrollStop()"></span>
<div class="gallery">
<div id="demo">
<div id="demo1" style="float:left">
<ul>
<li>
<a href="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_01.jpg" rel="zoom-id:Zoomer" rev="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_01.jpg" title="">
<img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_01.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="onbg"  onmouseover="chkimgcss(this)"/>
</a>
</li>
 <li>
<a href="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_02.jpg" rel="zoom-id:Zoomer" rev="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_02.jpg" title="">
<img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_02.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="autobg"  onmouseover="chkimgcss(this)"/>
</a>
</li>
 <li>
<a href="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_03.jpg" rel="zoom-id:Zoomer" rev="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_03.jpg" title="">
<img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_03.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="autobg"  onmouseover="chkimgcss(this)"/>
</a>
</li>
 <li>
<a href="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_04.jpg" rel="zoom-id:Zoomer" rev="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_04.jpg" title="">
<img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_04.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="autobg"  onmouseover="chkimgcss(this)"/>
</a>
</li>
 <li>
<a href="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_05.jpg" rel="zoom-id:Zoomer" rev="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_05.jpg" title="">
<img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_05.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="autobg"  onmouseover="chkimgcss(this)"/>
</a>
</li>
 <li>
<a href="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_06.jpg" rel="zoom-id:Zoomer" rev="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_06.jpg" title="">
<img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_06.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="autobg"  onmouseover="chkimgcss(this)"/>
</a>
</li>
 </ul>
</div>
<div id="demo2" style="display:inline;overflow:visible;">
</div>
</div>
</div>
<span onmouseover="moveRight()" onmousedown="clickRight()" onmouseup="moveRight()" onmouseout="scrollStop()" class="spanR"></span>
<script type="text/javascript">
function $gg(A){
return(document.getElementById)?document.getElementById(A):document.all[A]
}
function chkimgcss(C){
var D=document.getElementById("demo");
var B=D.getElementsByTagName("img");
for(var A=0;A<B.length;A++){B[A].className="autobg"}C.className="onbg"}
var boxwidth=80;
var box=$gg("demo");
var obox=$gg("demo1");
var dulbox=$gg("demo2");
obox.style.width=obox.getElementsByTagName("li").length*boxwidth+"px";
dulbox.style.width=obox.getElementsByTagName("li").length*boxwidth+"px";
box.style.width=obox.getElementsByTagName("li").length*boxwidth*3+"px";
var canroll=false;if(obox.getElementsByTagName("li").length>=5){
canroll=true;dulbox.innerHTML=obox.innerHTML}var step=5;temp=1;speed=50;var awidth=obox.offsetWidth;var mData=0;var isStop=1;var dir=1;
function s(){if(!canroll){return}if(dir){if((awidth+mData)>=0){mData=mData-step}else{mData=-step}}else{if(mData>=0){mData=-awidth}else{mData+=step}}obox.style.marginLeft=mData+"px";if(isStop){return}setTimeout(s,speed)}
function moveLeft(){var A=isStop;dir=1;speed=50;isStop=0;if(A){setTimeout(s,speed)}}
function moveRight(){var A=isStop;dir=0;speed=50;isStop=0;if(A){setTimeout(s,speed)}}
function scrollStop(){isStop=1}
function clickLeft(){var A=isStop;dir=1;speed=25;isStop=0;if(A){setTimeout(s,speed)}}
function clickRight(){var A=isStop;dir=0;speed=25;isStop=0;if(A){setTimeout(s,speed)}};
</script>
</div>
 
      
      <div class="blank5"></div>
    </div>
    <div class="textInfo">
      <form action="javascript:addToCart(43276)" method="post" name="ECS_FORMBUY" id="ECS_FORMBUY">
        <div class="proname"><h1>67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包</h1></div>
                <div class="props">
          <dl>
            <dt>商品编号：</dt>
            <dd>67086黑色鹿皮</dd>
          </dl>
          <dl>
            <dt>产品品牌：</dt>
            <dd><a href="http://www.52milan.com/brand-chanel/">chanel香奈儿</a></dd>
          </dl>
           
        </div>
        <ul>
          <li class="clearfix">
            <dd> 本店售价：<font class="shop" id="ECS_SHOPPRICE">￥2600</font> </dd>
            <dd class="ddR"> 市场价格：<font class="market">￥4940</font> </dd>
          </li>
          
                    
          <li class="clearfix">
            <dd> 	   <img src="http://lvbao-file.b0.upaiyun.com/ico/kefu.gif" border="0" />
	   </dd>
            <dd class="ddR"> <strong>可节省：</strong>￥2340（5.3折）</dd>
          </li>
        </ul>
        <div class="product_bj" onmouseover="this.className='product_bj1'" onmouseout="this.className='product_bj'">
          <div style="border: medium none; padding-top: 10px; background: none repeat scroll 0% 0% transparent;"> 
            
           
            
                        <div class="clear"></div>
            <div style="height:25px; line-height:25px;">
              <div class="f_l">我要买：</div>
              <a href="javascript:void(0);" onclick="goods_cut();changePrice()" class="imgl"></a>
              <input name="number" type="text" id="number" class="inum" value="1" size="4" onblur="changePrice();get_shipping_list(forms['ECS_FORMBUY'],43276);"/>
              <a href="javascript:void(0);"  onclick="goods_add();changePrice()" class="imgr"></a> &nbsp;&nbsp;商品总价：<font id="ECS_GOODS_AMOUNT" class="shop"></font></div>
            <div class="buy clearfix">
              <div class="f_l gobuy">
                            <a href="javascript:addToCart1(43276)"><img src="themes/wbw2012/images/bnt_cat.gif" /></a>
                            </div>
              <div class="f_l"><a href="javascript:addToCart(43276)"><img src="themes/wbw2012/images/cart1.gif" /></a></div>
            </div>
            <script language="javascript" type="text/javascript">
			function goods_cut(){
				var num_val=document.getElementById('number');
				var new_num=num_val.value;
				 if(isNaN(new_num)){alert('请输入数字');return false}
				var Num = parseInt(new_num);
				if(Num>1)Num=Num-1;
				num_val.value=Num;
			}
			function goods_add(){
				var num_val=document.getElementById('number');
				var new_num=num_val.value;
				 if(isNaN(new_num)){alert('请输入数字');return false}
				var Num = parseInt(new_num);
				Num=Num+1;
				num_val.value=Num;
			}
	    </script> 
          </div>
        </div>
        <div class="blank"></div>
        <div class="blank"></div>
                <div class="sale_info"> 该商品已被浏览<span>59</span>次&nbsp;|&nbsp;已被评论<a rel="nofollow" href="/chanel-g43276.html#ECS_COMMENT"><span>554fcae493e564ee0dc75bdf2ebf94capl_sum|a:2:{s:4:"name";s:6:"pl_sum";s:8:"goods_id";s:5:"43276";}554fcae493e564ee0dc75bdf2ebf94ca</span></a>次 </div>
        <div class="add_fav"> 
          
          <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare"> <span class="bds_more">分享到：</span> <a class="bds_qzone"></a> <a class="bds_tsina"></a> <a class="bds_tqq"></a> <a class="bds_renren"></a> <a class="shareCount"></a> </div>
          <script type="text/javascript" id="bdshare_js" data="type=tools" ></script> 
          <script type="text/javascript" id="bdshell_js"></script> 
          <script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script> 
           
        </div>
        <div class="activity">
          <div class="t">商城推荐：</div>
          <div class="c">
            <ul>
              <li><span>●</span>&nbsp;零售商优惠活动：凡“购满”2000元以上的，立即减200元</li>
              <li><span>●</span>&nbsp;零售商优惠活动：凡“购满”3000元以上的，立即减300元</li>
              <li><span>●</span>&nbsp;零售商优惠活动：凡“购满”4000元以上的，立即减400元</li>
            </ul>
          </div>
        </div>
        <div class="reg"> </a><a href="user.php?act=register" rel="nofollow">马上注册成为会员</a> </div>
      </form>
    </div>
    <div class="blank"></div>
  </div>
      <div class="blank5 clearfix"></div>
  
  
  <div class="AreaL">
  <div id="hot_sale">
      <div class="l__hot_sale"></div>
      <ul>
                <li> <a class="img" target="_blank" href="gucci-g44800.html"><img src="http://bbpp.u.qiniudn.com/GucciHandbags2013/1/309613-12.jpg" alt="309613 黑色漆皮压花 Gucci精美时尚女士单肩手提包_古奇经典包_Gucci包包" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="gucci-g44800.html">309613 黑色漆皮压花 Gucci精美时尚女士单...</a> <span class="price">￥1100</span> </li>
                <li> <a class="img" target="_blank" href="prada-g44379.html"><img src="http://bbpp.u.qiniudn.com/PradaHandbags2013/1/80093-1-02.jpg" alt="80093-1土黄配蓝啡 普拉达男士休闲腰包_厂家热卖名牌胸包_普拉达胸包" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="prada-g44379.html">80093-1土黄配蓝啡 普拉达男士休闲腰包_厂家热...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="MichaelKors-g45247.html"><img src="http://bbpp.u.qiniudn.com/MichaelKorsHandbags2013/1/MK-03-01.jpg" alt="MK-03-01 MK热销时尚大牌包包_Michael Kors2013新款潮流时尚女包_MK美国时尚品牌" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="MichaelKors-g45247.html">MK-03-01 MK热销时尚大牌包包_Michae...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="hermespidai-g43833.html"><img src="http://bbpp.u.qiniudn.com/HermesBelt2013/1/H00552-01.jpg" alt="H00552 hermes英伦潮男休闲大方皮带_爱马仕官网皮带" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="hermespidai-g43833.html">H00552 hermes英伦潮男休闲大方皮带_爱马...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="ysl-g44390.html"><img src="http://bbpp.u.qiniudn.com/YSLHandbags2013/1/5228-04.jpg" alt="5228土黄 YSL全皮百搭男士公文包_厂家热卖品牌男士手提单肩包包_圣罗兰包包" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="ysl-g44390.html">5228土黄 YSL全皮百搭男士公文包_厂家热卖品牌...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="givenchy-g45151.html"><img src="http://bbpp.u.qiniudn.com/GivenchyHandbags2013/1/9989-04.jpg" alt="9989-黑配花 纪梵希潮流手提包_2013新款百搭时尚女士包包_Givenchy官网" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="givenchy-g45151.html">9989-黑配花 纪梵希潮流手提包_2013新款百搭...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="chanel-g44416.html"><img src="http://bbpp.u.qiniudn.com/ChanelWallet2013/1/093-05.jpg" alt="093蓝色 Chanel韩版潮女流行钱夹_香奈儿2013新品上市" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="chanel-g44416.html">093蓝色 Chanel韩版潮女流行钱夹_香奈儿20...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="gucci-g45082.html"><img src="http://bbpp.u.qiniudn.com/GucciHandbags2013/1/322714-01.jpg" alt="322714宝蓝 Gucci休闲男士经典包包_古奇男士高档包包_官网包包" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="gucci-g45082.html">322714宝蓝 Gucci休闲男士经典包包_古奇男...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="chanel-g44551.html"><img src="http://bbpp.u.qiniudn.com/ChanelWallet2013/1/31509-07.jpg" alt="31509荧光蓝 Chanel通勤复古OL百搭长款钱夹_香奈儿超迷你爆款钱包" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="chanel-g44551.html">31509荧光蓝 Chanel通勤复古OL百搭长款钱...</a> <span class="price">￥0</span> </li>
                <li> <a class="img" target="_blank" href="hermes-g44668.html"><img src="http://bbpp.u.qiniudn.com/HermesHandbags2013/1/1659-01.jpg" alt="1659黑色 爱马仕新款潮流包包_Hermes2013热销新品百搭时尚包包_爱马仕新款" class="home-thumb lh_lazyimg">
        
          </a> <a class="txt" target="_blank" href="hermes-g44668.html">1659黑色 爱马仕新款潮流包包_Hermes201...</a> <span class="price">￥0</span> </li>
              </ul>
    </div>
  
            
    
    <div class="blank5"></div> 
         
        <div id="news_list">
        	<div class="tab">
            	<ul>
				  <li class="cur">最新资讯</li> 	
                </ul>
            </div>
			                        
                          <div class="page cur">
                          <ul>
                                                                               </ul>
                          </div>
						  </div>
                          
                          
                                      
        </div>
  
  <div class="AreaR">
  
  <div class="box">
      <div id="desc">
      <div class="tab"> <a class="m1 cur" title="商品详情" href="javascript:void(0);"></a> <a class="m2" title="货到付款" href="javascript:void(0);"></a> <a class="m3" title="支付配送" href="javascript:void(0);"></a> <a class="m4" title="购物流程" href="javascript:void(0);"></a></div>
    <div class="clearfix">
      <div id="com_v" class="mt10"></div>
      <div id="com_h">
        <div class="page cur">
          <div class="t">
            <div class="g__product_detail"></div>
          </div>
          <img src="themes/wbw2012/images/fwcn.jpg" width="788" />
          <div class="blank"></div>
          <div style="margin:0 30px 0 58px;">
          <table><tr><td>
            <div>&nbsp;</div>
<div>■品牌■：Chanel香奈儿</div>
<div>&nbsp;</div>
<div>■货号■;67086黑色鹿皮</div>
<div>&nbsp;</div>
<div>■面料■：Chanel香奈儿专用进口牛皮；</div>
<div>&nbsp;</div>
<div>■尺寸■：W25xH16xD9cm；</div>
<div>&nbsp;</div>
<div>■包装■：原装Chanel香奈儿防尘袋+塑料袋，送礼自用两相宜；</div>
<div>&nbsp;</div>
<div>■备注■：内有Chanel香奈儿序列号, 说明书和仿伪卡；</div>
<div>&nbsp;</div>
<div>■级别■：按原版1:1比例做.</div>
<div>&nbsp;</div>
<div>1:1水准-你能找到的最高仿制水准，最接近真品的级别！专门针对品质要求高的客户。</div>
<div>&nbsp;</div>            </td></tr></table>
           
          </div>
          <div class="blank5"></div>
          <center>
            <div class="clear"></div>
                        <li><img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_01.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="B_blue" /></li>
            <li>
              <h4></h4>
            </li>
            <br />
                        <li><img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_02.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="B_blue" /></li>
            <li>
              <h4></h4>
            </li>
            <br />
                        <li><img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_03.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="B_blue" /></li>
            <li>
              <h4></h4>
            </li>
            <br />
                        <li><img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_04.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="B_blue" /></li>
            <li>
              <h4></h4>
            </li>
            <br />
                        <li><img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_05.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="B_blue" /></li>
            <li>
              <h4></h4>
            </li>
            <br />
                        <li><img src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/67086-89_06.jpg" alt="67086黑色鹿皮  Chanel新款百搭韩版经典包包_香奈儿复古流行单肩包_热销包包" class="B_blue" /></li>
            <li>
              <h4></h4>
            </li>
            <br />
                      </center>
          <div class="blank"></div>
           <div id="ECS_COMMENT"> 554fcae493e564ee0dc75bdf2ebf94cacomments|a:3:{s:4:"name";s:8:"comments";s:4:"type";i:0;s:2:"id";i:43276;}554fcae493e564ee0dc75bdf2ebf94ca</div>        </div>
       <div class="page">
          <div class="block">
            <div class="t">
              <div class="g__about_us2"><img src="/ad/hd.gif" /></div>
            </div>
            <div class="c">
            <p><img src="/ad/hd_01.jpg" />
            <img src="/ad/hd_02.jpg" />
            <img src="/ad/hd_03.jpg" />
            </p>
            </div>
          </div>
        </div>
     <div class="page">
          <div class="block">
            <div class="t">
              <div class="g__payment"></div>
            </div>
            <div class="c">
             <img src="/ad/zf.jpg" />
            </div>
          </div>
        </div>
      <div class="page">
          <div class="block">
            <div class="t">
              <div class="g__service_commitment"></div>
            </div>
            <div class="c">
            
            <div class="help_content">
                     <p><strong><span style="color: #339966">一.</span></strong><span style="color: #000000">注册成为维美达皮具新会员，点击</span><strong><span style="color: #ff0000"> <a href="/user.php?act=register" rel="nofollow"><span style="color: #ff0000">注册</span></a></span></strong>&nbsp;&nbsp;&nbsp;&nbsp; 如果您不打算注册<span style="color: #000000">“不打算登陆直接购买&nbsp;”</span><strong><span style="color: #ff0000">参考第5条细则</span></strong></p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="548" src="/images/upload/Image/网站购物流程_01.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>二.</strong></span><span style="color: #000000">进入我司网站浏览商品，如果有需要购买的款式直接点击</span><span style="color: #ff0000"><strong>“小图片”</strong></span><span style="color: #000000">进入到商品内页，往后操作流程看下图。</span></p>
<p><br>
<img align="middle" width="790" height="457" src="/images/upload/Image/网站购物流程_02.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>三.</strong></span><span style="color: #000000">点击</span><span style="color: #ff0000"><strong>“立即购买”</strong><span style="color: #000000">按钮，直接进入结算中心。也可以点击</span><strong>“加入购物车”</strong><span style="color: #000000">，如果要挑选其他商品则在选择</span><strong>“继续挑选宝贝”。</strong></span></p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="270" src="/images/upload/Image/网站购物流程_03.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>四.</strong></span><span style="color: #000000">订单核对后点击</span><span style="color: #ff0000"><strong>“去结算”</strong><span style="color: #000000">，</span><span style="color: #000000">如果同个款式商品数量需要增加的，则点击购买数量下的</span><strong>“ +&nbsp; ”</strong></span><span style="color: #000000">按键。</span></p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="312" src="/images/upload/Image/网站购物流程_07.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>五.</strong></span><span style="color: #000000">为方便您实时查看跟进订单情况，请先</span><span style="color: #ff0000"><strong>“注册用户”</strong><span style="color: #000000">，</span><span style="color: #000000">如果不想注册用户的，可以直接选择</span><strong>“不打算登陆，直接购买”</strong>。</span></p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="187" src="/images/upload/Image/网站购物流程_04.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>六.</strong></span><span style="color: #000000">注册成功的用户首次下单需要填写收货信息，往后下单</span><span style="color: #ff0000"><strong>系统自动保存地址</strong><span style="color: #000000">，如果收货信息有变更，可以另外</span><strong>增加收货信息。</strong></span></p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="440" src="/images/upload/Image/网站购物流程_05.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>七.</strong></span>确认您的 <span style="color: #ff0000"><strong>收货人、地址、电话、信息</strong></span><strong> </strong>无误后，在选择配送方式。</p>
<p>&nbsp;</p>
<p><img align="middle" width="790" height="543" src="/images/upload/Image/网站购物流程_06.jpg" alt=""></p>
<p>&nbsp;</p>
<p><span style="color: #339966"><strong>八.</strong></span><span style="color: #000000">选择好您的支付方式，如果您订购的商品有其他要求，请在</span><strong><span style="color: #ff0000">“订单附言”</span></strong><span style="color: #000000">里面做简短描述。最后确认无误点击</span><strong><span style="color: #ff0000">“提交订单”</span></strong><span style="color: #000000">，</span><span style="color: #000000">把</span><span style="color: #000000">订单号发给我司客服人员进行核对结算。</span></p>
<p>&nbsp;</p>                   </div>
            </div>
          </div>
        </div>
        
      
      </div>
    </div>
  </div>
  <script type="text/javascript">
    <!--
    reg("com");
    //-->
    </script>
  <div class="blank"></div>
  
  <div id="xingqu">
    <div class="t">
      <div class="g__xingqu"></div>
    </div>
    <div class="tab"> <a href="javascript:void(0);" class="cur" id="one1" onmousemove="setTab('one',1,4)">相关商品</a> <a class="" href="javascript:void(0);" id="one2" onmousemove="setTab('one',2,4)">相关文章</a> <a class="" href="javascript:void(0);" id="one3" onmousemove="setTab('one',3,4)">相关配件</a> <a class="" href="javascript:void(0);" id="one4" onmousemove="setTab('one',4,4)">购买过此商品的人还购买过</a> </div>
    <div class="page cur" id="con_one_1">
      <ul>
                <li> <a href="chanel-g43120.html" title="35487枚红色球纹皮 香奈儿热销时尚包包_Chanel2013新款潮流实用单肩女包_Chanel官网热销"> <img style="display: inline;" src="http://bbpp.u.qiniudn.com/ChanelHandbags2013/1/35487-04.jpg" alt="35487枚红色球纹皮 香奈儿热销时尚包包_Chanel2013新款潮流实用单肩女包_Chanel官网热销"><span>35487枚红色球纹皮 香奈儿热销时尚包包_Chan...</span></a><span> 
          ￥450 
          </span> </li>
                <li> <a href="chanelsijin-g44293.html" title="CH1109-5 Chanel新品时尚丝巾_香奈儿2013热销爆款时尚百搭丝巾_香奈儿丝巾"> <img style="display: inline;" src="http://bbpp.u.qiniudn.com/Chanelscarves2013/1/CH1109-5.jpg" alt="CH1109-5 Chanel新品时尚丝巾_香奈儿2013热销爆款时尚百搭丝巾_香奈儿丝巾"><span>CH1109-5 Chanel新品时尚丝巾_香奈儿2...</span></a><span> 
          ￥0 
          </span> </li>
                <li> <a href="chanelsijin-g44960.html" title="CH1118-1-01 香奈儿新款热销围巾_Chanel2013热销时尚大牌围巾_香奈儿围巾"> <img style="display: inline;" src="http://bbpp.u.qiniudn.com/Chanelscarves2013/1/CH1118-1-01.jpg" alt="CH1118-1-01 香奈儿新款热销围巾_Chanel2013热销时尚大牌围巾_香奈儿围巾"><span>CH1118-1-01 香奈儿新款热销围巾_Chan...</span></a><span> 
          ￥0 
          </span> </li>
                <li> <a href="chanelsijin-g44032.html" title="CH8014 Chanel热销新品丝巾_Chanel2013新品热卖百搭奢华丝巾围巾_香奈儿丝巾"> <img style="display: inline;" src="http://bbpp.u.qiniudn.com/Chanelscarves2013/1/CH8014.jpg" alt="CH8014 Chanel热销新品丝巾_Chanel2013新品热卖百搭奢华丝巾围巾_香奈儿丝巾"><span>CH8014 Chanel热销新品丝巾_Chanel...</span></a><span> 
          ￥0 
          </span> </li>
              </ul>
    </div>
    <div class="page" id="con_one_2">
      <ul class="articles">
      
      </ul>
    </div>
    <div class="page" id="con_one_3">
      <ul>
              </ul>
    </div>
    <div class="page" id="con_one_4">
      <ul>
              </ul>
    </div>
  </div>
  </div>
  <div class="blank5 clearfix"></div>
  </div>
</div>
 <style>
.weixin_pic {
    background-image: none;
    position: absolute;
    z-index: 9999;
	right:367px;
	margin-top:16px;
	_margin-top:18px;
	
}
.weixin_pic img{
	z-index: 9999;
	}
</style>
<div id="footer">
  <div class="info">
    <p> 
       
      <a href="http://www.lvbaopifa.com/article-204.html"   rel="nofollow" >维美达皮具网的优势</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-203.html"   rel="nofollow" >实体批发</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-97.html"   rel="nofollow" >咨询热点</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-205.html"   rel="nofollow" >国外支付方式</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-206.html"   rel="nofollow" >包包等级说明</a>&nbsp;&nbsp;|&nbsp;&nbsp; 
       
      <a href="http://www.lvbaopifa.com/article-207.html"   rel="nofollow" >运费查询</a> 
       
        |
      <a  href="/sitemap.html" target="_blank">网站地图</a>
    </p>
    
        <p>  
       
      </p>
    <p class="copyright">&copy; 2005-2014 米兰精品商城 版权所有，并保留所有权利。</p>
   
  </div>
</div>
<div class="blank5"></div>
<script type="text/javascript">
function datasrc(){
var imga = document.getElementsByTagName("img");
//alert('网站打开完毕！开始加载图片！');
for(i=0;i<imga.length;i++)
{
imgsrc=imga[i].getAttribute('data-src');
if (imgsrc!=null){
imga[i].setAttribute('src',""+imgsrc+"");
       }
}
}
</script>
<LINK rel=stylesheet type=text/css href="/images/common.css">
<DIV id=floatTools class=float0831>
  <DIV class=floatL> 
  <A style="DISPLAY: none" id="newswt_mini" class="btnOpen" title="查看在线客服"  href="javascript:void(0);">展开</A> 
<A id="newswt_close" class="btnCtn" title="关闭在线客服" href="javascript:void(0);">收缩</A> </DIV>
  <DIV id=divFloatToolsView class=floatR>
    <DIV class=tp></DIV>
    <DIV class=cn>
      <UL>
        <LI class=top>
          <H3 class=titZx>QQ咨询</H3>
        </LI>
        <LI><a rel="nofollow" target="_blank" href="/kefu_1.html?arg=lvbao1688&amp;style=1"><img width="80" height="26" src="/themes/wbw2012/images/zxkf.gif"></a></LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=800009775&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服①</A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1622861430&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服② </A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1764924587&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服③</A> </LI>
        <LI><A class=icoTc href="http://wpa.qq.com/msgrd?v=3&uin=1984216240&site=qq&menu=yes" target="_blank" rel="nofollow">QQ客服④</A> </LI>
         <LI><A  href="http://amos.im.alisoft.com/msg.aw?v=2&uid=%E7%BB%B4%E7%BE%8E%E8%BE%BE%E7%9A%AE%E5%85%B7&site=cntaobao&s=1&charset=utf-8" target="_blank" rel="nofollow"><img src="/ad/wangwang.gif"></A> </LI>
      </UL>
      <UL>
        <LI>
          <H3 class=titDh>电话咨询</H3>
        </LI>
        <LI><SPAN class=icoTl>4006-346-588</SPAN> </LI>
        <LI>
        <SPAN class=icoTl>15811883379</SPAN>
        </LI>
        <LI class=bot>
          <H3 class=titDc><A href="/message.php" target="_blank">给我留言</A></H3>
        </LI>
      </UL>
    </DIV>
  </DIV>
</DIV>
<script type="text/javascript">
function mouseOver()
{
    document.getElementById('weixin_pic').style.display = "block";
}
function mouseOut()
{
    document.getElementById('weixin_pic').style.display = "none";
}
$(function(){
 $(".weixin").mouseenter(function () {
        $(this).children('.weixin_pic').show();
    }).mouseleave(function () {
        $(this).children('.weixin_pic').hide();
 })
})
$(function(){
	$('#floatTools').show();
	/*$('.swt_h').prev().addClass('swt_current_t');
	$('.swt_tit').each(function(){
		$(this).click(function(){
			$(this).toggleClass('swt_current_t').next().slideToggle()
		})
	});*/
	$('#newswt_close').click(function(){
		$(this).hide()							  
		$('#divFloatToolsView').animate({
			width:'-=130'
		},400,function(){
			$(this).hide()
			$('#newswt_mini').show().animate({
				width:'+=40'
			},600)
		})
	});
	$('#newswt_mini').click(function(){
	    $(this).hide()								 
		$(this).animate({
			width:'-=40'
		},100,function(){
			$('#divFloatToolsView').show().animate({
				width:'+=130'
			},400,function(){
				$('#newswt_close').show().animate({
				width:'+=0'
			},600)
		  })
		})
	})
}) 
</script>
).animate({
				width:'+=0'
			},600)
		  })
		})
	})
}) 
</script>
</body>
<script type="text/javascript">
var goods_id = 43276;
var goodsattr_style = 1;
var gmt_end_time = 0;
var day = "天";
var hour = "小时";
var minute = "分钟";
var second = "秒";
var end = "结束";
var goodsId = 43276;
var now_time = 1388909996;
onload = function(){
  changePrice();
  fixpng();
  try {onload_leftTime();}
  catch (e) {}
}
/**
 * 点选可选属性或改变数量时修改商品价格的函数
 */
function changePrice()
{
  var attr = getSelectedAttributes(document.forms['ECS_FORMBUY']);
  var qty = document.forms['ECS_FORMBUY'].elements['number'].value;
  Ajax.call('goods.php', 'act=price&id=' + goodsId + '&attr=' + attr + '&number=' + qty, changePriceResponse, 'GET', 'JSON');
}
/**
 * 接收返回的信息
 */
function changePriceResponse(res)
{
  if (res.err_msg.length > 0)
  {
    alert(res.err_msg);
  }
  else
  {
    document.forms['ECS_FORMBUY'].elements['number'].value = res.qty;
    if (document.getElementById('ECS_GOODS_AMOUNT'))
      document.getElementById('ECS_GOODS_AMOUNT').innerHTML = res.result;
  }
}
/*
*选择信息处理
*/
function changeP(b, c) {
	var frm=document.forms['ECS_FORMBUY'];
	var cur_id="";
    document.getElementById('spec_value_' + c).checked=true;
	document.getElementById('url_' + c).className="selected";
	for (var i = 0; i < frm.elements[b].length; i++) {
		cur_id=frm.elements[b][i].id.substr(11);
        document.getElementById('url_' + cur_id).className="";
		if (frm.elements[b][i].checked)
		{
		   document.getElementById('url_' + c).className="selected";
		}
    }
	changePrice();
}
</script>
</html>