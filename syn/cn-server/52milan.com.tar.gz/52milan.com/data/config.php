<?php
// database host
$db_host   = "localhost:3306";

// database name
$db_name   = "alan_52milan";

// database username
$db_user   = "alan";

// database password
$db_pass   = "alan147896325";

// table prefix
$prefix    = "ecs_";

$timezone    = "PRC";

$cookie_path    = "/";

$cookie_domain    = "";

$session = "1440";

define('EC_CHARSET', 'utf-8');

define('ADMIN_PATH','sb_admin');

define('AUTH_KEY', 'this is a key');

define('OLD_AUTH_KEY', '');



define('API_TIME', '2014-01-06 00:02:44');
error_reporting(E_ALL);




































?>
