<?php
$lang['L_LOG_DELETE']="Log löschen";
$lang['L_LOGFILEFORMAT']="Log-Dateiformat";
$lang['L_LOGFILENOTWRITABLE']="Log-Datei kann nicht geschrieben werden!";
$lang['L_NOREVERSE']="Ältester Eintrag zuerst";
$lang['L_REVERSE']="Neuster Eintrag zuerst


";


?>