<?php
$lang['L_RESTORE_TABLES_COMPLETED0']="Up to now <b>%d</b> tables were created.";
$lang['L_FILE_MISSING']="couldn't find file";
$lang['L_RESTORE_DB']="Database '<b>%s</b>' on '<b>%s</b>'.";
$lang['L_RESTORE_COMPLETE']="<b>%s</b> tables created.";
$lang['L_RESTORE_RUN1']="<br>Up to now  <b>%s</b> of <b>%s</b> records were successfully added.";
$lang['L_RESTORE_RUN2']="<br>Now the table '<b>%s</b>' is restoring.<br><br>";
$lang['L_RESTORE_COMPLETE2']="<b>%s</b> records inserted.";
$lang['L_RESTORE_TABLES_COMPLETED']="Up to now <b>%d</b> of <b>%d</b> tables were created.";
$lang['L_RESTORE_TOTAL_COMPLETE']="<br><b>Congratulations.</b><br><br>The restoration of the database is done.<br>All data from the Backup file was restored.<br><br>Everything is done. :-)";
$lang['L_DB_SELECT_ERROR']="<br>Error:<br>Selection of database <b>";
$lang['L_DB_SELECT_ERROR2']="</b> failed!";
$lang['L_FILE_OPEN_ERROR']="Error: could not open file.";
$lang['L_PROGRESS_OVER_ALL']="Overall Progress";
$lang['L_BACK_TO_OVERVIEW']="Database Overview";
$lang['L_RESTORE_RUN0']="<br>up to now <b>%s</b> records were successfully added.";
$lang['L_UNKNOWN_SQLCOMMAND']="unknown SQL-Command";
$lang['L_NOTICES']="Notices";


?>