<?php
$lang['L_LOG_DELETE']="حذف مدخلات السجل";
$lang['L_LOGFILEFORMAT']="تفاصيل الملف في السجل";
$lang['L_LOGFILENOTWRITABLE']="لا يمكن الكتابة الى ملف السجل !";
$lang['L_NOREVERSE']="بيانات الدخول الاقدم";
$lang['L_REVERSE']="بيانات الدخول الاخيره

";


?>