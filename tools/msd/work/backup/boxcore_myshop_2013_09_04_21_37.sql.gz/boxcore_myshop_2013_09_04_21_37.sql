-- Status:8:205:MP_0:boxcore_myshop:php:1.24.4:MyShop20130904-稳定版备份:5.0.51b-community-nt-log:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|brand|34|3760|2013-08-24 23:29:17|MyISAM
-- TABLE|category|7|2188|2013-08-24 23:29:17|MyISAM
-- TABLE|cats|6|2172|2013-08-24 23:29:17|MyISAM
-- TABLE|commit|38|3372|2013-08-24 23:52:57|MyISAM
-- TABLE|config|3|4212|2013-08-24 23:29:17|MyISAM
-- TABLE|goods|32|12196|2013-08-24 23:52:57|MyISAM
-- TABLE|ordertab|26|11412|2013-08-24 23:52:57|MyISAM
-- TABLE|user|59|4232|2013-08-24 23:52:57|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2013-09-04 21:37

--
-- Create Table `brand`
--

DROP TABLE IF EXISTS `brand`;
CREATE TABLE `brand` (
  `id` tinyint(4) unsigned NOT NULL auto_increment,
  `cid` int(4) unsigned NOT NULL,
  `bname` varchar(40) NOT NULL,
  `blogo` varchar(255) NOT NULL,
  `bdesc` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `cid` (`cid`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

--
-- Data for Table `brand`
--

/*!40000 ALTER TABLE `brand` DISABLE KEYS */;
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('1','1','苹果','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('2','1','惠普','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('3','1','三星','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('4','1','索尼','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('5','1','联想','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('6','1','华硕','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('7','2','飞利浦','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('8','1','Thinkpad','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('9','1','戴尔','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('10','2','索尼','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('11','2','先锋','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('12','6','佳能','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('13','6','索尼','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('14','6','Nikon','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('15','6','奥林匹斯','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('16','4','苹果','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('17','4','三星','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('18','2','EDIFIER','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('19','6','三星','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('20','3','微软','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('21','1','宏基','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('22','3','惠普','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('23','3','双飞燕','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('24','4','HTC','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('25','4','摩托罗拉','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('26','4','海尔','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('27','5','惠普','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('28','5','华硕','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('29','5','Logitech','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('30','5','ThinkPad','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('31','5','技嘉','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('32','5','戴尔','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('33','5','雷帕','','');
INSERT INTO `brand` (`id`,`cid`,`bname`,`blogo`,`bdesc`) VALUES ('34','6','tess1','','');
/*!40000 ALTER TABLE `brand` ENABLE KEYS */;


--
-- Create Table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` tinyint(2) unsigned NOT NULL auto_increment,
  `cname` varchar(45) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Data for Table `category`
--

/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`id`,`cname`) VALUES ('1','笔记本');
INSERT INTO `category` (`id`,`cname`) VALUES ('2','耳机');
INSERT INTO `category` (`id`,`cname`) VALUES ('3','键盘');
INSERT INTO `category` (`id`,`cname`) VALUES ('4','手机');
INSERT INTO `category` (`id`,`cname`) VALUES ('5','鼠标');
INSERT INTO `category` (`id`,`cname`) VALUES ('6','数码相机');
INSERT INTO `category` (`id`,`cname`) VALUES ('7','test');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Create Table `cats`
--

DROP TABLE IF EXISTS `cats`;
CREATE TABLE `cats` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Data for Table `cats`
--

/*!40000 ALTER TABLE `cats` DISABLE KEYS */;
INSERT INTO `cats` (`id`,`name`) VALUES ('1','手机');
INSERT INTO `cats` (`id`,`name`) VALUES ('2','笔记本');
INSERT INTO `cats` (`id`,`name`) VALUES ('3','数码产品1');
INSERT INTO `cats` (`id`,`name`) VALUES ('4','耳机');
INSERT INTO `cats` (`id`,`name`) VALUES ('5','家电');
INSERT INTO `cats` (`id`,`name`) VALUES ('6','手表');
/*!40000 ALTER TABLE `cats` ENABLE KEYS */;


--
-- Create Table `commit`
--

DROP TABLE IF EXISTS `commit`;
CREATE TABLE `commit` (
  `id` int(4) unsigned NOT NULL auto_increment,
  `uid` int(4) unsigned NOT NULL,
  `mail` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `pid` int(4) unsigned NOT NULL,
  `time` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

--
-- Data for Table `commit`
--

/*!40000 ALTER TABLE `commit` DISABLE KEYS */;
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('1','0','','dfafaf','0','0');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('2','0','','fafadfadfa','1','1366253231');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('3','0','','fdfdf','1','1366253537');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('4','0','','dfafafd','1','1366253855');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('5','0','','fdfafda','1','1366253875');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('6','0','','dfafafd','1','1366253906');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('7','5','','dddfdfdfdfd','1','1366253971');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('8','5','','fadfaef','2','1366254333');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('9','5','','测试的数据 好东东 啊','2','1366254907');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('10','5','','好','2','1366254941');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('11','5','','这个产品好用么？\r\n','2','1366255019');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('12','5','','不好的产品？','2','1366255025');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('13','5','','dfdfafefef','2','1366255738');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('14','1','','cesefefef','1','1366255843');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('15','1','','抢沙发，我是管理员！\r\n','8','1366257632');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('16','1','','我我我','1','1366616619');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('17','1','','dfsfafafadfadfa','17','1366860396');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('18','1','','fafeafaefaefa','17','1366860466');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('19','1','','sdafawwwwwwwww','17','1366860510');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('20','1','','sdafawwwwwwwwwfdddfdfdff','17','1366860579');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('21','1','','','27','1366865505');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('22','1','','','27','1366865510');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('23','1','','测试验证码','27','1366865537');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('24','1','','','27','1366865628');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('25','1','','测试','27','1366865715');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('26','1','','','27','1366865738');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('27','1','','','27','1366865750');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('28','1','','11111111111111','27','1366865868');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('29','1','','testetrewt','30','1366867125');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('30','1','','afafee','25','1366874632');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('31','1','','fsdfdfdfa','25','1366874682');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('32','0','','aaaa','30','1366882064');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('33','0','','fdfafa','23','1366943952');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('34','0','','测试评论2','23','1366944036');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('35','54','','fsfsfsfsdfsfsf','32','1366945364');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('36','0','','aaaaaaaaaaaaaaaaaaaaaaaaaa','30','1366963329');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('37','56','','就是要测试这个产品 他的id','15','1366993138');
INSERT INTO `commit` (`id`,`uid`,`mail`,`content`,`pid`,`time`) VALUES ('38','1','','对方答复','30','1367028539');
/*!40000 ALTER TABLE `commit` ENABLE KEYS */;


--
-- Create Table `config`
--

DROP TABLE IF EXISTS `config`;
CREATE TABLE `config` (
  `id` int(2) unsigned NOT NULL auto_increment,
  `defname` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `range` int(5) NOT NULL,
  `value` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `defname` (`defname`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Data for Table `config`
--

/*!40000 ALTER TABLE `config` DISABLE KEYS */;
INSERT INTO `config` (`id`,`defname`,`type`,`range`,`value`) VALUES ('1','shopdir','','0','/myshop/');
INSERT INTO `config` (`id`,`defname`,`type`,`range`,`value`) VALUES ('2','shop_name','','0','我的测试商城');
INSERT INTO `config` (`id`,`defname`,`type`,`range`,`value`) VALUES ('3','shop_domain','','0','http://localhost/myshop/');
/*!40000 ALTER TABLE `config` ENABLE KEYS */;


--
-- Create Table `goods`
--

DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(100) default NULL,
  `pic` varchar(200) default NULL,
  `price` varchar(200) default NULL,
  `stock` int(11) default NULL,
  `time` int(11) default NULL,
  `cartup` tinyint(4) NOT NULL default '0',
  `bid` int(11) unsigned NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `bid` (`bid`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

--
-- Data for Table `goods`
--

/*!40000 ALTER TABLE `goods` DISABLE KEYS */;
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('1','戴尔(DELL) Ins15RR-3518X 15英寸笔记本电脑 （i5-3210M 4G 500G D刻 HD7670M 1G独显 WIN7）灰','thu_1366653089578745322.jpg','3899','98','1365963103','1','9','<span style=\"background-color:#FFFFFF;\"> \r\n<table align=\"center\" border=\"0\" width=\"750\" class=\"ke-zeroborder\">\r\n	<tbody>\r\n		<tr>\r\n			<td>\r\n				<div style=\"margin:0px;padding:0px;\">\r\n					<a target=\"_blank\" href=\"http://sale.360buy.com/p2516.html\"><img alt=\"\" src=\"http://img30.360buyimg.com/jgsq-productsoa/g8/M00/12/04/rBEHaFDqc2cIAAAAAAEpaeq23yoAADiswPnB3cAASmB696.jpg\" class=\"err-product\" /></a> \r\n				</div>\r\n			</td>\r\n		</tr>\r\n	</tbody>\r\n</table>\r\n<br />\r\n</span> \r\n<p style=\"color:#333333;font-family:Arial, Verdana, 宋体;background-color:#FFFFFF;\">\r\n	<span></span> \r\n</p>\r\n<div style=\"margin:0px auto;padding:0px;background-color:#FFFFFF;color:#E4E4E4;font-family:\'Microsoft YaHei\';font-size:11px;\">\r\n	<p>\r\n		&nbsp;<img alt=\"\" src=\"http://img30.360buyimg.com/jgsq-productsoa/g10/M00/01/1B/rBEQWFEIiX8IAAAAAAB0H7_yRuIAAAXNQHtjEkAAHQ3575.jpg\" class=\"err-product\" /><img alt=\"\" src=\"http://img30.360buyimg.com/jgsq-productsoa/g10/M00/01/1B/rBEQWFEIiXUIAAAAAAAz8eShM9wAAAXNQFSnU0AADQJ697.jpg\" class=\"err-product\" /> \r\n	</p>\r\n	<div style=\"margin:0px auto;padding:0px;\">\r\n		<p style=\"color:#666666;\">\r\n			全新灵越 R系列采用第三代英特尔酷睿处理器，性能更强劲，表现更卓越，玩转个性花样，释放内心独特主张，15R超大15.6寸高清屏幕，每一款都有型，当仁不让的时尚派。\r\n		</p>\r\n		<p style=\"color:#666666;\">\r\n			贝壳式设计，16:9宽屏让视野更加宽广，无论是欣赏高清电影还是玩3D游戏都能够带来逼真且震撼的视觉感受。\r\n		</p>\r\n		<p style=\"color:#666666;\">\r\n			新灵越R系列笔记本电脑成为您的通信中心。凭借强大的WiFi连接、内置高清网络摄像头、Skype和超过6小时的电池续航时间，与朋友和家人保持联系变得前所未有地简单。\r\n		</p>\r\n	</div>\r\n	<div style=\"margin:0px auto;padding:0px;\">\r\n		<p style=\"color:#666666;\">\r\n			15.6英寸Truelife屏幕随处为您带来身临其境般的观赏体验。通过HDMI端口连接到具有HDMI功能的外接电视或显示器，可使您享受超震撼的娱乐体验，再也无需购买电影票。\r\n		</p>\r\n	</div>\r\n	<div style=\"margin:0px;padding:0px;\">\r\n		<p style=\"color:#777777;\">\r\n			<strong>第三代智能英特尔<sup>®</sup>酷睿?处理器</strong>基于业界划时代的22纳米制程工艺和3D晶体管技术，通过将处理器和核芯显卡无缝融合，演绎强劲速度、超低能耗，以及流畅视觉体验的全“芯”升级感受。\r\n		</p>\r\n		<p style=\"color:#777777;\">\r\n			<strong>最高可达8GB DDR3<span class=\"wiki-words\" id=\"wiki-keyword-0\">内存</span></strong>标配4G内存，最高支持8G的快速高效DDR3 SDRAM(1600MHz)，为您提供快如闪电的观影、游戏和视频体验。\r\n		</p>\r\n		<p style=\"color:#777777;\">\r\n			<strong>内置高清摄像头</strong>高清摄像头被巧妙地隐藏在显示屏上方，用于拍摄照片和视频，将摄像头与语音视频配件和影音软件搭配使用，即可获得身临其境般的沟通体验。\r\n		</p>\r\n		<p style=\"color:#777777;\">\r\n			<strong>智能可切换显卡 随心而换</strong>既可享受高性能独立显卡带来的出色图形处理能力，也可享受到集成显卡带来的长续航时间，这一切都是由系统自动切换，不需要您进行任何手动操作。\r\n		</p>\r\n		<p style=\"color:#777777;\">\r\n			<strong>大容量硬盘 充足存储空间</strong>音乐、照片、影片、文档、各种文件都会与日俱增，500G超大存库空间硬盘满足存储需求，让一切资料随身携带。\r\n		</p>\r\n		<p style=\"color:#777777;\">\r\n			<strong>USB3.0</strong>拥有丰富USB接口,高速的传输速度。\r\n		</p>\r\n	</div>\r\n	<div style=\"margin:0px auto;padding:0px;\">\r\n	</div>\r\n	<div style=\"margin:0px auto;padding:0px;\">\r\n		<p style=\"color:#666666;\">\r\n			戴尔作为世界知名厂商，相信大家都不陌生。对于笔记本稍有接触的朋友也应该知道灵越系列，作为戴尔旗下的重要成员，该系列产品在娱乐市场上具有非常强的竞争力，不仅外观时尚靓丽，而且卓越的性能在日常游戏娱乐中表现突出，因此备受消费者喜爱。该系列可以称的上是戴尔的明星产品。对于喜欢娱乐的朋友来说，15吋屏幕可以带来更好的视觉、操作体验。所以消费者在考虑自身使用需求后，选择合适的尺寸，使用感受会更好。\r\n		</p>\r\n		<p style=\"color:#666666;\">\r\n			<strong>&nbsp;&nbsp;戴尔 WM112<br />\r\n&nbsp;&nbsp;三键式无线光电鼠标<br />\r\n·</strong>&nbsp;&nbsp;即插即用 设计小巧<br />\r\n<strong>·</strong>&nbsp;&nbsp;符合人体工程学<br />\r\n<strong>·</strong>&nbsp;&nbsp;精准的1000 dpi光学追踪能力<br />\r\n<strong>·</strong>&nbsp;&nbsp;自动通电/断电，带有指示灯<br />\r\n<strong>·</strong>&nbsp;&nbsp;USB迷你接收器，采用隐式折叠方式收纳\r\n		</p>\r\n		<p style=\"color:#666666;\">\r\n			<strong>&nbsp;&nbsp;戴尔 P2312H 23英寸<br />\r\n&nbsp;&nbsp;专业级宽屏LED背光液晶显示器<br />\r\n·</strong>&nbsp;&nbsp;生动的图像 智慧的调节<br />\r\n<strong>·</strong>&nbsp;&nbsp;性能满足工作效率需求<br />\r\n<strong>·</strong>&nbsp;&nbsp;舒适度和便捷性大有裨益<br />\r\n<strong>·</strong>&nbsp;&nbsp;远程管理\r\n		</p>\r\n		<p style=\"font-size:12px;color:#666666;\">\r\n			<strong>关于戴尔：</strong>戴尔公司由迈克尔?戴尔于1987年成立。近三十年来，戴尔致力于提供高品质的产品， 使得信息技术变得更加强大，易于使用，价格更能接受，为客户提供利用这些强大的、全新工具的机会，用以改善他们的工作和生活。<strong>010年，戴尔以其高品质的产品，稳定的性能和卓越的售后服务能力，被Gartner, Inc.评为全球第一大医疗保健信息技术服务提供商，与《财富》500强公司中的99 %保持积极的关系，为全球超过1000万家中小型企业(SMB)提供服务。</strong> \r\n		</p>\r\n		<p style=\"font-size:12px;color:#666666;\">\r\n			<strong>戴尔在中国：</strong>1998年戴尔进入了中国市场，从这一刻起，戴尔便把满足中国消费者的需求作为自身的使命.戴尔不断地将其全球化经验、领先的产品技术、完善的渠道和服务带到中国，并根据中国的本土实践进行改良，不断推陈出新，用能够突显中国消费者个性的产品打动消费者。在中国标准化研究院顾客满意度测评中心和清华大学中国企业研究中心联合编制出版的《2011年中国顾客满意度手册》中，<strong>戴尔笔记本电脑和台式计算机顾客满意度荣居行业第一。</strong> \r\n		</p>\r\n		<div>\r\n			<strong><br />\r\n</strong> \r\n		</div>\r\n	</div>\r\n</div>');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('2','惠普 ProBook','thu_1366697480652130220.jpg','3500','34','1366182027','1','2','dfdf');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('3','苹果1笔记本电脑2','thu_13666975451187730720.jpg','8998','55','1366181489','1','1','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('4','苹果mac1111111111','thu_13661960602070270166.jpg','5532','100','1366182118','1','1','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('5','宏基11111','thu_13661963941127989916.jpg','3445','333','1366182118','1','21','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('6','iphone 4s','thu_13661964871463122104.jpg','4500','200','1366182118','1','16','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('7','摩托罗拉 M121','thu_1366196542224074927.jpg','2300','57','1366182118','1','25','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('8','三星 212','thu_13661967131920209119.jpg','3100','38','1366182118','1','17','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('9','佳能 canon 22','thu_1366196751151046163.jpg','5600','33','1366182118','1','12','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('10','Nikon 尼康 23','thu_1366196825317636765.jpg','8700','78','1366182118','1','14','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('11','SONY 相机 dd','thu_1366196882864000508.jpg','4220','200','1366182118','1','13','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('12','SONY 索尼 相机 2323','thu_13661970372018121156.jpg','4588','32','1366182118','1','13','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('13','Nikon 3411','thu_13661970801288030124.jpg','6500','56','1366182118','1','14','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('14','SONY 6678','thu_13661971361736527373.jpg','4433','76','1366182118','1','13','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('15','LUNIX 这是一个相机','thu_13661972091806853327.jpg','8776','78','1366182118','1','15','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('16','三星电脑','thu_1366697975113253381.jpg','5278','25','1366697944','1','3','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('17','苹果22电脑11','thu_13666992941706002126.jpg','5869','78','1366698058','1','1','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('18','三星电脑12414','thu_13666993331190216329.jpg','1122','44','1366698852','1','3','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('19','索尼电脑地方','thu_1366699376332968866.jpg','3444','123','1366698998','1','4','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('20','fefef','thu_1366699046195664211.jpg','414124','12','1366699046','1','5','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('21','索尼大幅度反弹','thu_13666994341168377231.jpg','4433','343','1366699078','1','4','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('22','华硕 Hffd','thu_13666994681122531235.jpg','5525','42','1366699148','1','6','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('23','苹果1212','thu_1366699543828885118.jpg','8956','112','1366699244','1','1','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('24','sony vivo','thu_136669960575057466.jpg','4242','31','1366699605','1','4','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('25','三星 4141','thu_13666998001846595604.jpg','14244','33','1366699800','1','3','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('26','三星大幅度反弹','thu_1366699868583108587.jpg','777','57','1366699868','1','3','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('27','联想 e系列','thu_13666999041740837415.jpg','4567','21','1366699904','1','5','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('28','11惠普qqq22','thu_13666999331712931062.jpg','4589','31','1366699933','1','2','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('29','三星 豆豆','thu_13666999571848662980.jpg','5758','-3','1366699957','1','3','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('30','联想 白色','thu_13666999991441804161.jpg','5542','0','1366699999','1','5','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('31','键盘1121214','thu_1366943874235055678.jpg','125','24','1366943874','1','20','');
INSERT INTO `goods` (`id`,`name`,`pic`,`price`,`stock`,`time`,`cartup`,`bid`,`content`) VALUES ('32','test1111','thu_13669451371332116756.png','1221','5','1366945137','1','34','feffef');
/*!40000 ALTER TABLE `goods` ENABLE KEYS */;


--
-- Create Table `ordertab`
--

DROP TABLE IF EXISTS `ordertab`;
CREATE TABLE `ordertab` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `sn` varchar(255) NOT NULL,
  `info` text NOT NULL,
  `status` tinyint(1) NOT NULL default '0',
  `time` int(11) NOT NULL,
  `amount` int(10) unsigned NOT NULL,
  `note` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8;

--
-- Data for Table `ordertab`
--

/*!40000 ALTER TABLE `ordertab` DISABLE KEYS */;
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('45','1','1366612667653050604','%7B%223%22%3A%7B%22id%22%3A%223%22%2C%22name%22%3A%22%5Cu4e09%5Cu661f11%22%2C%22pic%22%3A%22thu_1366181489956026495.jpg%22%2C%22price%22%3A%222123%22%2C%22stock%22%3A%2255%22%2C%22num%22%3A1%7D%2C%2214%22%3A%7B%22id%22%3A%2214%22%2C%22name%22%3A%22SONY+6678%22%2C%22pic%22%3A%22thu_13661971361736527373.jpg%22%2C%22price%22%3A%224433%22%2C%22stock%22%3A%2276%22%2C%22num%22%3A1%7D%7D','0','1366612667','6556','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('43','1','1366597207492081762','%7B%221%22%3A%7B%22id%22%3A%221%22%2C%22name%22%3A%22%5Cu60e0%5Cu666e11112dd%22%2C%22pic%22%3A%22thu_1366195968622843257.jpg%22%2C%22price%22%3A%2212%22%2C%22stock%22%3A%2211%22%2C%22num%22%3A2%7D%7D','2','1366597207','24','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('44','1','1366600753820332058','%7B%221%22%3A%7B%22id%22%3A%221%22%2C%22name%22%3A%22%5Cu60e0%5Cu666e11112dd%22%2C%22pic%22%3A%22thu_1366195968622843257.jpg%22%2C%22price%22%3A%2212%22%2C%22stock%22%3A%2211%22%2C%22num%22%3A1%7D%2C%223%22%3A%7B%22id%22%3A%223%22%2C%22name%22%3A%22%5Cu4e09%5Cu661f11%22%2C%22pic%22%3A%22thu_1366181489956026495.jpg%22%2C%22price%22%3A%222123%22%2C%22stock%22%3A%2255%22%2C%22num%22%3A2%7D%2C%225%22%3A%7B%22id%22%3A%225%22%2C%22name%22%3A%22%5Cu5b8f%5Cu57fa11111%22%2C%22pic%22%3A%22thu_13661963941127989916.jpg%22%2C%22price%22%3A%223445%22%2C%22stock%22%3A%22333%22%2C%22num%22%3A1%7D%7D','2','1366600753','7703','有操作了么？');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('46','1','1366880803720658134','%7B%2214%22%3A%7B%22id%22%3A%2214%22%2C%22name%22%3A%22SONY+6678%22%2C%22pic%22%3A%22thu_13661971361736527373.jpg%22%2C%22price%22%3A%224433%22%2C%22stock%22%3A%2276%22%2C%22num%22%3A1%7D%2C%2222%22%3A%7B%22id%22%3A%2222%22%2C%22name%22%3A%22%5Cu534e%5Cu7855+Hffd%22%2C%22pic%22%3A%22thu_13666994681122531235.jpg%22%2C%22price%22%3A%225525%22%2C%22stock%22%3A%2242%22%2C%22num%22%3A2%7D%7D','2','1366880803','15483','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('47','1','1366881492752014981','%7B%227%22%3A%7B%22id%22%3A%227%22%2C%22name%22%3A%22%5Cu6469%5Cu6258%5Cu7f57%5Cu62c9+M121%22%2C%22pic%22%3A%22thu_1366196542224074927.jpg%22%2C%22price%22%3A%222300%22%2C%22stock%22%3A%2260%22%2C%22num%22%3A4%7D%7D','0','1366881492','9200','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('48','1','13668861971961128131','%7B%2230%22%3A%7B%22id%22%3A%2230%22%2C%22name%22%3A%22%5Cu8054%5Cu60f3+%5Cu767d%5Cu8272%22%2C%22pic%22%3A%22thu_13666999991441804161.jpg%22%2C%22price%22%3A%225542%22%2C%22stock%22%3A%2274%22%2C%22num%22%3A3%7D%7D','1','1366886197','16626','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('49','52','13669445911978840093','%7B%2230%22%3A%7B%22id%22%3A%2230%22%2C%22name%22%3A%22%5Cu8054%5Cu60f3+%5Cu767d%5Cu8272%22%2C%22pic%22%3A%22thu_13666999991441804161.jpg%22%2C%22price%22%3A%225542%22%2C%22stock%22%3A%2274%22%2C%22num%22%3A6%7D%2C%2214%22%3A%7B%22id%22%3A%2214%22%2C%22name%22%3A%22SONY+6678%22%2C%22pic%22%3A%22thu_13661971361736527373.jpg%22%2C%22price%22%3A%224433%22%2C%22stock%22%3A%2276%22%2C%22num%22%3A1%7D%7D','0','1366944591','37685','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('50','52','1366944696326491341','%7B%2229%22%3A%7B%22id%22%3A%2229%22%2C%22name%22%3A%22%5Cu4e09%5Cu661f+%5Cu8c46%5Cu8c46%22%2C%22pic%22%3A%22thu_13666999571848662980.jpg%22%2C%22price%22%3A%225758%22%2C%22stock%22%3A%2246%22%2C%22num%22%3A3%7D%7D','0','1366944696','17274','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('51','53','13669448442071245917','%7B%2223%22%3A%7B%22id%22%3A%2223%22%2C%22name%22%3A%22%5Cu82f9%5Cu679c1212%22%2C%22pic%22%3A%22thu_1366699543828885118.jpg%22%2C%22price%22%3A%228956%22%2C%22stock%22%3A%22112%22%2C%22num%22%3A3%7D%7D','2','1366944844','26868','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('52','1','1366945222941836746','%7B%2232%22%3A%7B%22id%22%3A%2232%22%2C%22name%22%3A%22test1111%22%2C%22pic%22%3A%22thu_13669451371332116756.png%22%2C%22price%22%3A%221221%22%2C%22stock%22%3A%225%22%2C%22num%22%3A%225%22%7D%7D','0','1366945222','6105','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('53','1','13669623211602031194','%7B%2230%22%3A%7B%22id%22%3A%2230%22%2C%22name%22%3A%22%5Cu8054%5Cu60f3+%5Cu767d%5Cu8272%22%2C%22pic%22%3A%22thu_13666999991441804161.jpg%22%2C%22price%22%3A%225542%22%2C%22stock%22%3A%2274%22%2C%22num%22%3A5%7D%7D','0','1366962321','27710','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('54','1','1366967315994753594','%7B%2225%22%3A%7B%22id%22%3A%2225%22%2C%22name%22%3A%22%5Cu4e09%5Cu661f+4141%22%2C%22pic%22%3A%22thu_13666998001846595604.jpg%22%2C%22price%22%3A%2214244%22%2C%22stock%22%3A%2233%22%2C%22num%22%3A1%7D%7D','0','1366967315','14244','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('55','1','1366981624510085616','%7B%2229%22%3A%7B%22id%22%3A%2229%22%2C%22name%22%3A%22%5Cu4e09%5Cu661f+%5Cu8c46%5Cu8c46%22%2C%22pic%22%3A%22thu_13666999571848662980.jpg%22%2C%22price%22%3A%225758%22%2C%22stock%22%3A%2246%22%2C%22num%22%3A3%7D%7D','0','1366981624','17274','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('56','56','13669928341816587841','%7B%2230%22%3A%7B%22id%22%3A%2230%22%2C%22name%22%3A%22%5Cu8054%5Cu60f3+%5Cu767d%5Cu8272%22%2C%22pic%22%3A%22thu_13666999991441804161.jpg%22%2C%22price%22%3A%225542%22%2C%22stock%22%3A%2274%22%2C%22num%22%3A1%7D%2C%228%22%3A%7B%22id%22%3A%228%22%2C%22name%22%3A%22%5Cu4e09%5Cu661f+212%22%2C%22pic%22%3A%22thu_13661967131920209119.jpg%22%2C%22price%22%3A%223100%22%2C%22stock%22%3A%2238%22%2C%22num%22%3A1%7D%7D','2','1366992834','8642','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('57','1','1367025246629934936','%7B%2229%22%3A%7B%22id%22%3A%2229%22%2C%22name%22%3A%22%5Cu4e09%5Cu661f+%5Cu8c46%5Cu8c46%22%2C%22pic%22%3A%22thu_13666999571848662980.jpg%22%2C%22price%22%3A%225758%22%2C%22stock%22%3A%2246%22%2C%22num%22%3A1%7D%2C%2230%22%3A%7B%22id%22%3A%2230%22%2C%22name%22%3A%22%5Cu8054%5Cu60f3+%5Cu767d%5Cu8272%22%2C%22pic%22%3A%22thu_13666999991441804161.jpg%22%2C%22price%22%3A%225542%22%2C%22stock%22%3A%2274%22%2C%22num%22%3A2%7D%7D','0','1367025246','16842','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('58','1','13670253471487806828','%7B%2230%22%3A%7B%22id%22%3A%2230%22%2C%22name%22%3A%22%5Cu8054%5Cu60f3+%5Cu767d%5Cu8272%22%2C%22pic%22%3A%22thu_13666999991441804161.jpg%22%2C%22price%22%3A%225542%22%2C%22stock%22%3A%2212%22%2C%22num%22%3A3%7D%7D','0','1367025347','16626','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('59','1','13670254091855028334','%7B%2230%22%3A%7B%22id%22%3A%2230%22%2C%22name%22%3A%22%5Cu8054%5Cu60f3+%5Cu767d%5Cu8272%22%2C%22pic%22%3A%22thu_13666999991441804161.jpg%22%2C%22price%22%3A%225542%22%2C%22stock%22%3A%2212%22%2C%22num%22%3A2%7D%7D','0','1367025409','11084','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('60','1','13670255371214185946','%7B%2230%22%3A%7B%22id%22%3A%2230%22%2C%22name%22%3A%22%5Cu8054%5Cu60f3+%5Cu767d%5Cu8272%22%2C%22pic%22%3A%22thu_13666999991441804161.jpg%22%2C%22price%22%3A%225542%22%2C%22stock%22%3A%2212%22%2C%22num%22%3A3%7D%7D','0','1367025537','16626','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('61','1','1367025882712444083','%7B%2230%22%3A%7B%22id%22%3A%2230%22%2C%22name%22%3A%22%5Cu8054%5Cu60f3+%5Cu767d%5Cu8272%22%2C%22pic%22%3A%22thu_13666999991441804161.jpg%22%2C%22price%22%3A%225542%22%2C%22stock%22%3A%2212%22%2C%22num%22%3A1%7D%7D','0','1367025882','5542','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('62','1','13670259081318266175','%7B%2230%22%3A%7B%22id%22%3A%2230%22%2C%22name%22%3A%22%5Cu8054%5Cu60f3+%5Cu767d%5Cu8272%22%2C%22pic%22%3A%22thu_13666999991441804161.jpg%22%2C%22price%22%3A%225542%22%2C%22stock%22%3A%2211%22%2C%22num%22%3A%2211%22%7D%7D','0','1367025908','60962','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('63','1','1367025994198133273','%7B%221%22%3A%7B%22id%22%3A%221%22%2C%22name%22%3A%22%5Cu6234%5Cu5c14%28DELL%29+Ins15RR-3518X+15%5Cu82f1%5Cu5bf8%5Cu7b14%5Cu8bb0%5Cu672c%5Cu7535%5Cu8111+%5Cuff08i5-3210M+4G+500G+D%5Cu523b+HD7670M+1G%5Cu72ec%5Cu663e+WIN7%5Cuff09%5Cu7070%22%2C%22pic%22%3A%22thu_1366653089578745322.jpg%22%2C%22price%22%3A%223899%22%2C%22stock%22%3A%22100%22%2C%22num%22%3A2%7D%7D','0','1367025994','7798','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('64','57','1367026712886767822','%7B%2229%22%3A%7B%22id%22%3A%2229%22%2C%22name%22%3A%22%5Cu4e09%5Cu661f+%5Cu8c46%5Cu8c46%22%2C%22pic%22%3A%22thu_13666999571848662980.jpg%22%2C%22price%22%3A%225758%22%2C%22stock%22%3A%22-1%22%2C%22num%22%3A1%7D%7D','0','1367026712','5758','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('65','57','1367026788508586562','%7B%2229%22%3A%7B%22id%22%3A%2229%22%2C%22name%22%3A%22%5Cu4e09%5Cu661f+%5Cu8c46%5Cu8c46%22%2C%22pic%22%3A%22thu_13666999571848662980.jpg%22%2C%22price%22%3A%225758%22%2C%22stock%22%3A%22-2%22%2C%22num%22%3A1%7D%7D','0','1367026788','5758','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('66','1','13670287721025655252','%7B%2228%22%3A%7B%22id%22%3A%2228%22%2C%22name%22%3A%2211%5Cu60e0%5Cu666eqqq22%22%2C%22pic%22%3A%22thu_13666999331712931062.jpg%22%2C%22price%22%3A%224589%22%2C%22stock%22%3A%2235%22%2C%22num%22%3A3%7D%7D','0','1367028772','13767','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('67','1','13670314741026686133','%7B%2228%22%3A%7B%22id%22%3A%2228%22%2C%22name%22%3A%2211%5Cu60e0%5Cu666eqqq22%22%2C%22pic%22%3A%22thu_13666999331712931062.jpg%22%2C%22price%22%3A%224589%22%2C%22stock%22%3A%2232%22%2C%22num%22%3A1%7D%7D','0','1367031474','4589','');
INSERT INTO `ordertab` (`id`,`uid`,`sn`,`info`,`status`,`time`,`amount`,`note`) VALUES ('68','59','1367033210276044232','%7B%2224%22%3A%7B%22id%22%3A%2224%22%2C%22name%22%3A%22sony+vivo%22%2C%22pic%22%3A%22thu_136669960575057466.jpg%22%2C%22price%22%3A%224242%22%2C%22stock%22%3A%2234%22%2C%22num%22%3A3%7D%2C%227%22%3A%7B%22id%22%3A%227%22%2C%22name%22%3A%22%5Cu6469%5Cu6258%5Cu7f57%5Cu62c9+M121%22%2C%22pic%22%3A%22thu_1366196542224074927.jpg%22%2C%22price%22%3A%222300%22%2C%22stock%22%3A%2260%22%2C%22num%22%3A3%7D%7D','2','1367033210','19626','');
/*!40000 ALTER TABLE `ordertab` ENABLE KEYS */;


--
-- Create Table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `username` varchar(40) default NULL,
  `password` varchar(40) default NULL,
  `admin` tinyint(1) unsigned NOT NULL default '0',
  `addr` varchar(250) default NULL,
  `tel` varchar(100) default NULL,
  `mail` varchar(200) default NULL,
  `realname` varchar(100) default NULL,
  `question` varchar(255) NOT NULL,
  `answer` varchar(255) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

--
-- Data for Table `user`
--

/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('1','user1','111','1','lamp brother','119110','aba@xii.cn','兄弟连掉丝','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('2','user2','222','0','大不列颠市区2001号','4322349','back.hk@bt.co','贝克汉姆','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('4','user4','444','0','444','56332124','xxx.33@tt.cn','苍井孔','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('3','user3','333','1','天空一区','88888888','6@dd.cc','小泽','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('5','user5','999','0','北京谈订单','12222222','aba@ddd.cc','辛苦费','没有问题','有问题');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('6','user6','8888','0','fafa','14444212','aba@3ddd.cc','cmd','cmd','cmd');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('7','user7','8888','0','北京测试一','','','','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('8','user8','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('9','user9','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('10','user10','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('11','user11','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('12','user12','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('13','user13','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('14','user14','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('15','user15','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('16','user16','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('17','user17','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('18','user18','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('19','user19','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('20','user20','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('21','user21','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('22','user22','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('23','user23','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('24','user24','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('25','user25','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('26','user26','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('27','user27','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('28','user28','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('29','user29','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('30','user30','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('31','user31','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('32','user32','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('33','user33','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('34','user34','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('35','user35','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('36','user36','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('37','user37','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('38','user38','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('39','user39','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('40','user40','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('41','user41','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('42','user42','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('43','user43','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('44','user44','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('45','user45','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('46','user46','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('47','user47','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('48','user48','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('49','user49','8888','0',NULL,NULL,NULL,NULL,'','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('50','demo','111','0','ddd','fff','fffff','测试账号dd','班主任','周明惠');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('51','demo2','demo2','0','','','','','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('52','long','long','0','long','long','long','long','long','long');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('53','88888888','88888888','0','dvdgd','124125151','ssfsf@sdsd.com','sddsfssf','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('54','user2222','user2222','1','user2222','','','','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('55','user1','aaaaaa','0','','','aaaaa@qq.cn','aaaaaa','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('56','12345678','12345678','0','12345678','15800202100','12345678','黄春泽测试','12345678','12345678');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('57','test','test','0','测试地址懂点','1215617543','tees@tes.con','测试账号','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('58','admin','admin','1','','','','','','');
INSERT INTO `user` (`id`,`username`,`password`,`admin`,`addr`,`tel`,`mail`,`realname`,`question`,`answer`) VALUES ('59','test1','111','0','','','','','','');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

